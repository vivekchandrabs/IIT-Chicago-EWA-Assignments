import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

function CartPage() {
    const [cartItems, setCartItems] = useState([]);
    const location = useLocation();
    const navigate = useNavigate();
    const query = new URLSearchParams(location.search);
    const customerId = query.get("customer_id");
    const userType = query.get("type");

    useEffect(() => {
        fetch(`http://localhost:8080/helloworld-servlet/cart/get?customer_id=${customerId}`)
            .then((response) => response.json())
            .then((data) => setCartItems(data))
            .catch((error) => console.error("Error fetching cart items:", error));
    }, [customerId]);

    const updateCart = async (productId, quantity) => {
        if (quantity === 0) {
            await fetch("http://localhost:8080/helloworld-servlet/cart/delete", {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ customer_id: customerId, product_id: productId }),
            });
        } else {
            await fetch("http://localhost:8080/helloworld-servlet/cart/update", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ customer_id: customerId, product_id: productId, quantity }),
            });
        }
        // Refresh cart items after update
        fetch(`http://localhost:8080/helloworld-servlet/cart/get?customer_id=${customerId}`)
            .then((response) => response.json())
            .then((data) => setCartItems(data))
            .catch((error) => console.error("Error fetching cart items:", error));
    };

    if (cartItems.length === 0) return <div>No items in the cart.</div>;

    return (
        <div style={{ padding: "20px" }}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "20px" }}>
                {cartItems.map((item) => (
                    <div key={item.product_id} style={{ border: "1px solid #ccc", borderRadius: "5px", overflow: "hidden", padding: "10px" }}>
                        <img src={item.product.image} alt={item.product.name} style={{ width: "100%", height: "150px", objectFit: "cover" }} />
                        <h3>{item.product.name}</h3>
                        <p>Price: ${item.product.price.toFixed(2)}</p>
                        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                            <button onClick={() => updateCart(item.product.id, item.quantity - 1)}>-</button>
                            <span style={{ margin: "0 10px" }}>{item.quantity}</span>
                            <button onClick={() => updateCart(item.product.id, item.quantity + 1)}>+</button>
                        </div>
                    </div>
                ))}
            </div>
            <button
                onClick={() => navigate(`/checkout?customer_id=${customerId}&type=${userType}`)}
                style={{ marginTop: "20px", padding: "10px 20px", backgroundColor: "green", color: "white", border: "none", cursor: "pointer" }}
            >
                Go to Checkout
            </button>
        </div>
    );
}

export default CartPage;