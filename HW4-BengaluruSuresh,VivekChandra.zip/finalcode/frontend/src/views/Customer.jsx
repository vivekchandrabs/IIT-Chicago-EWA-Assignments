import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

function CustomersPage() {
    const [customers, setCustomers] = useState([]);
    const [newCustomer, setNewCustomer] = useState({ name: "", email: "" });
    const [editingId, setEditingId] = useState(null);
    const [editedName, setEditedName] = useState("");
    const location = useLocation();
    const query = new URLSearchParams(location.search);
    const customerId = parseInt(query.get("customer_id"), 10);

    useEffect(() => {
        fetch("http://localhost:8080/helloworld-servlet/customers/all")
            .then((response) => response.json())
            .then((data) => setCustomers(data))
            .catch((error) => console.error("Error fetching customers:", error));
    }, []);

    const handleDelete = async (targetCustomerId) => {
        if (window.confirm("Are you sure you want to delete this customer?")) {
            try {
                const response = await fetch("http://localhost:8080/helloworld-servlet/customer/delete", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        target_customer_id: targetCustomerId,
                        customer_id: customerId,
                    }),
                });

                if (response.ok) {
                    alert("Customer deleted successfully.");
                    setCustomers(customers.filter(customer => customer.id !== targetCustomerId));
                } else {
                    alert("Failed to delete customer.");
                }
            } catch (error) {
                console.error("Error deleting customer:", error);
            }
        }
    };

    const handleEditClick = (customer) => {
        setEditingId(customer.id);
        setEditedName(customer.name);
    };

    const handleNameChange = (e) => {
        setEditedName(e.target.value);
    };

    const handleNameSubmit = async (id) => {
        try {
            const response = await fetch("http://localhost:8080/helloworld-servlet/customer/update-name", {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    customer_id: id,
                    new_name: editedName,
                }),
            });

            if (response.ok) {
                alert("Name updated successfully.");
                setCustomers(customers.map(customer =>
                    customer.id === id ? { ...customer, name: editedName } : customer
                ));
                setEditingId(null);
            } else {
                alert("Failed to update name.");
            }
        } catch (error) {
            console.error("Error updating name:", error);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewCustomer({ ...newCustomer, [name]: value });
    };

    const handleAddCustomer = async () => {
        try {
            const response = await fetch("http://localhost:8080/helloworld-servlet/customer/create", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    ...newCustomer,
                    customer_id: customerId,
                }),
            });

            if (response.ok) {
                alert("Customer added successfully.");
                setCustomers([...customers, { ...newCustomer, id: Date.now() }]); // Simulate adding new customer
                setNewCustomer({ name: "", email: "" });
            } else {
                alert("Failed to add customer.");
            }
        } catch (error) {
            console.error("Error adding customer:", error);
        }
    };

    return (
        <div className="d-flex p-3">
            <div className="flex-grow-1 d-grid gap-3" style={{ gridTemplateColumns: "repeat(2, 1fr)" }}>
                {customers.map((customer) => (
                    <div key={customer.id} className="border rounded p-3">
                        {editingId === customer.id ? (
                            <>
                                <input type="text" value={editedName} onChange={handleNameChange} className="form-control mb-2" />
                                <button onClick={() => handleNameSubmit(customer.id)} className="btn btn-success mb-2">Submit</button>
                            </>
                        ) : (
                            <>
                                <h3>{customer.name}</h3>
                                <button onClick={() => handleEditClick(customer)} className="btn btn-primary mb-2">Edit</button>
                            </>
                        )}
                        <p>Email: {customer.email}</p>
                        <p>Type: {customer.type}</p>
                        <p>Created At: {new Date(customer.created_at).toLocaleString()}</p>
                        <p>Updated At: {new Date(customer.updated_at).toLocaleString()}</p>
                        <button onClick={() => handleDelete(customer.id)} className="btn btn-danger">Delete</button>
                    </div>
                ))}
            </div>
            <div className="flex-shrink-0 border rounded p-3 ml-3" style={{ width: "300px" }}>
                <h2>Add Customer</h2>
                <form>
                    <div className="mb-2">
                        <label>Name</label>
                        <input type="text" name="name" value={newCustomer.name} onChange={handleInputChange} className="form-control" />
                    </div>
                    <div className="mb-2">
                        <label>Email</label>
                        <input type="email" name="email" value={newCustomer.email} onChange={handleInputChange} className="form-control" />
                    </div>
                    <button type="button" onClick={handleAddCustomer} className="btn btn-primary w-100">Submit</button>
                </form>
            </div>
        </div>
    );
}

export default CustomersPage;