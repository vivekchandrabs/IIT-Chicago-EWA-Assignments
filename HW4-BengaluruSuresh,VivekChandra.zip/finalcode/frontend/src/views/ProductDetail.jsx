import React, { useEffect, useState } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

function ProductDetail() {
    const { id } = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    const [product, setProduct] = useState(null);
    const [accessories, setAccessories] = useState([]);
    const [quantity, setQuantity] = useState(1);
    const [reviews, setReviews] = useState([]);

    // Get customer_id from URL
    const query = new URLSearchParams(location.search);
    const customerId = query.get("customer_id");
    const userType = query.get("type");

    // State for new review
    const [newReview, setNewReview] = useState({
        ProductModelName: "",
        ProductCategory: "",
        ProductPrice: 0,
        ProductID: id,
        UserID: customerId,
        ReviewRating: 0,
        ReviewDate: new Date().toISOString().split('T')[0], // Current date
        ReviewText: ""
    });

    useEffect(() => {
        // Fetch product details and accessories
        fetch(`http://localhost:8080/helloworld-servlet/product/${id}`)
            .then((response) => response.json())
            .then((data) => {
                setProduct(data);
                return Promise.all(
                    data.accessories.map((accessory) =>
                        fetch(`http://localhost:8080/helloworld-servlet/product/${accessory.id}`)
                            .then((res) => res.json())
                    )
                );
            })
            .then((accessoryData) => setAccessories(accessoryData))
            .catch((error) => console.error("Error fetching product:", error));

        // Fetch product reviews
        fetch(`http://localhost:8080/helloworld-servlet/product/reviews?product_id=${id}`)
            .then((response) => response.json())
            .then((data) => setReviews(data))
            .catch((error) => console.error("Error fetching reviews:", error));
    }, [id]);

    const handleAddToCart = async () => {
        try {
            const response = await fetch("http://localhost:8080/helloworld-servlet/cart/add", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    customer_id: customerId,
                    product_id: product.id,
                    quantity: quantity,
                }),
            });
            const result = await response.json();
            console.log("Add to Cart Response:", result);
            alert("Product added to cart!");
        } catch (error) {
            console.error("Add to Cart Error:", error);
        }
    };

    const handleLikeProduct = async () => {
        try {
            const response = await fetch("http://localhost:8080/helloworld-servlet/product/like", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ product_id: id }),
            });
            if (response.ok && product) {
                setProduct({ ...product, like_count: product.like_count + 1 }); // Increment like count
                alert("Product liked!");
            }
        } catch (error) {
            console.error("Error liking product:", error);
        }
    };

    const handleReviewChange = (e) => {
        setNewReview({ ...newReview, [e.target.name]: e.target.value });
    };

    const handleSubmitReview = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch("http://localhost:8080/helloworld-servlet/product/review", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(newReview),
            });
            if (response.ok) {
                alert("Review submitted!");
                setReviews([...reviews, newReview]);
                setNewReview({
                    ProductModelName: "",
                    ProductCategory: "",
                    ProductPrice: 0,
                    ProductID: id,
                    UserID: customerId,
                    ReviewRating: 0,
                    ReviewDate: new Date().toISOString().split('T')[0],
                    ReviewText: ""
                });
            }
        } catch (error) {
            console.error("Error submitting review:", error);
        }
    };

    if (!product) return <div>Loading...</div>;

    return (
        <div className="container" style={{ paddingTop: "20px" }}>
            <div className="row">
                <div className="col-md-8">
                    <div className="d-flex align-items-center mb-4">
                        <img src={product.image} alt={product.name} className="img-fluid mr-3" style={{ width: "300px" }} />
                        <div>
                            <h2>{product.name}</h2>
                            <p>Price: ${product.price.toFixed(2)}</p>
                            <p>{product.description}</p>
                            <p>Category: {product.category.name}</p>
                            <p>Warranty: {product.warranty.name}</p>
                            <div className="d-flex align-items-center mt-3">
                                <button className="btn btn-secondary" onClick={() => setQuantity(quantity > 1 ? quantity - 1 : 1)}>-</button>
                                <span className="mx-3">{quantity}</span>
                                <button className="btn btn-secondary" onClick={() => setQuantity(quantity + 1)}>+</button>
                            </div>
                            <button onClick={handleAddToCart} className="btn btn-primary mt-3">
                                Add to Cart
                            </button>
                            <button onClick={handleLikeProduct} className="btn btn-outline-primary mt-3 ml-2">
                                Like
                            </button>
                            <p>Total Likes: {product.like_count}</p> {/* Display total likes */}
                        </div>
                    </div>

                    <h3>Accessories</h3>
                    <div className="d-flex overflow-auto">
                        {accessories.map((accessory) => (
                            <div
                                key={accessory.id}
                                className="mr-3"
                                style={{ cursor: "pointer" }}
                                onClick={() => navigate(`/product/${accessory.id}?customer_id=${customerId}&type=${userType}`)}
                            >
                                <img src={accessory.image} alt={accessory.name} className="img-fluid" style={{ width: "100px" }} />
                                <p>{accessory.name}</p>
                                <p>${accessory.price.toFixed(2)}</p>
                            </div>
                        ))}
                    </div>

                    <h3>Reviews</h3>
                    {reviews.map((review, index) => (
                        <div key={index} className="border-bottom pb-3 mb-3">
                            <strong>{review.UserID}</strong> - Reviewed on {review.ReviewDate}
                            <p>Rating: {review.ReviewRating}</p>
                            <p><strong>{review.ProductModelName}</strong></p>
                            <p>Category: {review.ProductCategory}</p>
                            <p>Price at Review Time: ${review.ProductPrice.toFixed(2)}</p>
                            <p>{review.ReviewText}</p>
                        </div>
                    ))}
                </div>

                <div className="col-md-4">
                    <h3>Submit a Review</h3>
                    <form onSubmit={handleSubmitReview} className="form-group">
                        <label htmlFor="ProductModelName">Model Name</label>
                        <input type="text" id="ProductModelName" name="ProductModelName" placeholder="Model Name" value={newReview.ProductModelName} onChange={handleReviewChange} required className="form-control mb-2" />

                        <label htmlFor="ProductCategory">Category</label>
                        <input type="text" id="ProductCategory" name="ProductCategory" placeholder="Category" value={newReview.ProductCategory} onChange={handleReviewChange} required className="form-control mb-2" />

                        <label htmlFor="ProductPrice">Price</label>
                        <input type="number" id="ProductPrice" name="ProductPrice" placeholder="Price" value={newReview.ProductPrice} onChange={handleReviewChange} required className="form-control mb-2" />

                        <label htmlFor="ReviewRating">Rating (1-5)</label>
                        <input type="number" id="ReviewRating" name="ReviewRating" placeholder="Rating (1-5)" value={newReview.ReviewRating} onChange={handleReviewChange} required min="1" max="5" className="form-control mb-2" />

                        <label htmlFor="ReviewText">Your Review</label>
                        <textarea id="ReviewText" name="ReviewText" placeholder="Your review..." value={newReview.ReviewText} onChange={handleReviewChange} required className="form-control mb-2"></textarea>

                        <button type="submit" className="btn btn-primary">Submit Review</button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default ProductDetail;