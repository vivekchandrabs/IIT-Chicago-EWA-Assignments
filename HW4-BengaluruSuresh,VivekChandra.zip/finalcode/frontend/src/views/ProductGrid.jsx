import React, { useEffect, useState } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";

function ProductGrid() {
    const [products, setProducts] = useState([]);
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        fetch("http://localhost:8080/helloworld-servlet/product/all")
            .then((response) => response.json())
            .then((data) => setProducts(data))
            .catch((error) => console.error("Error fetching products:", error));
    }, []);

    const query = new URLSearchParams(location.search);
    const customerId = query.get("customer_id");
    const userType = query.get("type");

    const renderProductCard = (product) => (
        <div key={product.product_id} style={{ border: "1px solid #ccc", borderRadius: "5px", overflow: "hidden" }}>
            <img src={product.image} alt={product.name} style={{ width: "100%", height: "200px", objectFit: "cover" }} />
            <div style={{ padding: "10px" }}>
                <h3>{product.name}</h3>
                <p>${product.price.toFixed(2)}</p>
                <p>{product.description}</p>
                <button
                    onClick={() => navigate(`/product/${product.id}?customer_id=${customerId}&type=${userType}`)}
                    style={{ backgroundColor: "red", color: "white", padding: "5px 10px", border: "none", cursor: "pointer" }}
                >
                    View Details
                </button>
            </div>
        </div>
    );

    return (
        <div style={{ padding: "20px" }}>
            <div style={{ marginBottom: "20px" }}>
                <Link to={`/trending?${query.toString()}`} style={{ textDecoration: 'none', color: 'blue' }}>
                    View Trending Products
                </Link>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "20px" }}>
                {products.map(product => renderProductCard(product))}
            </div>
        </div>
    );
}

export default ProductGrid;