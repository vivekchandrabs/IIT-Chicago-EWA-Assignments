import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import 'bootstrap/dist/css/bootstrap.min.css';

// Register the components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

function SalesReport() {
    const [sales, setSales] = useState([]);
    const [dailySales, setDailySales] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredSales, setFilteredSales] = useState([]);

    useEffect(() => {
        fetch('http://localhost:8080/helloworld-servlet/api/sale-report')
            .then(response => response.json())
            .then(data => {
                setSales(data.sales);
                setDailySales(data.daily_sales);
                setFilteredSales(data.sales);
            })
            .catch(error => console.error('Error fetching data:', error));
    }, []);

    const handleSearchChange = (e) => {
        const value = e.target.value.toLowerCase();
        setSearchTerm(value);
        setFilteredSales(sales.filter(product => product.name.toLowerCase().includes(value)));
    };

    const productNames = filteredSales.map(product => product.name);
    const totalSales = filteredSales.map(product => product.total_sales);

    const data = {
        labels: productNames,
        datasets: [
            {
                label: 'Total Sales',
                data: totalSales,
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
            },
        ],
    };

    return (
        <div className="container mt-4">
            <h2>Product Sales Report</h2>
            <div className="mb-3">
                <input
                    type="text"
                    className="form-control"
                    placeholder="Search products..."
                    value={searchTerm}
                    onChange={handleSearchChange}
                />
                {searchTerm && (
                    <ul className="list-group position-absolute w-100" style={{ zIndex: 1000 }}>
                        {filteredSales.map((product, index) => (
                            <li key={index} className="list-group-item">
                                {product.name}
                            </li>
                        ))}
                    </ul>
                )}
            </div>

            <table className="table table-bordered">
                <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Product Price</th>
                    <th>Number of Items Sold</th>
                    <th>Total Sales</th>
                </tr>
                </thead>
                <tbody>
                {sales.map((product, index) => (
                    <tr key={index}>
                        <td>{product.name}</td>
                        <td>${product.price.toFixed(2)}</td>
                        <td>{product.number_of_items_sold}</td>
                        <td>${product.total_sales.toFixed(2)}</td>
                    </tr>
                ))}
                </tbody>
            </table>

            <h2>Daily Sales Transactions</h2>
            <table className="table table-bordered">
                <thead>
                <tr>
                    <th>Date</th>
                    <th>Total Sales</th>
                </tr>
                </thead>
                <tbody>
                {dailySales.map((day, index) => (
                    <tr key={index}>
                        <td>{day.date}</td>
                        <td>${day.total_sales.toFixed(2)}</td>
                    </tr>
                ))}
                </tbody>
            </table>

            <h2>Total Sales Bar Chart</h2>
            <Bar data={data} />
        </div>
    );
}

export default SalesReport;