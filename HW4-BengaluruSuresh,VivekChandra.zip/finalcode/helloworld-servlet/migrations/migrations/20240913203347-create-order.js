"use strict";
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("Orders", {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      customer_id: {
        type: Sequelize.INTEGER,
        references: {
          model: "Customers",
          key: "id",
        },
        onDelete: "CASCADE",
        allowNull: true, // Set nullable
      },
      products: {
        type: Sequelize.JSON,
        allowNull: true, // Set nullable
      },
      payment: {
        type: Sequelize.DECIMAL,
        allowNull: true, // Set nullable
      },
      delivery_type_id: {
        type: Sequelize.INTEGER,
        references: {
          model: "DeliveryTypes",
          key: "id",
        },
        allowNull: true, // Already nullable
        onDelete: "SET NULL",
      },
      status: {
        type: Sequelize.STRING,
        allowNull: true, // Set nullable
        defaultValue: "pending",
      },
      store_location_id: {
        type: Sequelize.INTEGER,
        references: {
          model: "StoreLocation",
          key: "id",
        },
        allowNull: true, // Already nullable
        onDelete: "SET NULL",
      },
      // Newly added columns
      credit_card_number: {
        type: Sequelize.STRING,
        allowNull: true, // Set nullable
      },
      zip_code: {
        type: Sequelize.STRING,
        allowNull: true, // Set nullable
      },
      address: {
        type: Sequelize.STRING,
        allowNull: true, // Set nullable
      },
      customer_name: {
        type: Sequelize.STRING,
        allowNull: true, // Set nullable
      },
      createdAt: {
        allowNull: true, // Set nullable
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
        allowNull: true, // Set nullable
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("Orders");
  },
};
