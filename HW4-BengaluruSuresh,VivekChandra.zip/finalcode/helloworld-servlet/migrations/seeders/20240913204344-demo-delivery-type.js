"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert("DeliveryTypes", [
      { title: "Standard", createdAt: new Date(), updatedAt: new Date() },
      { title: "Express", createdAt: new Date(), updatedAt: new Date() },
      { title: "Overnight", createdAt: new Date(), updatedAt: new Date() },
      { title: "Same Day", createdAt: new Date(), updatedAt: new Date() },
      { title: "Two-Day", createdAt: new Date(), updatedAt: new Date() },
      { title: "International", createdAt: new Date(), updatedAt: new Date() },
      {
        title: "In-Store Pickup",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      { title: "Local Delivery", createdAt: new Date(), updatedAt: new Date() },
      { title: "Free Shipping", createdAt: new Date(), updatedAt: new Date() },
      {
        title: "Subscription Delivery",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete("DeliveryTypes", null, {});
  },
};
