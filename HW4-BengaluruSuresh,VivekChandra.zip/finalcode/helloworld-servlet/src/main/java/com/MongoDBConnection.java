package com; // Adjust this package name as needed for your project structure

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class MongoDBConnection {
    private static final Logger logger = Logger.getLogger(MongoDBConnection.class.getName());
    private static MongoClient mongoClient;
    private static MongoDatabase database;

    public static MongoDatabase getDatabase() {
        if (database == null) {
            try {
                // Replace this with your actual MongoDB connection string
                String connectionString = "mongodb://localhost:27017/ewadb";
                logger.info("Connecting to MongoDB with connection string: " + connectionString);

                MongoClientSettings settings = MongoClientSettings.builder()
                        .applyConnectionString(new ConnectionString(connectionString))
                        .applyToSocketSettings(builder ->
                                builder.connectTimeout(10, TimeUnit.SECONDS))
                        .build();

                mongoClient = MongoClients.create(settings);
                database = mongoClient.getDatabase("ewadb");
                logger.info("Successfully connected to MongoDB database: " + database.getName());
            } catch (Exception e) {
                logger.severe("Failed to connect to MongoDB: " + e.getMessage());
                throw e;
            }
        }
        return database;
    }

    public static void close() {
        if (mongoClient != null) {
            mongoClient.close();
            logger.info("MongoDB connection closed.");
        }
    }
}