package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@WebServlet("/order/create")
public class OrderCreateServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body to JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract values from the JSON object
        int customerId = jsonObject.get("customer_id").getAsInt();
        String customerName = jsonObject.get("customer_name").getAsString();
        String creditCard = jsonObject.get("credit_card").getAsString();
        String zipCode = jsonObject.get("zip_code").getAsString();
        String address = jsonObject.get("address").getAsString();
        JsonArray products = jsonObject.getAsJsonArray("products");
        String payment = jsonObject.get("payment").getAsString();

        // Define default order status
        String status = "pending"; // This can be modified based on your business logic

        int orderId = 0;
        String createdAt;
        String updatedAt;
        JsonObject storeLocation = null; // To store the full store location information
        int deliveryTypeId = 0; // Variable to store the selected delivery type ID

        try (Connection connection = DBConnection.getConnection()) {
            // Select a random store location
            String storeLocationQuery = "SELECT id, name, location FROM StoreLocation ORDER BY RAND() LIMIT 1";
            PreparedStatement storeLocationStatement = connection.prepareStatement(storeLocationQuery);
            ResultSet storeLocationResult = storeLocationStatement.executeQuery();

            if (storeLocationResult.next()) {
                storeLocation = new JsonObject();
                storeLocation.addProperty("id", storeLocationResult.getInt("id"));
                storeLocation.addProperty("name", storeLocationResult.getString("name"));
                storeLocation.addProperty("location", storeLocationResult.getString("location"));
            }

            // Fetch a random delivery type ID from the DeliveryTypes table
            String deliveryTypeQuery = "SELECT id FROM DeliveryTypes ORDER BY RAND() LIMIT 1"; // Fetch one random delivery type
            PreparedStatement deliveryTypeStatement = connection.prepareStatement(deliveryTypeQuery);
            ResultSet deliveryTypeResult = deliveryTypeStatement.executeQuery();

            if (deliveryTypeResult.next()) {
                deliveryTypeId = deliveryTypeResult.getInt("id"); // Get the selected delivery type ID
            } else {
                // Handle case where there are no delivery types
                throw new SQLException("No delivery types available.");
            }

            // Insert the new order into the Orders table, including the random store location ID and delivery type ID
            String insertOrderQuery = "INSERT INTO Orders (customer_id, customer_name, credit_card_number, zip_code, address, products, payment, status, store_location_id, delivery_type_id, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(insertOrderQuery, Statement.RETURN_GENERATED_KEYS);

            // Set the current timestamp for createdAt and updatedAt
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String currentTime = dateFormat.format(new Date());

            statement.setInt(1, customerId);
            statement.setString(2, customerName);
            statement.setString(3, creditCard);
            statement.setString(4, zipCode);
            statement.setString(5, address);
            statement.setString(6, products.toString()); // Store the products as JSON string
            statement.setString(7, payment);
            statement.setString(8, status); // Status of the order
            statement.setInt(9, storeLocation.get("id").getAsInt()); // Store location ID
            statement.setInt(10, deliveryTypeId); // Delivery type ID
            statement.setString(11, currentTime); // createdAt
            statement.setString(12, currentTime); // updatedAt

            int affectedRows = statement.executeUpdate();

            // Ensure that the insert was successful
            if (affectedRows == 0) {
                throw new SQLException("Failed to create order, no rows affected.");
            }

            // Retrieve the generated order ID
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    orderId = generatedKeys.getInt(1); // Get the inserted order's ID
                } else {
                    throw new SQLException("Failed to create order, no ID obtained.");
                }
            }

            // Fetch the created and updated timestamps from the result
            createdAt = currentTime;
            updatedAt = currentTime;

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // Send error response if something goes wrong
            return;
        }

        // Build the response with the order details
        JsonObject orderResponse = new JsonObject();
        orderResponse.addProperty("id", orderId);
        orderResponse.addProperty("customer_id", customerId);
        orderResponse.addProperty("customer_name", customerName);
        orderResponse.addProperty("credit_card", creditCard);
        orderResponse.addProperty("zip_code", zipCode);
        orderResponse.addProperty("address", address);
        orderResponse.add("products", products);
        orderResponse.addProperty("payment", payment);
        orderResponse.addProperty("status", status); // Add the status to the response
        orderResponse.add("store_location", storeLocation); // Add full store location details
        orderResponse.addProperty("delivery_type_id", deliveryTypeId); // Add delivery type ID
        orderResponse.addProperty("createdAt", createdAt);
        orderResponse.addProperty("updatedAt", updatedAt);

        // Convert the order object to JSON and return it in the response
        String jsonResponse = gson.toJson(orderResponse);
        out.print(jsonResponse);
        out.flush();
    }
}
