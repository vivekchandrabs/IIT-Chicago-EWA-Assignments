package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Comparator;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.Gson;
import com.google.gson.JsonParser;

@WebServlet("/products/top-sold")
public class TopSoldProductsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();
        Gson gson = new Gson();

        // A map to store product_id as key and total quantity sold as value
        Map<Integer, Integer> productSalesMap = new HashMap<>();
        // A map to store zip_code as key and total quantity sold as value
        Map<String, Integer> zipSalesMap = new HashMap<>();

        try (Connection connection = DBConnection.getConnection()) {
            // Query to get all orders including their zip codes
            String query = "SELECT products, zip_code FROM Orders";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            // Process each order
            while (resultSet.next()) {
                // Get the products JSON array from the result set
                String productsJsonString = resultSet.getString("products");
                String zipCode = resultSet.getString("zip_code");
                JsonArray productsJsonArray = JsonParser.parseString(productsJsonString).getAsJsonArray();

                // Loop through each product in the array
                for (int i = 0; i < productsJsonArray.size(); i++) {
                    JsonObject productObject = productsJsonArray.get(i).getAsJsonObject();
                    int productId = productObject.get("product_id").getAsInt();
                    int quantity = productObject.get("quantity").getAsInt();

                    // Update the productSalesMap with the product's sold quantity
                    productSalesMap.put(productId, productSalesMap.getOrDefault(productId, 0) + quantity);

                    // Update the zipSalesMap with the zip code's sold quantity
                    zipSalesMap.put(zipCode, zipSalesMap.getOrDefault(zipCode, 0) + quantity);
                }
            }

            // Get top 5 sold products by quantity
            JsonArray topProductsArray = getTopProducts(productSalesMap, connection);
            // Get top 5 sold products by zip code
            JsonArray topZipProductsArray = getTopZipProducts(zipSalesMap, connection);
            // Get top 5 liked products
            JsonArray topLikedProductsArray = getTopLikedProducts(connection);

            // Combine all results into a final JSON object
            JsonObject finalResponse = new JsonObject();
            finalResponse.add("top_products", topProductsArray);
            finalResponse.add("top_zip_products", topZipProductsArray);
            finalResponse.add("top_liked_products", topLikedProductsArray);

            // Send the response
            out.print(gson.toJson(finalResponse));
            out.flush();
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    // Method to get top 5 products based on sold quantities
    private JsonArray getTopProducts(Map<Integer, Integer> productSalesMap, Connection connection) throws SQLException {
        PriorityQueue<Map.Entry<Integer, Integer>> topProductsQueue = new PriorityQueue<>(
                Comparator.comparingInt(Map.Entry::getValue)
        );

        for (Map.Entry<Integer, Integer> entry : productSalesMap.entrySet()) {
            topProductsQueue.offer(entry);
            if (topProductsQueue.size() > 5) {
                topProductsQueue.poll(); // Remove the lowest sales count if we exceed top 5
            }
        }

        JsonArray topProductsArray = new JsonArray();
        while (!topProductsQueue.isEmpty()) {
            Map.Entry<Integer, Integer> entry = topProductsQueue.poll();
            String productQuery = "SELECT id, name, price, description, image FROM Products WHERE id = ?";
            PreparedStatement productStatement = connection.prepareStatement(productQuery);
            productStatement.setInt(1, entry.getKey());
            ResultSet productResult = productStatement.executeQuery();

            if (productResult.next()) {
                JsonObject productJson = new JsonObject();
                productJson.addProperty("product_id", productResult.getInt("id"));
                productJson.addProperty("name", productResult.getString("name"));
                productJson.addProperty("price", productResult.getDouble("price"));
                productJson.addProperty("description", productResult.getString("description"));
                productJson.addProperty("image", productResult.getString("image"));
                productJson.addProperty("quantity_sold", entry.getValue()); // Total quantity sold
                topProductsArray.add(productJson);
            }
        }

        return topProductsArray;
    }

    // Method to get top 5 zip codes based on sold quantities, including complete product information
    private JsonArray getTopZipProducts(Map<String, Integer> zipSalesMap, Connection connection) throws SQLException {
        PriorityQueue<Map.Entry<String, Integer>> topZipQueue = new PriorityQueue<>(
                Comparator.comparingInt(Map.Entry::getValue)
        );

        for (Map.Entry<String, Integer> entry : zipSalesMap.entrySet()) {
            topZipQueue.offer(entry);
            if (topZipQueue.size() > 5) {
                topZipQueue.poll(); // Remove the lowest sales count if we exceed top 5
            }
        }

        JsonArray topZipArray = new JsonArray();
        while (!topZipQueue.isEmpty()) {
            Map.Entry<String, Integer> entry = topZipQueue.poll();
            JsonObject zipJson = new JsonObject();
            zipJson.addProperty("zip_code", entry.getKey());
            zipJson.addProperty("quantity_sold", entry.getValue()); // Total quantity sold by zip code

            // Retrieve the products sold in this zip code
            JsonArray productsInZip = new JsonArray();
            String orderQuery = "SELECT products FROM Orders WHERE zip_code = ?";

            try (PreparedStatement orderStatement = connection.prepareStatement(orderQuery)) {
                orderStatement.setString(1, entry.getKey());
                ResultSet orderResult = orderStatement.executeQuery();

                // Process each order for the given zip code
                while (orderResult.next()) {
                    // Get the products JSON array from the result set
                    String productsJsonString = orderResult.getString("products");
                    JsonArray productsJsonArray = JsonParser.parseString(productsJsonString).getAsJsonArray();

                    // Loop through each product in the array
                    for (int i = 0; i < productsJsonArray.size(); i++) {
                        JsonObject productObject = productsJsonArray.get(i).getAsJsonObject();
                        int productId = productObject.get("product_id").getAsInt();
                        int quantity = productObject.get("quantity").getAsInt();

                        // Fetch product details from the Products table
                        String productQuery = "SELECT id, name, price, description, image FROM Products WHERE id = ?";
                        try (PreparedStatement productStatement = connection.prepareStatement(productQuery)) {
                            productStatement.setInt(1, productId);
                            ResultSet productResult = productStatement.executeQuery();

                            if (productResult.next()) {
                                JsonObject productJson = new JsonObject();
                                productJson.addProperty("product_id", productResult.getInt("id"));
                                productJson.addProperty("name", productResult.getString("name"));
                                productJson.addProperty("price", productResult.getDouble("price"));
                                productJson.addProperty("description", productResult.getString("description"));
                                productJson.addProperty("image", productResult.getString("image"));
                                productJson.addProperty("quantity_sold", quantity); // Quantity sold for this product
                                productsInZip.add(productJson);
                            }
                        }
                    }
                }
            }

            zipJson.add("products", productsInZip);
            topZipArray.add(zipJson);
        }

        return topZipArray;
    }

    // Method to get top 5 liked products based on like_count
    private JsonArray getTopLikedProducts(Connection connection) throws SQLException {
        JsonArray topLikedArray = new JsonArray();
        String likedProductsQuery = "SELECT id, name, price, description, image, like_count FROM Products ORDER BY like_count DESC LIMIT 5";
        PreparedStatement likedProductsStatement = connection.prepareStatement(likedProductsQuery);
        ResultSet likedProductsResult = likedProductsStatement.executeQuery();

        while (likedProductsResult.next()) {
            JsonObject productJson = new JsonObject();
            productJson.addProperty("product_id", likedProductsResult.getInt("id"));
            productJson.addProperty("name", likedProductsResult.getString("name"));
            productJson.addProperty("price", likedProductsResult.getDouble("price"));
            productJson.addProperty("description", likedProductsResult.getString("description"));
            productJson.addProperty("image", likedProductsResult.getString("image"));
            productJson.addProperty("like_count", likedProductsResult.getInt("like_count")); // Total like count
            topLikedArray.add(productJson);
        }

        return topLikedArray;
    }
}
