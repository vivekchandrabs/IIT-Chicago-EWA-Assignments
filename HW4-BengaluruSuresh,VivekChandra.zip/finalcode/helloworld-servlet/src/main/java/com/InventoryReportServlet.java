package com;

import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/api/inventory-report")
public class InventoryReportServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();
        List<Product> productList = new ArrayList<>();
        List<Product> saleProductList = new ArrayList<>();

        try (Connection connection = DBConnection.getConnection()) {
            // SQL query to fetch product details, including rebate
            String query = "SELECT name, price, stock, rebate FROM Products";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            // Process the result set
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                double price = resultSet.getDouble("price");
                int stock = resultSet.getInt("stock");
                double rebate = resultSet.getDouble("rebate");

                Product product = new Product(name, price, stock, rebate);
                productList.add(product);

                // Check if the product is on sale (rebate > 10% of price)
                if (rebate > price * 0.10) {
                    saleProductList.add(product);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Convert the product lists to JSON using Gson
        Gson gson = new Gson();
        JsonResponse response = new JsonResponse(productList, saleProductList);
        String jsonResponse = gson.toJson(response);
        out.print(jsonResponse);
        out.flush();
    }

    // Inner class for Product
    class Product {
        private String name;
        private double price;
        private int stock;
        private double rebate; // Add rebate field

        public Product(String name, double price, int stock, double rebate) {
            this.name = name;
            this.price = price;
            this.stock = stock;
            this.rebate = rebate; // Initialize rebate
        }
    }

    // Inner class for JSON Response
    class JsonResponse {
        private List<Product> products;
        private List<Product> saleProducts;

        public JsonResponse(List<Product> products, List<Product> saleProducts) {
            this.products = products;
            this.saleProducts = saleProducts;
        }
    }
}
