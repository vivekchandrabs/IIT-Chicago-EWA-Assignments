package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/customer/signup")
public class SignupServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Set CORS headers to allow requests from any domain
        resp.setHeader("Access-Control-Allow-Origin", "*");
        resp.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        resp.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body into JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract name, email, and type from the JSON object
        String name = jsonObject.get("name").getAsString();
        String email = jsonObject.get("email").getAsString();
        String type = jsonObject.get("type").getAsString();

        int customerId = 0;
        String createdAt = null;
        String updatedAt = null;

        try (Connection connection = DBConnection.getConnection()) {
            // Insert the new customer into the Customers table
            String insertCustomerQuery = "INSERT INTO Customers (name, email, type, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(insertCustomerQuery, PreparedStatement.RETURN_GENERATED_KEYS);

            // Set the current timestamp for createdAt and updatedAt
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String currentTime = dateFormat.format(new Date());

            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, type);
            statement.setString(4, currentTime);  // createdAt
            statement.setString(5, currentTime);  // updatedAt
            int affectedRows = statement.executeUpdate();

            // Ensure that the insert was successful
            if (affectedRows == 0) {
                throw new SQLException("Failed to sign up customer, no rows affected.");
            }

            // Retrieve the generated customer ID
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    customerId = generatedKeys.getInt(1); // Get the inserted customer ID
                } else {
                    throw new SQLException("Failed to sign up customer, no ID obtained.");
                }
            }

            // Fetch the created and updated timestamps
            createdAt = currentTime;
            updatedAt = currentTime;

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            return;
        }

        // Build the response JSON with the customer details
        JsonObject customerResponse = new JsonObject();
        customerResponse.addProperty("id", customerId);
        customerResponse.addProperty("name", name);
        customerResponse.addProperty("email", email);
        customerResponse.addProperty("type", type);
        customerResponse.addProperty("createdAt", createdAt);
        customerResponse.addProperty("updatedAt", updatedAt);

        // Return the response as JSON
        String jsonResponse = gson.toJson(customerResponse);
        out.print(jsonResponse);
        out.flush();
    }
}
