package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@WebServlet("/orders/all")
public class OrdersServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body to JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract customer_id from the JSON object
        int customerId = jsonObject.get("customer_id").getAsInt();

        List<Order> orderList = new ArrayList<>();

        try (Connection connection = DBConnection.getConnection()) {
            // SQL query to fetch orders for the given customer_id
            String query = "SELECT o.id, o.customer_id, o.products, o.payment, o.status, o.store_location_id, "
                    + "o.delivery_type_id, o.createdAt, o.updatedAt, "
                    + "o.credit_card_number, o.address, o.zip_code, "
                    + "d.title as delivery_type FROM Orders o "
                    + "JOIN DeliveryTypes d ON o.delivery_type_id = d.id "
                    + "WHERE o.customer_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, customerId);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                // Parse the products field from JSON string to JsonArray
                String productsJsonString = resultSet.getString("products");
                JsonArray productsJsonArray = JsonParser.parseString(productsJsonString).getAsJsonArray();

                // Enrich the products with product details from the Products table
                JsonArray detailedProducts = new JsonArray();
                for (int i = 0; i < productsJsonArray.size(); i++) {
                    JsonObject productObject = productsJsonArray.get(i).getAsJsonObject();
                    int productId = productObject.get("product_id").getAsInt();
                    int quantity = productObject.get("quantity").getAsInt();

                    // Fetch product details from the Products table
                    String productQuery = "SELECT id, name, price, description, image FROM Products WHERE id = ?";
                    try (PreparedStatement productStatement = connection.prepareStatement(productQuery)) {
                        productStatement.setInt(1, productId);
                        ResultSet productResult = productStatement.executeQuery();

                        if (productResult.next()) {
                            // Add detailed product information to the original product object
                            productObject.addProperty("name", productResult.getString("name"));
                            productObject.addProperty("price", productResult.getDouble("price"));
                            productObject.addProperty("description", productResult.getString("description"));
                            productObject.addProperty("image", productResult.getString("image"));
                            productObject.addProperty("quantity", quantity);  // Include the quantity from the order

                            // Add enriched product object to the detailedProducts array
                            detailedProducts.add(productObject);
                        }
                    }
                }

                // Fetch store location details if store_location_id is not null
                int storeLocationId = resultSet.getInt("store_location_id");
                JsonObject storeLocationObject = null;
                if (storeLocationId != 0) {
                    String storeQuery = "SELECT id, name, location FROM StoreLocation WHERE id = ?";
                    try (PreparedStatement storeStatement = connection.prepareStatement(storeQuery)) {
                        storeStatement.setInt(1, storeLocationId);
                        ResultSet storeResult = storeStatement.executeQuery();

                        if (storeResult.next()) {
                            storeLocationObject = new JsonObject();
                            storeLocationObject.addProperty("id", storeResult.getInt("id"));
                            storeLocationObject.addProperty("name", storeResult.getString("name"));
                            storeLocationObject.addProperty("location", storeResult.getString("location"));
                        }
                    }
                }

                // Build the order object with detailed information from the Orders table
                Order order = new Order(
                        resultSet.getInt("id"),
                        resultSet.getInt("customer_id"),
                        resultSet.getString("status"),
                        detailedProducts,
                        resultSet.getString("payment"),
                        storeLocationObject,
                        resultSet.getInt("delivery_type_id"),
                        resultSet.getString("createdAt"),
                        resultSet.getString("updatedAt"),
                        resultSet.getString("credit_card_number"), // Get credit card number from Orders table
                        resultSet.getString("address"), // Get address from Orders table
                        resultSet.getString("zip_code"), // Get zip code from Orders table
                        resultSet.getString("delivery_type") // New field for delivery type
                );
                orderList.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Optionally send an error response back
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            JsonObject errorResponse = new JsonObject();
            errorResponse.addProperty("error", "Failed to retrieve orders.");
            out.print(gson.toJson(errorResponse));
            out.flush();
            return; // Exit to prevent further processing
        }

        // Convert the order list to JSON using Gson
        String jsonResponse = gson.toJson(orderList);
        out.print(jsonResponse);
        out.flush();
    }

    // Inner class for Order
    class Order {
        private int id;
        private int customer_id;
        private String status;
        private JsonArray products;
        private String payment;
        private JsonObject store_location;
        private int delivery_type_id;
        private String createdAt;
        private String updatedAt;
        private String credit_card_number; // New field for credit card number
        private String address; // New field for address
        private String zip_code; // New field for zip code
        private String delivery_type; // New field for delivery type

        public Order(int id, int customer_id, String status, JsonArray products, String payment, JsonObject store_location,
                     int delivery_type_id, String createdAt, String updatedAt,
                     String credit_card_number, String address, String zip_code, String delivery_type) {
            this.id = id;
            this.customer_id = customer_id;
            this.status = status;
            this.products = products;
            this.payment = payment;
            this.store_location = store_location;
            this.delivery_type_id = delivery_type_id;
            this.createdAt = createdAt;
            this.updatedAt = updatedAt;
            this.credit_card_number = credit_card_number; // Set credit card number from Orders table
            this.address = address; // Set address from Orders table
            this.zip_code = zip_code; // Set zip code from Orders table
            this.delivery_type = delivery_type; // Set delivery type
        }
    }
}
