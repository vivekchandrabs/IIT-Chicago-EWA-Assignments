from langchain_openai import OpenAIEmbeddings
from langchain_elasticsearch import ElasticsearchStore

def get_vector_store(index_name):
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

    elastic_vector_search = ElasticsearchStore(
        es_url="http://localhost:9200",
        index_name=index_name,
        embedding=embeddings,
        es_user="elastic",
        es_password="0nHuOyhIGTZ=tNiI_UKy",
    )
    
    return elastic_vector_search