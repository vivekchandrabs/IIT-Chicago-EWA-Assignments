import json
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv()

from langchain_openai import OpenAIEmbeddings
from langchain_core.documents import Document
from uuid import uuid4

import mysql.connector
from langchain_elasticsearch import ElasticsearchStore

def get_vector_store(index_name, embeddings="text-embedding-3-small"):
    elastic_vector_search = ElasticsearchStore(
        es_url="http://localhost:9200",
        index_name=index_name,
        embedding=embeddings,
        es_user="elastic",
        es_password="0nHuOyhIGTZ=tNiI_UKy",
    )
    
    return elastic_vector_search
    
def fetch_products():
    # Database connection
    conn = mysql.connector.connect(
        host='localhost',
        user='root',
        password='password',
        database='ewadb'
    )
    
    cursor = conn.cursor(dictionary=True)
    
    # Query to fetch all records from Products table
    query = "SELECT * FROM Products"
    cursor.execute(query)
    
    # Fetch all rows from the executed query
    rows = cursor.fetchall()
    
    # Initialize an empty list to store the JSON data
    json_data = []
    
    # Iterate over each row and append to the JSON array
    for row in rows:
        for key in row:
            row[key] = str(row[key])
        json_data.append(row)
    
    # Close the cursor and connection
    cursor.close()
    conn.close()
    
    # Convert the list to a JSON string
    json_string = json.dumps(json_data, indent=4)
    
    return json_string

def fetch_product_reviews():
    # MongoDB connection
    client = MongoClient('localhost', 27017)
    db = client['ewadb']
    collection = db['product_reviews']
    
    # Fetch all documents from the collection
    reviews = collection.find()
    
    # Initialize an empty list to store the JSON data
    json_data = []
    
    # Iterate over each document and append to the JSON array
    for review in reviews:
        json_data.append({
            "ProductModelName": review.get("ProductModelName"),
            "ProductCategory": review.get("ProductCategory"),
            "ProductPrice": review.get("ProductPrice"),
            "ProductID": review.get("ProductID"),
            "UserID": review.get("UserID"),
            "ReviewRating": review.get("ReviewRating"),
            "ReviewDate": review.get("ReviewDate"),
            "ReviewText": review.get("ReviewText")
        })
    
    # Convert the list to a JSON string
    json_string = json.dumps(json_data, indent=4)
    
    return json_string

def embed_data():
    products_json = fetch_products()
    product_reviews = fetch_product_reviews()

    # Get embeddings for the product
    # Iterate over the products and create documents for each product
    documents = []
    uuids = []
    for product in json.loads(products_json):
        # Create a document for the product
        strProduct = json.dumps(product)
        document = Document(
            page_content=strProduct,
            metadata={"source": "product"},
        )

        # Append the document to the list
        documents.append(document)
        uuids.append(str(uuid4()))
    
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

    # Store the embeddings in Elasticsearch
    index_name = "ewa_products_3"
    elastic_vector_search = get_vector_store(index_name, embeddings)
    elastic_vector_search.add_documents(documents=documents, ids=uuids)

    # Get embeddings for the product reviews
    # Iterate over the product reviews and create documents for each review
    review_documents = []
    review_uuids = []
    for review in json.loads(product_reviews):
        # Create a document for the review
        strReview = json.dumps(review)
        document = Document(
            page_content=strReview,
            metadata={"source": "product_review"},
        )

        # Append the document to the list
        review_documents.append(document)
        review_uuids.append(str(uuid4()))

    # Store the embeddings in Elasticsearch
    index_name = "ewa_product_reviews_3"
    elastic_vector_search = get_vector_store(index_name, embeddings)
    elastic_vector_search.add_documents(documents=review_documents, ids=review_uuids)

    print("Embeddings stored successfully!")

    return

embed_data()