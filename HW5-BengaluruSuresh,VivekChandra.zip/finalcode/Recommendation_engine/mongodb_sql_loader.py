import mysql.connector
from pymongo import MongoClient

# MySQL configuration
mysql_config = {
    'host': 'localhost',        # Change as per your MySQL server
    'user': 'root',             # Replace with your MySQL username
    'password': 'password',     # Replace with your MySQL password
    'database': 'ewadb' # Replace with your MySQL database name
}

# MongoDB configuration
mongo_config = {
    'host': 'localhost',
    'port': 27017,              # Default MongoDB port
    'database': 'ewadb', # Replace with your MongoDB database name
    'collection': 'product_reviews'
}

def load_data_from_mysql_to_mongodb():
    try:
        # Connect to MySQL
        mysql_conn = mysql.connector.connect(**mysql_config)
        mysql_cursor = mysql_conn.cursor(dictionary=True)
        
        # Fetch data from MySQL
        mysql_cursor.execute("SELECT * FROM product_reviews")
        rows = mysql_cursor.fetchall()
        
        # Connect to MongoDB
        mongo_client = MongoClient(mongo_config['host'], mongo_config['port'])
        mongo_db = mongo_client[mongo_config['database']]
        mongo_collection = mongo_db[mongo_config['collection']]
        
        # Prepare and insert data into MongoDB
        for row in rows:
            # Map MySQL columns to MongoDB fields
            mongo_document = {
                "ProductModelName": row["ProductModelName"],
                "ProductCategory": row["ProductCategory"],
                "ProductPrice": float(row["ProductPrice"]),
                "ProductID": row["ProductID"],
                "UserID": row["UserID"],
                "ReviewRating": row["ReviewRating"],
                "ReviewDate": row["ReviewDate"].isoformat(),
                "ReviewText": row["ReviewText"],
            }
            mongo_collection.insert_one(mongo_document)
        
        print(f"Successfully loaded {len(rows)} records into MongoDB.")
    
    except Exception as e:
        print(f"An error occurred: {e}")
    
    finally:
        # Close MySQL connection
        if mysql_cursor:
            mysql_cursor.close()
        if mysql_conn:
            mysql_conn.close()
        # Close MongoDB connection
        if mongo_client:
            mongo_client.close()

if __name__ == "__main__":
    load_data_from_mysql_to_mongodb()
