from langchain_elasticsearch import ElasticsearchStore
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains import create_retrieval_chain
import json
import mysql.connector
from vector_store import get_vector_store

def create_chain(vectorStore):
    model = ChatOpenAI(
        temperature=0.4,
        model='gpt-4o-mini'
    )

    prompt = ChatPromptTemplate.from_template("""
    Answer the user's question based on the information provided in the context below.                                               
    If there is no relevant data in the context, tell I do not know the answer for this. 
            
    Return the answer in the json format only.
    Do not include any other information in the response. 
    Do not include any markdown tags in the response.
    Return multiple results if there are multiple answers, but no duplicate results.  
    The outer parent should be a list and all the product should be many json inside the list.                                              
    All the objects should be in the list.                                     
    Context: {context}
    Question: {input}
    """)

    # chain = prompt | model
    document_chain = create_stuff_documents_chain(
        llm=model,
        prompt=prompt
    )

    retriever = vectorStore.as_retriever(search_kwargs={"k": 10, "score_threshold": 0.2}, 
                                                         search_type="similarity_score_threshold")

    retrieval_chain = create_retrieval_chain(retriever, document_chain)

    return retrieval_chain

def get_product_review_recommendation(user_query):
    vectorStore = get_vector_store("ewa_product_reviews_3")
    chain = create_chain(vectorStore)

    response = chain.invoke({
        "input": user_query,
    })

    print(response)

    answer = response["answer"]
    required_json = json.loads(answer)

    result_product_ids = []

    for result in required_json:
        productID = result["ProductID"]

        if productID not in result_product_ids:
            result_product_ids.append(productID)
    
    print("product_ids", result_product_ids)
    
    # Get the product by id from the Products table from the database.
    # Database connection
    conn = mysql.connector.connect(
        host='localhost',
        user='root',
        password='password',
        database='ewadb'
    )

    products = []
    cursor = conn.cursor(dictionary=True)
    for productID in result_product_ids:
        # Query to fetch all records from Products table
        query = "SELECT * FROM Products WHERE id = {}".format(productID)
        cursor.execute(query)
        product = cursor.fetchone()

        products.append(product)
    print()
    print(products)

    cursor.close()
    conn.close()

    # Sort all the reviews by the product id
    for result in required_json:
        productID = result["ProductID"]

        for i in range(len(products)):
            if int(products[i]["id"]) == int(productID):
                if "reviews" not in products[i]:
                    products[i]["reviews"] = [result]
                else:
                    products[i]["reviews"].append(result)

    return products