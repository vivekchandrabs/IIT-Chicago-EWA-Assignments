# Read from the database all the products. 
# Generate embeddings for each product in the document. Use mainly the product name, description, image, category, price for embeddings. 
# Store all the embeddings in a Elastic search

from langchain_elasticsearch import ElasticsearchStore
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains import create_retrieval_chain
from langchain_openai import OpenAIEmbeddings
from vector_store import get_vector_store
import json

def create_chain(vectorStore):
    model = ChatOpenAI(
        temperature=0.4,
        model='gpt-4o-mini'
    )

    prompt = ChatPromptTemplate.from_template("""
    Answer the user's question based on the information provided in the context below.                                               
    If there is no relevant data in the context, tell I do not know the answer for this. 

                                               
    Return the answer in the json format only.
    Do not include any other information in the response. 
    Do not include any markdown tags in the response.  
    The outer parent should be a list and all the product should be many json inside the list.
    Return multiple results if there are multiple answers, but no duplicate results
    All the objects should be in the list.
                                                                                   
    Context: {context}
    Question: {input}
    """)

    # chain = prompt | model
    document_chain = create_stuff_documents_chain(
        llm=model,
        prompt=prompt
    )

    retriever = vectorStore.as_retriever(search_kwargs={"k": 10, "score_threshold": 0.2}, 
                                                         search_type="similarity_score_threshold")

    retrieval_chain = create_retrieval_chain(retriever, document_chain)

    return retrieval_chain

def get_product_recommendation(user_query):
    vectorStore = get_vector_store("ewa_products_3")
    chain = create_chain(vectorStore)

    response = chain.invoke({
        "input": user_query,
    })

    answer = response["answer"]
    required_json = json.loads(answer)

    if required_json is None or required_json == "" or required_json == {} or required_json == []:
        return {
            "message": "No data found"
        }

    return required_json
