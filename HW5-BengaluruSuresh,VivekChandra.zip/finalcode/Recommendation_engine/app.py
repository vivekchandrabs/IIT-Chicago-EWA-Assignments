from flask import Flask, request, jsonify
from flask_cors import CORS
from product_recommendation import get_product_recommendation
from product_review import get_product_review_recommendation

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})  # Enable CORS globally

# Define routes
@app.route('/api/product-search', methods=['POST'])
def get_product():
    data = request.get_json()
    user_query = data.get('message', '')
    if not user_query:
        return jsonify({"error": "Empty message"}), 400  # Use jsonify for responses
    return get_product_recommendation(user_query)

@app.route('/api/product-reviews', methods=['POST'])
def get_review():
    data = request.get_json()
    user_query = data.get('message', '')
    if not user_query:
        return jsonify({"error": "Empty message"}), 400  # Use jsonify for responses
    return get_product_review_recommendation(user_query)

if __name__ == '__main__':
    app.run(debug=True)
