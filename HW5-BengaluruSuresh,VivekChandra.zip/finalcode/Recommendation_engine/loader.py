import random
from datetime import datetime
import json

from dotenv import load_dotenv

load_dotenv()

from openai import OpenAI
from pymongo import MongoClient
client = OpenAI()

product_categories = [
    "Smart Doorbells",
    "Smart Lighting",
    "Smart Speakers",
    "Smart Doorlocks",
    "Smart Thermostats",
]

products = [
     {
        "name": "Smart Doorbell Pro",
        "image": "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/c604a1c3-cad5-5019-a7cf-c0c773313b73/3cb059b3-e901-51c5-8425-e794cb6c299b.jpg",
    },
    {
        "name": "Secure Smart Door Lock",
        "image": "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/a307be83-8798-5790-97f1-2afe7d4981ab/19fff8e5-c8d2-5bcc-b34c-43e2ef28b80a.jpg",
    },
    {
        "name": "Echo Smart Speaker",
        "image": "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/6e899db8-3134-5a45-a7fe-19aee114218b/19fff8e5-c8d2-5bcc-b34c-43e2ef28b80a.jpg",
    },
     {
        "name": "Hue Smart Lighting Kit",
        "image": "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/2b442973-a356-5bc1-81a6-38e3a77e16b2/da03499e-9f33-5816-ada9-200494b5151a.jpg",
    },
    {
        "name": "Nest Smart Thermostat",
        "image": "https://images.thdstatic.com/productImages/98f93e48-f4b3-4d91-8032-865914be6fa8/svn/stainless-steel-google-programmable-thermostats-t3007es-e1_600.jpg",
    },
    {
        "name": "Video Smart Doorbell Plus",
        "image": "https://pisces.bbystatic.com/image2/BestBuy_US/images/products/967f0a5b-c866-44c8-8634-a80e61e9e11e.jpg",
    },
       {
        "name": "Advanced Smart Lock",
        "image": "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/ec9bab4f-2a97-5814-9e75-f9ea57ca0b64/19fff8e5-c8d2-5bcc-b34c-43e2ef28b80a.jpg",
    },
    {
        "name": "Compact Smart Speaker",
        "image": "https://shopcgx.com/cdn/shop/files/6522265cv11d.jpg?v=1708217850",
    },
    {
        "name": "Smart LED Light Bulb",
        "image": "https://www.gelighting.com/sites/default/files/styles/x_small_hq/public/image/2021-05/product-full-color.png?itok=uv5GY-FR",
    },
    {
        "name": "Eco Smart Thermostat",
        "image": "https://storage.googleapis.com/gweb-uniblog-publish-prod/images/Nest_Learning_Thermostat_4th_gen__.width-1300.jpg",
    },
    {
        "name": "360 Video Doorbell",
        "image": "https://contentgrid.thdstatic.com/hdus/en_US/DTCCOMNEW/package-1223.jpg",
    },
    {
        "name": "Keyless Smart Lock",
        "image": "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/e72a2afe-1d64-55d2-8b40-ac5f22549037/82a90d64-070d-5fcd-a04c-7847fea4842d.jpg",
    },
      {
        "name": "High-Definition Smart Speaker",
        "image": "https://i.pcmag.com/imagery/roundups/017S1tRIBIkr8Mfan0lnX4J-59..v1657221180.jpg",
    },
    {
        "name": "Adjustable Smart Light Panels",
        "image": "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/5882d149-d1ce-5b0b-af85-4d63553c594f/19fff8e5-c8d2-5bcc-b34c-43e2ef28b80a.jpg",
    },
    {
        "name": "Energy-Saving Thermostat",
        "image": "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/c3ed65f7-fbb1-5825-b04e-2a588f301732/f546042b-814f-52fd-a042-625703195baf.jpg",
    },
    {
        "name": "Premium Smart Doorbell",
        "image": "https://assets.rebelmouse.io/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpbWFnZSI6Imh0dHBzOi8vYXNzZXRzLnJibC5tcy8yNjA4OTE1MS9vcmlnaW4uanBnIiwiZXhwaXJlc19hdCI6MTc4NzcyMzAxNn0.xKgTswH47_b-QRUsr7WypoQs-VbWZNzA-yK6m_B49H4/img.jpg?coordinates=0%2C29%2C0%2C29&height=800&quality=85&width=1200",
    },
    {
        "name": "SecureTouch Smart Lock",
        "image": "https://securamsys.com/cdn/shop/products/sv-touch.jpg?v=1680198343&width=1600",
    },
    {
        "name": "Multi-Room Smart Speaker",
        "image": "https://cdn.thewirecutter.com/wp-content/media/2023/04/multiroom-wireless-speaker-2048px-9288-3x2-1.jpg?auto=webp&crop=1.91%3A1&quality=75&width=1200",
    },
    {
        "name": "Ambient Smart Lighting Strip",
        "image": "https://ae01.alicdn.com/kf/S9dfd2e03f4544267bdae9213c9f423c9y/Smart-Ambient-TV-Lighting-PC-Display-Sync-LED-Strip-Monitor-Backlight-DIY-Party-Atmosphere-Light-Ramadan.jpg",
    },
    {
        "name": "WiFi Smart Thermostat",
        "image": "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/6e7023f3-16e3-53f5-a10a-c026cd728446/19fff8e5-c8d2-5bcc-b34c-43e2ef28b80a.jpg",
    }
]

generated_products = []
review_data = []
product_id = 1
for product_idea in products:
    product_name = product_idea["name"]

    completion = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": """
            You are a very helpful AI assistant that helps the user generate the information about product ideas.
            The user will provide you with a product name, and you will generate the following
            description (should be less than 100 words but more than 50 words), 
            price should be more than 100,
            warranty_id should be a random number between 1 and 10,
            category_id should be from this list. [
                        "Smart Doorbells",
                        "Smart Lighting",
                        "Smart Speakers",
                        "Smart Doorlocks",
                        "Smart Thermostats",
                    ]
            Analyse the product name and choose the category the index of the array stars from 1 to 5 inclusive.
            Return the entire JSON object with the following
            {
                    name: "Smart Doorbell Pro",
                    category_id: 1,
                    warranty_id:
                    warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
                    price: "129.99",
                    description:
                    "Enhance your home security with the Smart Doorbell Pro, featuring crystal-clear HD video, two-way communication, and real-time motion alerts. Stay connected to your home no matter where you are, with seamless integration into your smart home ecosystem. Its sleek design ensures both functionality and style.",
                    image:
                    "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/c604a1c3-cad5-5019-a7cf-c0c773313b73/3cb059b3-e901-51c5-8425-e794cb6c299b.jpg",
                    createdAt: new Date(),
                    updatedAt: new Date(),
                    reviews: [
                        {
                        "ProductCategory": "Smart Doorbells",
                        "ProductID": 16,
                        "ProductModelName": "Premium Smart Doorbell",
                        "ProductPrice": 160,
                        "ReviewDate": "2024-11-20T07:25:13",
                        "ReviewRating": 3,
                        "ReviewText": "I had high hopes for this doorbell, but the connection issues have been a constant problem. The notifications are delayed, and I often have trouble accessing the video feed in real-time. I also have concerns about privacy, especially with how much data the device collects. Overall, it’s decent, but could be much better.",
                        "UserID": 7
                        }
                    ]
                },
             
            UserID for the review can be anything between 1 to 10.
            
            This is just an example. 
             
            And you should also generate 5 reviews for the product idea. Consider the following points for the reviews:
            Choose them depending upon the category of the product.
            The review description should be less 100 words but more than 50 words.

             1. Smart Doorbells
                o Positive: convenient, secure, real-time, reliable, clear video
                o Negative: glitchy, slow alerts, poor connection, privacy concerns
            2. Smart Doorlocks
                o Positive: secure, convenient, remote access, easy install
                o Negative: battery drain, app issues, unreliable, lock jams
            3. Smart Speakers
                o Positive: responsive, good sound, versatile, user-friendly
                o Negative: poor privacy, limited commands, connectivity issues
            4. Smart Lighting
                o Positive: customizable, energy-efficient, remote control, mood-
                enhancing
                o Negative: app problems, delay, connectivity issues, limited brightness
            5. Smart Thermostats
                o Positive: energy-saving, easy to use, efficient, remote control
                o Negative: difficult setup, temperature inaccuracy, app bugs,
                connectivity issues
             
            Return only the json object.
            Do not return any other information.
            Do not have any markdown tags in the response.
            Do not return the image, createdAt, updatedAt key value in the response.
            """},
            {
                "role": "user",
                "content": f"I have a product idea called {product_name} and the ProductID in the reviews should be {product_id}. Can you help me generate other information about it?"
            }
        ]
    )

    result = completion.choices[0].message.content
    
    result = json.loads(result)

    result["image"] = product_idea["image"]

    generated_reviews = result["reviews"]

    # Extend the review_data list with the generated reviews
    review_data.extend(generated_reviews)

    # Delete the reviews key from the result
    del result["reviews"]

    # Append the result to the generated_products list
    generated_products.append(result)

    product_id += 1

    print(product_id)


# Insert the products into the MySQL database.
import mysql.connector

conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='password',
    database='ewadb'
)

cursor = conn.cursor()

for product in generated_products:
    sql = """
    INSERT INTO Products (name, category_id, warranty_id, price, description, image, createdAt, updatedAt)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """
    values = (
        product["name"],
        product["category_id"],
        product["warranty_id"],
        product["price"],
        product["description"],
        product["image"],
        datetime.now(),
        datetime.now()
    )
    cursor.execute(sql, values)

conn.commit()
cursor.close()
conn.close()

# Insert the reviews into MongoDB.
# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['ewadb']
collection = db['product_reviews']

# Iterate over all the review_data and insert them into the product_reviews collection
for review in review_data:
    document = {
        "ProductModelName": review["ProductModelName"],
        "ProductCategory": review["ProductCategory"],
        "ProductPrice": review["ProductPrice"],
        "ProductID": review["ProductID"],
        "UserID": review["UserID"],
        "ReviewRating": review["ReviewRating"],
        "ReviewDate": review["ReviewDate"],
        "ReviewText": review["ReviewText"]
    }
    collection.insert_one(document)

# Close the MongoDB connection
client.close()

print("Reviews inserted into MongoDB")



    