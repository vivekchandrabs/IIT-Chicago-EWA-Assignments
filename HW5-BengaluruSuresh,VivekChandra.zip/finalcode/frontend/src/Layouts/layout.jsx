import React from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from '../Components/Navbar.jsx'; // Import the Navbar component

function Layout({ userType }) {
    return (
        <div>
            <Navbar userType={userType} />
            <div className="container">
                <Outlet />
            </div>
        </div>
    );
}

export default Layout;