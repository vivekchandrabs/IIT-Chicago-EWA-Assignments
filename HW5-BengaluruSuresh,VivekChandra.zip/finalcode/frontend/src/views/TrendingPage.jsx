import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function TrendingPage() {
    const [topProducts, setTopProducts] = useState({
        top_products: [],
        top_zip_products: [],
        top_liked_products: []
    });
    const navigate = useNavigate();

    const query = new URLSearchParams(location.search);
    const customerId = query.get("customer_id");
    const userType = query.get("type");

    useEffect(() => {
        fetch("http://localhost:8080/helloworld-servlet/products/top-sold")
            .then((response) => response.json())
            .then((data) => setTopProducts(data))
            .catch((error) => console.error("Error fetching top sold products:", error));
    }, []);

    const renderProductCard = (product, extraInfo) => (
        <div key={product.product_id} style={{ border: "1px solid #ccc", borderRadius: "5px", overflow: "hidden" }}>
            <img src={product.image} alt={product.name} style={{ width: "100%", height: "200px", objectFit: "cover" }} />
            <div style={{ padding: "10px" }}>
                <h3>{product.name}</h3>
                <p>${product.price.toFixed(2)}</p>
                <p>{product.description}</p>
                {extraInfo && <p>{extraInfo}</p>}
                <button
                    onClick={() => navigate(`/product/${product.product_id}?customer_id=${customerId}&type=${userType}`)}
                    style={{ backgroundColor: "red", color: "white", padding: "5px 10px", border: "none", cursor: "pointer" }}
                >
                    View Details
                </button>
            </div>
        </div>
    );

    return (
        <div style={{ padding: "20px" }}>
            <h3>Top Sold Products</h3>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "20px" }}>
                {topProducts.top_products.map(product => renderProductCard(product))}
            </div>

            <h3>Top Sold Products by Zip Code</h3>
            {topProducts.top_zip_products.map(zipProduct => (
                <div key={zipProduct.zip_code}>
                    <h4>Zip Code: {zipProduct.zip_code}</h4>
                    <p>Total Quantity Sold: {zipProduct.quantity_sold}</p>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "20px" }}>
                        {zipProduct.products.map(product =>
                            renderProductCard(product, `Quantity Sold: ${product.quantity_sold}`)
                        )}
                    </div>
                </div>
            ))}

            <h3>Top Liked Products</h3>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "20px" }}>
                {topProducts.top_liked_products.map(product =>
                    renderProductCard(product, `Likes: ${product.like_count}`)
                )}
            </div>
        </div>
    );
}

export default TrendingPage;