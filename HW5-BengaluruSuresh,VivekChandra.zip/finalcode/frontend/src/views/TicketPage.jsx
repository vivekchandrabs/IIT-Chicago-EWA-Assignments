import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

function TicketPage() {
    const [showForm, setShowForm] = useState(false);
    const [showStatusCheck, setShowStatusCheck] = useState(false);
    const [ticketDescription, setTicketDescription] = useState('');
    const [image, setImage] = useState(null);
    const [statusMessage, setStatusMessage] = useState('');
    const [ticketNumber, setTicketNumber] = useState('');
    const [ticketStatus, setTicketStatus] = useState(null);

    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const customerId = searchParams.get('customer_id');

    const handleOpenTicket = () => {
        setShowForm(true);
        setShowStatusCheck(false);
        setStatusMessage('');
        setTicketStatus(null);
    };

    const handleCheckStatus = () => {
        setShowForm(false);
        setShowStatusCheck(true);
        setStatusMessage('');
        setTicketStatus(null);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append('ticket_description', ticketDescription);
        formData.append('customer_id', customerId);
        if (image) {
            formData.append('image', image);
        }

        try {
            const response = await fetch('http://localhost:8080/helloworld-servlet/api/create-ticket', {
                method: 'POST',
                body: formData,
            });

            const data = await response.json();

            if (response.ok) {
                setStatusMessage(data.message);
                setTicketNumber(data.ticket_number);
                setShowForm(false);
                setTicketDescription('');
                setImage(null);
            } else {
                setStatusMessage('Failed to create ticket. Please try again.');
            }
        } catch (error) {
            setStatusMessage('An error occurred. Please try again later.');
        }
    };

    const handleStatusCheck = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch(`http://localhost:8080/helloworld-servlet/api/ticket-status?ticket_number=${ticketNumber}`);
            const data = await response.json();

            if (response.ok) {
                setTicketStatus(data);
            } else {
                setStatusMessage('Failed to fetch ticket status. Please try again.');
            }
        } catch (error) {
            setStatusMessage('An error occurred. Please try again later.');
        }
    };

    return (
        <div className="container mt-5">
            <h1 className="text-center mb-4">Ticket Management</h1>
            <div className="d-flex justify-content-center mb-4">
                <button className="btn btn-primary me-2" onClick={handleOpenTicket}>Open Ticket</button>
                <button className="btn btn-secondary" onClick={handleCheckStatus}>Check Status</button>
            </div>

            {showForm && (
                <div className="card shadow">
                    <div className="card-body">
                        <h2 className="card-title text-center mb-4">Open a New Ticket</h2>
                        <form onSubmit={handleSubmit}>
                            <div className="mb-3">
                                <label htmlFor="ticketDescription" className="form-label">Ticket Description:</label>
                                <textarea
                                    className="form-control"
                                    id="ticketDescription"
                                    rows="4"
                                    value={ticketDescription}
                                    onChange={(e) => setTicketDescription(e.target.value)}
                                    required
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="image" className="form-label">Upload Image:</label>
                                <input
                                    type="file"
                                    className="form-control"
                                    id="image"
                                    accept="image/*"
                                    onChange={(e) => setImage(e.target.files[0])}
                                />
                            </div>
                            <div className="text-center">
                                <button type="submit" className="btn btn-success">Submit Ticket</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {showStatusCheck && (
                <div className="card shadow">
                    <div className="card-body">
                        <h2 className="card-title text-center mb-4">Check Ticket Status</h2>
                        <form onSubmit={handleStatusCheck}>
                            <div className="mb-3">
                                <label htmlFor="ticketNumber" className="form-label">Ticket Number:</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="ticketNumber"
                                    value={ticketNumber}
                                    onChange={(e) => setTicketNumber(e.target.value)}
                                    required
                                />
                            </div>
                            <div className="text-center">
                                <button type="submit" className="btn btn-info">Check Status</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {statusMessage && (
                <div className="alert alert-info mt-4" role="alert">
                    {statusMessage}: {ticketNumber}
                </div>
            )}

            {ticketStatus && (
                <div className="card shadow mt-4">
                    <div className="card-body">
                        <h3 className="card-title text-center mb-4">Ticket Information</h3>
                        <div className="row">
                            <div className="col-md-4">
                                <p className="fw-bold">Ticket Number:</p>
                                <p className="badge bg-primary fs-5">{ticketStatus.ticket_number}</p>
                            </div>
                            <div className="col-md-4">
                                <p className="fw-bold">Status:</p>
                                <p>
                                    {ticketStatus.status.charAt(0).toUpperCase() + ticketStatus.status.slice(1)}
                                </p>
                            </div>
                            <div className="col-md-4">
                                <p className="fw-bold">Description:</p>
                                <p>{ticketStatus.ticket_description}</p>
                            </div>
                        </div>
                    </div>
                </div>
            )
            }
        </div >
    );
}

export default TicketPage;