import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

function AuthPage() {
  const [loginData, setLoginData] = useState({ name: "", email: "" });
  const [signupData, setSignupData] = useState({
    name: "",
    email: "",
    customerType: "salesmen",
  });
  const navigate = useNavigate();

  const handleLoginChange = (e) => {
    const { name, value } = e.target;
    setLoginData({ ...loginData, [name]: value });
  };

  const handleSignupChange = (e) => {
    const { name, value } = e.target;
    setSignupData({ ...signupData, [name]: value });
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:8080/helloworld-servlet/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(loginData),
      });
      const result = await response.json();
      console.log("Login Response:", result);
      navigate(`/products?customer_id=${result.id}&type=${result.type}`);
    } catch (error) {
      console.error("Login Error:", error);
    }
  };

  const handleSignupSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:8080/helloworld-servlet/customer/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: signupData.name,
          email: signupData.email,
          type: signupData.customerType,
        }),
      });
      const result = await response.json();
      console.log("Signup Response:", result);
      navigate(`/products?customer_id=${result.id}&type=${result.type}`);
    } catch (error) {
      console.error("Signup Error:", error);
    }
  };

  return (
    <div className="container d-flex justify-content-around py-4">
      <div className="border p-4 rounded" style={{ width: "300px" }}>
        <h2 className="text-danger">Login</h2>
        <form onSubmit={handleLoginSubmit}>
          <div className="mb-3">
            <label className="form-label">Name:</label>
            <input
              type="text"
              name="name"
              value={loginData.name}
              onChange={handleLoginChange}
              className="form-control"
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Email:</label>
            <input
              type="email"
              name="email"
              value={loginData.email}
              onChange={handleLoginChange}
              className="form-control"
            />
          </div>
          <button
            type="submit"
            className="btn btn-danger"
          >
            Login
          </button>
        </form>
      </div>
      <div className="border p-4 rounded" style={{ width: "300px" }}>
        <h2 className="text-danger">Sign Up</h2>
        <form onSubmit={handleSignupSubmit}>
          <div className="mb-3">
            <label className="form-label">Name:</label>
            <input
              type="text"
              name="name"
              value={signupData.name}
              onChange={handleSignupChange}
              className="form-control"
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Email:</label>
            <input
              type="email"
              name="email"
              value={signupData.email}
              onChange={handleSignupChange}
              className="form-control"
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Type of Customer:</label>
            <select
              name="customerType"
              value={signupData.customerType}
              onChange={handleSignupChange}
              className="form-select"
            >
              <option value="salesmen">Salesmen</option>
              <option value="customer">Customer</option>
              <option value="manager">Manager</option>
            </select>
          </div>
          <button
            type="submit"
            className="btn btn-danger"
          >
            Sign Up
          </button>
        </form>
      </div>
    </div>
  );
}

export default AuthPage;