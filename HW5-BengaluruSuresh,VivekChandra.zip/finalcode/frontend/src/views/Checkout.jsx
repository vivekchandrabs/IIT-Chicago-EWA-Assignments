import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

function CheckoutPage() {
    const [cartItems, setCartItems] = useState([]);
    const [paymentDetails, setPaymentDetails] = useState({
        firstName: "",
        lastName: "",
        address: "",
        creditCardNumber: "",
        expiry: "",
        cvv: "",
        zipCode: ""
    });
    const location = useLocation();
    const navigate = useNavigate();
    const query = new URLSearchParams(location.search);
    const customerId = query.get("customer_id");
    const userType = query.get("type");

    useEffect(() => {
        fetch(`http://localhost:8080/helloworld-servlet/cart/get?customer_id=${customerId}`)
            .then((response) => response.json())
            .then((data) => setCartItems(data))
            .catch((error) => console.error("Error fetching cart items:", error));
    }, [customerId]);

    const calculateTotal = () => {
        return cartItems.reduce((total, item) => total + item.product.price * item.quantity, 0).toFixed(2);
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setPaymentDetails({ ...paymentDetails, [name]: value });
    };

    const handlePayment = async () => {
        const products = cartItems.map(item => ({
            product_id: item.product.id,
            quantity: item.quantity
        }));

        const totalPayment = calculateTotal();

        try {
            const response = await fetch("http://localhost:8080/helloworld-servlet/order/create", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    customer_id: customerId,
                    customer_name: `${paymentDetails.firstName} ${paymentDetails.lastName}`,
                    credit_card: paymentDetails.creditCardNumber,
                    zip_code: paymentDetails.zipCode,
                    address: paymentDetails.address,
                    products: products,
                    payment: totalPayment,
                }),
            });

            if (response.ok) {
                alert("Your order has been placed.");
                navigate(`/orders?customer_id=${customerId}&type=${userType}`);
            } else {
                alert("Failed to place the order.");
            }
        } catch (error) {
            console.error("Payment Error:", error);
        }
    };

    return (
        <div className="container py-4">
            <div className="row">
                <div className="col-md-8">
                    <h2>Cart Items</h2>
                    {cartItems.map((item) => (
                        <div key={item.product.id} className="card mb-3">
                            <div className="row g-0">
                                <div className="col-md-4">
                                    <img src={item.product.image} alt={item.product.name} className="img-fluid rounded-start" />
                                </div>
                                <div className="col-md-8">
                                    <div className="card-body">
                                        <h5 className="card-title">{item.product.name}</h5>
                                        <p className="card-text">Price: ${item.product.price.toFixed(2)}</p>
                                        <p className="card-text">Quantity: {item.quantity}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                    <h3>Total: ${calculateTotal()}</h3>
                </div>
                <div className="col-md-4">
                    <h2>Payment</h2>
                    <form>
                        <div className="mb-3">
                            <label className="form-label">First Name</label>
                            <input type="text" name="firstName" value={paymentDetails.firstName} onChange={handleInputChange} className="form-control" />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Last Name</label>
                            <input type="text" name="lastName" value={paymentDetails.lastName} onChange={handleInputChange} className="form-control" />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Address</label>
                            <input type="text" name="address" value={paymentDetails.address} onChange={handleInputChange} className="form-control" />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Zip Code</label>
                            <input type="text" name="zipCode" value={paymentDetails.zipCode} onChange={handleInputChange} className="form-control" />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Credit Card Number</label>
                            <input type="text" name="creditCardNumber" value={paymentDetails.creditCardNumber} onChange={handleInputChange} className="form-control" />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">Expiry</label>
                            <input type="date" name="expiry" value={paymentDetails.expiry} onChange={handleInputChange} className="form-control" />
                        </div>
                        <div className="mb-3">
                            <label className="form-label">CVV</label>
                            <input type="text" name="cvv" value={paymentDetails.cvv} onChange={handleInputChange} className="form-control" />
                        </div>
                        <button type="button" onClick={handlePayment} className="btn btn-success w-100">
                            Pay
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default CheckoutPage;