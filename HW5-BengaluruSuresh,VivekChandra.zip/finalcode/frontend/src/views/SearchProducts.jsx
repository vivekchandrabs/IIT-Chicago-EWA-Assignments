import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from "react-router-dom";

const LoadingSpinner = () => (
    <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '50px'
    }}>
        <div style={{
            width: '30px',
            height: '30px',
            border: '3px solid #f3f3f3',
            borderTop: '3px solid #3498db',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite'
        }} />
    </div>
);

const ProductSearch = () => {
    const [searchQuery, setSearchQuery] = useState('');
    const [products, setProducts] = useState([]);
    const navigate = useNavigate();
    const location = useLocation();
    const [isLoading, setIsLoading] = useState(false);

    const query = new URLSearchParams(location.search);
    const customerId = query.get("customer_id");
    const userType = query.get("type");

    const handleSearch = async () => {
        setIsLoading(true);
        try {
            const response = await fetch('http://127.0.0.1:5000/api/product-search', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: searchQuery }),
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();
            setProducts(data);
        } catch (error) {
            console.error('Error fetching products:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const renderProductCard = (product) => (
        <div key={product.id} style={{ border: "1px solid #ccc", borderRadius: "5px", overflow: "hidden", margin: "10px" }}>
            <img src={product.image} alt={product.name} style={{ width: "100%", height: "200px", objectFit: "cover" }} />
            <div style={{ padding: "10px" }}>
                <h3>{product.name}</h3>
                <p>${parseFloat(product.price).toFixed(2)}</p>
                <p>{product.description}</p>
                <button
                    onClick={() => navigate(`/product/${product.id}?customer_id=${customerId}&type=${userType}`)}
                    style={{ backgroundColor: "red", color: "white", padding: "5px 10px", border: "none", cursor: "pointer" }}
                >
                    View Details
                </button>
            </div>
        </div>
    );

    return (
        <div>
            <h1>Search Products</h1>
            <div style={{ marginBottom: "20px" }}>
                <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Enter search query"
                    style={{ padding: "10px", marginRight: "10px", width: "70%" }}
                />
                <button
                    onClick={handleSearch}
                    style={{ padding: "5px 10px", backgroundColor: "blue", color: "white", border: "none", cursor: "pointer" }}
                    disabled={isLoading}
                >
                    {isLoading ? 'Searching...' : 'Recommend Product'}
                </button>
            </div>
            {isLoading ? (
                <LoadingSpinner />
            ) : (
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))", gap: "20px" }}>
                    {products.map(renderProductCard)}
                </div>
            )}
        </div>
    );
};

export default ProductSearch;