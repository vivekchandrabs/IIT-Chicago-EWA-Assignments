import React, { useState } from 'react';

const ReviewSearch = () => {
    const [searchQuery, setSearchQuery] = useState('');
    const [products, setProducts] = useState([]);
    const [isLoading, setIsLoading] = useState(false);

    const handleSearch = async () => {
        setIsLoading(true);
        try {
            const response = await fetch('http://127.0.0.1:5000/api/product-reviews', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: searchQuery }),
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();
            setProducts(data);
        } catch (error) {
            console.error('Error fetching products:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const renderProductCard = (product) => (
        <div key={product.id} style={{ border: "1px solid #ccc", borderRadius: "5px", overflow: "hidden", margin: "20px 0", padding: "20px" }}>
            <img src={product.image} alt={product.name} style={{ width: "100%", height: "300px", objectFit: "cover" }} />
            <div style={{ padding: "10px" }}>
                <h2>{product.name}</h2>
                <p><strong>Price:</strong> ${parseFloat(product.price).toFixed(2)}</p>
                <p><strong>Description:</strong> {product.description}</p>
                <p><strong>Category ID:</strong> {product.category_id}</p>
                <p><strong>Stock:</strong> {product.stock > 0 ? 'In Stock' : 'Out of Stock'}</p>
                <p><strong>Warranty ID:</strong> {product.warranty_id}</p>

                <h3>Reviews</h3>
                {product.reviews && product.reviews.length > 0 ? (
                    product.reviews.map((review, index) => (
                        <div key={index} style={{ border: "1px solid #eee", padding: "10px", margin: "10px 0" }}>
                            <p><strong>Rating:</strong> {review.ReviewRating}/5</p>
                            <p><strong>Date:</strong> {new Date(review.ReviewDate).toLocaleDateString()}</p>
                            <p><strong>Review:</strong> {review.ReviewText}</p>
                        </div>
                    ))
                ) : (
                    <p>No reviews available</p>
                )}
            </div>
        </div>
    );

    return (
        <div style={{ maxWidth: "800px", margin: "0 auto", padding: "20px" }}>
            <h1>Search Reviews</h1>
            <div style={{ marginBottom: "20px" }}>
                <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Enter search query"
                    style={{ padding: "10px", marginRight: "10px", width: "70%" }}
                />
                <button
                    onClick={handleSearch}
                    style={{ padding: "10px 20px", backgroundColor: "blue", color: "white", border: "none", cursor: "pointer" }}
                    disabled={isLoading}
                >
                    {isLoading ? 'Searching...' : 'Search'}
                </button>
            </div>
            {isLoading ? (
                <div style={{ textAlign: "center", padding: "20px" }}>
                    <p>Loading...</p>
                </div>
            ) : (
                <div>
                    {products.map(renderProductCard)}
                </div>
            )}
        </div>
    );
};

export default ReviewSearch;