"use strict";
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("Products", {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      name: {
        type: Sequelize.STRING,
        allowNull: true, // Nullable
      },
      category_id: {
        type: Sequelize.INTEGER,
        references: {
          model: "Categories",
          key: "id",
        },
        onDelete: "CASCADE",
        allowNull: true, // Nullable
      },
      warranty_id: {
        type: Sequelize.INTEGER,
        references: {
          model: "Warranties",
          key: "id",
        },
        onDelete: "SET NULL",
        allowNull: true, // Nullable
      },
      price: {
        type: Sequelize.DECIMAL,
        allowNull: true, // Nullable
      },
      description: {
        type: Sequelize.TEXT,
        allowNull: true, // Nullable
      },
      image: {
        type: Sequelize.TEXT,
        allowNull: true, // Nullable
      },
      like_count: {
        type: Sequelize.INTEGER,
        allowNull: true, // Nullable
        defaultValue: 0,
      },
      stock: {
        type: Sequelize.INTEGER,
        allowNull: true, // Nullable
        defaultValue: 0,
      },
      has_rebate: {
        type: Sequelize.BOOLEAN,
        allowNull: true, // Nullable
        defaultValue: false,
      },
      rebate: {
        type: Sequelize.DECIMAL,
        allowNull: true, // Nullable
      },
      createdAt: {
        allowNull: true, // Nullable
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
        allowNull: true, // Nullable
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("Products");
  },
};
