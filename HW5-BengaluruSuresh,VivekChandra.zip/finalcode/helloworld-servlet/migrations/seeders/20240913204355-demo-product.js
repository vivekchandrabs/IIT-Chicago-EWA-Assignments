"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Fetch existing category and warranty IDs
    const categories = await queryInterface.sequelize.query(
      "SELECT id FROM Categories",
      { type: Sequelize.QueryTypes.SELECT }
    );

    const warranties = await queryInterface.sequelize.query(
      "SELECT id FROM Warranties",
      { type: Sequelize.QueryTypes.SELECT }
    );

    // Map IDs to arrays
    const categoryIds = categories.map((c) => c.id);
    const warrantyIds = warranties.map((w) => w.id);

    // Check if there are categories and warranties to choose from
    if (categoryIds.length === 0 || warrantyIds.length === 0) {
      throw new Error(
        "No categories or warranties available to populate products."
      );
    }

    // Define an array of realistic product data with valid image URLs
    const products = [
      {
        name: "Smart Doorbell Pro",
        category_id: 1,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "129.99",
        description:
          "Enhance your home security with the Smart Doorbell Pro, featuring crystal-clear HD video, two-way communication, and real-time motion alerts. Stay connected to your home no matter where you are, with seamless integration into your smart home ecosystem. Its sleek design ensures both functionality and style.",
        image:
          "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/c604a1c3-cad5-5019-a7cf-c0c773313b73/3cb059b3-e901-51c5-8425-e794cb6c299b.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Secure Smart Door Lock",
        category_id: 4,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "99.99",
        description:
          "Experience unmatched security and convenience with the Secure Smart Door Lock. This innovative lock allows you to unlock your door remotely, share virtual keys with family, and receive real-time tamper alerts. Its durable build and simple installation make it a must-have for modern homes.",
        image:
          "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/a307be83-8798-5790-97f1-2afe7d4981ab/19fff8e5-c8d2-5bcc-b34c-43e2ef28b80a.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Echo Smart Speaker",
        category_id: 3,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "59.99",
        description:
          "The Echo Smart Speaker delivers rich audio quality and responds instantly to your voice commands. Control your smart home devices, stream music, and get updates on news or weather—all hands-free. With its sleek design and robust capabilities, it's perfect for every room in your home.",
        image:
          "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/6e899db8-3134-5a45-a7fe-19aee114218b/19fff8e5-c8d2-5bcc-b34c-43e2ef28b80a.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Hue Smart Lighting Kit",
        category_id: 2,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "79.99",
        description:
          "Transform your space with the Hue Smart Lighting Kit, offering millions of color options and remote control from your smartphone. Set schedules, enhance moods, and save energy with these innovative, customizable lights that seamlessly integrate with major smart home platforms.",
        image:
          "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/2b442973-a356-5bc1-81a6-38e3a77e16b2/da03499e-9f33-5816-ada9-200494b5151a.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Nest Smart Thermostat",
        category_id: 5,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "119.99",
        description:
          "The Nest Smart Thermostat is a game-changer for energy efficiency, learning your habits to automatically adjust temperatures and save energy. Control it remotely with your smartphone, or use voice commands for added convenience. Its sleek, modern design complements any home decor.",
        image:
          "https://images.thdstatic.com/productImages/98f93e48-f4b3-4d91-8032-865914be6fa8/svn/stainless-steel-google-programmable-thermostats-t3007es-e1_600.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Video Smart Doorbell Plus",
        category_id: 1,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "149.99",
        description:
          "The Video Smart Doorbell Plus offers superior home security with its wide-angle HD camera, advanced motion sensors, and instant notifications. Stay connected to your doorstep via your smartphone, ensuring you never miss a visitor or delivery, even when you're away.",
        image:
          "https://pisces.bbystatic.com/image2/BestBuy_US/images/products/967f0a5b-c866-44c8-8634-a80e61e9e11e.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Advanced Smart Lock",
        category_id: 4,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "89.99",
        description:
          "Upgrade your home security with the Advanced Smart Lock. It features state-of-the-art encryption, remote access via app, and quick keyless entry. Designed for reliability and style, this lock combines modern technology with ease of use for peace of mind.",
        image:
          "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/ec9bab4f-2a97-5814-9e75-f9ea57ca0b64/19fff8e5-c8d2-5bcc-b34c-43e2ef28b80a.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Compact Smart Speaker",
        category_id: 3,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "49.99",
        description:
          "Small in size but big on features, the Compact Smart Speaker offers high-quality audio and voice-activated controls. Manage smart devices, set reminders, or play your favorite playlists, all with simple voice commands, making your daily life more convenient.",
        image:
          "https://shopcgx.com/cdn/shop/files/6522265cv11d.jpg?v=1708217850",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Smart LED Light Bulb",
        category_id: 2,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "24.99",
        description:
          "Brighten your home with the Smart LED Light Bulb, offering adjustable brightness, vibrant color options, and energy-efficient performance. Control your lighting with ease through voice commands or your smartphone, creating the perfect ambiance for any occasion.",
        image:
          "https://www.gelighting.com/sites/default/files/styles/x_small_hq/public/image/2021-05/product-full-color.png?itok=uv5GY-FR",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Eco Smart Thermostat",
        category_id: 5,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "129.99",
        description:
          "Optimize your home's energy use with the Eco Smart Thermostat. Designed to save you money while maintaining comfort, it adapts to your schedule and lets you control temperatures from anywhere with your smartphone or voice assistant.",
        image:
          "https://storage.googleapis.com/gweb-uniblog-publish-prod/images/Nest_Learning_Thermostat_4th_gen__.width-1300.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "360 Video Doorbell",
        category_id: 1,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "179.99",
        description:
          "Monitor every angle of your doorstep with the 360 Video Doorbell. Its panoramic HD camera and motion detection ensure no blind spots, while real-time alerts keep you informed wherever you are. Designed for seamless integration into your smart home system, it adds both security and convenience.",
        image:
          "https://contentgrid.thdstatic.com/hdus/en_US/DTCCOMNEW/package-1223.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Keyless Smart Lock",
        category_id: 4,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "89.99",
        description:
          "The Keyless Smart Lock offers advanced convenience and security with remote access and customizable user codes. Its tamper-resistant design and app integration make it easy to manage access to your home, providing peace of mind wherever you go.",
        image:
          "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/e72a2afe-1d64-55d2-8b40-ac5f22549037/82a90d64-070d-5fcd-a04c-7847fea4842d.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "High-Definition Smart Speaker",
        category_id: 3,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "129.99",
        description:
          "Enjoy crisp, immersive audio with the High-Definition Smart Speaker. With intelligent voice recognition and seamless connectivity to smart devices, this speaker is perfect for streaming music, controlling appliances, or managing your daily schedule effortlessly.",
        image:
          "https://i.pcmag.com/imagery/roundups/017S1tRIBIkr8Mfan0lnX4J-59..v1657221180.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Adjustable Smart Light Panels",
        category_id: 2,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "99.99",
        description:
          "Transform any room with Adjustable Smart Light Panels that offer vibrant colors, customizable designs, and remote control. Create dynamic lighting scenes to enhance your home decor or improve productivity, all while saving energy.",
        image:
          "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/5882d149-d1ce-5b0b-af85-4d63553c594f/19fff8e5-c8d2-5bcc-b34c-43e2ef28b80a.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Energy-Saving Thermostat",
        category_id: 5,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "149.99",
        description:
          "The Energy-Saving Thermostat intelligently adjusts your home's temperature to reduce energy consumption without compromising comfort. With features like remote access and compatibility with voice assistants, managing your environment has never been easier.",
        image:
          "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/c3ed65f7-fbb1-5825-b04e-2a588f301732/f546042b-814f-52fd-a042-625703195baf.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Premium Smart Doorbell",
        category_id: 1,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "159.99",
        description:
          "Ensure ultimate security and convenience with the Premium Smart Doorbell. Equipped with an ultra-clear camera, motion detection, and real-time alerts, it lets you monitor visitors and deliveries with ease from your smartphone or smart assistant.",
        image:
          "https://assets.rebelmouse.io/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpbWFnZSI6Imh0dHBzOi8vYXNzZXRzLnJibC5tcy8yNjA4OTE1MS9vcmlnaW4uanBnIiwiZXhwaXJlc19hdCI6MTc4NzcyMzAxNn0.xKgTswH47_b-QRUsr7WypoQs-VbWZNzA-yK6m_B49H4/img.jpg?coordinates=0%2C29%2C0%2C29&height=800&quality=85&width=1200",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "SecureTouch Smart Lock",
        category_id: 4,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "119.99",
        description:
          "The SecureTouch Smart Lock combines biometric security with modern convenience. Use your fingerprint, app, or key code to unlock your door effortlessly. Its durable, tamper-proof design ensures your home stays safe at all times.",
        image:
          "https://securamsys.com/cdn/shop/products/sv-touch.jpg?v=1680198343&width=1600",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Multi-Room Smart Speaker",
        category_id: 3,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "99.99",
        description:
          "Fill your home with music using the Multi-Room Smart Speaker. Its robust sound system and voice assistant integration let you control playback, adjust settings, and link multiple speakers for a synchronized audio experience throughout your house.",
        image:
          "https://cdn.thewirecutter.com/wp-content/media/2023/04/multiroom-wireless-speaker-2048px-9288-3x2-1.jpg?auto=webp&crop=1.91%3A1&quality=75&width=1200",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Ambient Smart Lighting Strip",
        category_id: 2,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "39.99",
        description:
          "Create stunning visual effects with the Ambient Smart Lighting Strip. Perfect for mood lighting or enhancing decor, it offers vibrant color options, dimming capabilities, and smart controls through apps or voice assistants.",
        image:
          "https://ae01.alicdn.com/kf/S9dfd2e03f4544267bdae9213c9f423c9y/Smart-Ambient-TV-Lighting-PC-Display-Sync-LED-Strip-Monitor-Backlight-DIY-Party-Atmosphere-Light-Ramadan.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "WiFi Smart Thermostat",
        category_id: 5,
        warranty_id:
          warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "109.99",
        description:
          "The WiFi Smart Thermostat helps you save energy and stay comfortable with its intuitive controls and real-time updates. Set schedules, monitor usage, and adjust temperatures remotely via your smartphone or voice assistant.",
        image:
          "https://d2u1z1lopyfwlx.cloudfront.net/thumbnails/6e7023f3-16e3-53f5-a10a-c026cd728446/19fff8e5-c8d2-5bcc-b34c-43e2ef28b80a.jpg",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    // Insert the products
    await queryInterface.bulkInsert("Products", products, {});
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete("Products", null, {});
  },
};
