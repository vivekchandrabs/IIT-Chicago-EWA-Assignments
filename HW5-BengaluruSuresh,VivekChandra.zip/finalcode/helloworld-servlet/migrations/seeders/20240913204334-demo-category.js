"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert("Categories", [
      { name: "Smart Doorbells", createdAt: new Date(), updatedAt: new Date() },
      { name: "Smart Lighting", createdAt: new Date(), updatedAt: new Date() },
      { name: "Smart Speakers", createdAt: new Date(), updatedAt: new Date() },
      { name: "Smart Doorlocks", createdAt: new Date(), updatedAt: new Date() },
      {
        name: "Smart Thermostats",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete("Categories", null, {});
  },
};
