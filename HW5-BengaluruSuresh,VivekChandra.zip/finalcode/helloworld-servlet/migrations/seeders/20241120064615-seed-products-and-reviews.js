"use strict";

const { Op } = require("sequelize");

module.exports = {
  async up(queryInterface, Sequelize) {
    // Fetch all products from the database
    const products = await queryInterface.sequelize.query(
      "SELECT id, name, category_id, price FROM Products",
      { type: Sequelize.QueryTypes.SELECT }
    );

    const users = await queryInterface.sequelize.query(
      "SELECT id FROM Customers",
      {
        type: Sequelize.QueryTypes.SELECT,
      }
    );

    const reviews = [];
    const now = new Date();

    // Review templates based on category
    const reviewTemplates = {
      1: {
        // Smart Doorbells
        positives: [
          "The real-time motion alerts make this doorbell an essential part of my security setup. I can always see who's at the door no matter where I am, and the video quality is excellent. It's incredibly reliable, and the seamless integration with my other smart devices makes it easy to manage everything from one place.",
          "Fantastic video quality and reliable connection make this doorbell an excellent choice for home security. I love that I can view footage in HD and communicate with visitors instantly. The alerts are timely, and it's easy to install. This product truly gives me peace of mind knowing I'm always connected to my front door.",
          "I love the convenience of being able to see who's at my door remotely, even when I'm not home. The video clarity is superb, and the motion alerts are always on time. It integrates perfectly with my smart home system, making it a must-have for anyone looking to enhance their security.",
          "This smart doorbell has made monitoring my front door so much easier. The video quality is clear, even at night, and the two-way audio feature allows me to communicate with anyone at the door. The app is straightforward, and notifications are quick, ensuring I'm always informed no matter where I am.",
          "This doorbell has been a great addition to my home. The integration with my existing smart devices was easy, and the video quality is exceptional. I also appreciate the real-time motion alerts and the fact that I can control it all from my smartphone. It's convenient, reliable, and very secure.",
        ],
        negatives: [
          "While the video quality is fantastic, the notifications can be delayed at times, which can be frustrating if you're expecting someone. Also, the connection drops occasionally, and that can be an issue when trying to communicate with visitors. I hope these issues are addressed in future updates.",
          "There are moments when the app becomes unresponsive, and I have to restart it. The video feed sometimes takes a while to load, and the connection drops occasionally, which makes it less reliable. These glitches are noticeable and could use improvement, especially considering the price of the product.",
          "I had high hopes for this doorbell, but the connection issues have been a constant problem. The notifications are delayed, and I often have trouble accessing the video feed in real-time. I also have concerns about privacy, especially with how much data the device collects. Overall, it’s decent, but could be much better.",
          "While the doorbell works well most of the time, there are moments when it becomes slow to respond, especially when there's motion detected. The video feed can also freeze, which defeats the purpose of having a real-time security system. I would recommend it, but it’s not flawless.",
          "I like the idea of this doorbell, but it’s not without its flaws. The app occasionally crashes, and there are delays with notifications. Sometimes it takes too long for the doorbell to start recording, which means I miss crucial moments. It's good, but needs refinement.",
        ],
      },
      2: {
        // Smart Doorlocks
        positives: [
          "This smart lock is incredibly convenient. I can lock and unlock my door remotely from anywhere, which is perfect for letting guests in or securing my home when I’m away. It was simple to install, and the remote access feature works flawlessly. It’s a game-changer for anyone looking for added security and convenience.",
          "I absolutely love the ease of use with this smart lock. The installation was straightforward, and I can lock or unlock my door from my phone, no matter where I am. It provides added peace of mind knowing my home is always secure, and the design is sleek and modern, fitting perfectly with my home’s aesthetic.",
          "This smart door lock is fantastic. It integrates seamlessly with my smart home system, and I can easily manage access for family and friends. The remote access feature is a lifesaver when I’m away from home, and the convenience of not needing physical keys is something I didn’t realize I needed until now.",
          "The smart door lock has been a huge convenience. Installation was quick, and the app interface is intuitive. I can lock or unlock my door remotely, which is useful for letting in family or guests when I’m not home. The security features make me feel much safer, and I’ve never had an issue with it.",
          "I’ve been using this smart lock for several months now, and I’m still impressed. It’s very easy to install, and the remote access feature works reliably. I can lock and unlock the door without needing to worry about losing keys. It’s a great security addition to my home.",
        ],
        negatives: [
          "While I love the convenience of this smart lock, the battery drains much faster than expected. I find myself having to recharge it every few weeks, which is a bit of a hassle. Additionally, the app sometimes struggles to connect to the lock, making it frustrating to use when I need it most.",
          "The smart lock is generally great, but I’ve encountered issues with it jamming on occasion. It’s especially frustrating when I need to quickly enter or exit my home, and the lock won’t open. The app also has some connectivity issues, making it unreliable at times. Despite these problems, it’s still a good product overall.",
          "While the lock itself works fine, the app can be glitchy at times. I’ve had problems with it not recognizing the lock, requiring a reset or reconnecting. Additionally, the battery drains quickly, and I’ve had to charge it more often than I expected. It’s a good product, but I hope these issues get fixed.",
          "I’ve had mixed experiences with this lock. The battery drains faster than I’d like, and sometimes the app doesn’t respond as expected. I’ve also had the lock jam a few times, making it a little stressful when I’m in a rush. The installation was easy, though, so that’s a positive.",
          "The smart lock works well, but it’s not without its issues. The battery life is too short, and I’ve experienced issues with the app disconnecting from the lock. It’s a convenient feature, but I’ve had moments where it was unreliable, which is concerning when it comes to security.",
        ],
      },
      3: {
        // Smart Speakers
        positives: [
          "The sound quality is impressive for such a compact speaker. I love how responsive the voice commands are, and it's a breeze to control all my smart devices through it. The integration with other devices is flawless, and I can stream music, control lights, and even adjust the thermostat all with my voice.",
          "This speaker delivers great sound and integrates seamlessly with my home automation system. The setup was quick and simple, and the voice assistant works flawlessly. It’s a great all-in-one solution for anyone who wants to streamline their smart home experience, and it fills my home with rich sound.",
          "I’ve been using this smart speaker for a while now, and it’s been fantastic. The voice recognition is spot-on, and the audio quality is amazing, even at high volumes. It’s perfect for music, podcasts, and even controlling smart home devices. It makes my daily routine so much easier and more efficient.",
          "I really appreciate how easy it is to control all my smart devices with this speaker. The sound quality is fantastic for such a small device, and I love the ability to set timers, play music, and ask for weather updates just by speaking. It’s a great addition to my home.",
          "This smart speaker has been a game-changer for me. The sound quality is excellent, and it’s incredibly responsive. Whether I’m asking about the weather or playing my favorite playlist, the speaker always gets it right. I also love that it integrates well with all my smart home gadgets.",
        ],
        negatives: [
          "I’ve noticed some connectivity issues with the speaker, especially when trying to control other smart devices. The sound quality could be better at higher volumes, as it tends to distort a little. The speaker also sometimes misses voice commands, which can be frustrating during use.",
          "The speaker is good, but it has some limitations. The voice assistant doesn't always respond to commands accurately, especially when there’s background noise. Additionally, the connectivity can be spotty at times, and it tends to lag when switching between tasks. It's still a great product overall, but not perfect.",
          "While the sound is good, it’s not as rich as I had hoped. The voice recognition also has some issues, as it sometimes struggles to understand commands. Additionally, there are occasional connectivity problems when linking with other smart devices, which is a little frustrating.",
          "I love the functionality, but there are some downsides. The connectivity can sometimes be slow, especially when trying to pair with other smart home devices. The voice recognition is also hit or miss at times, especially when there's a lot of background noise.",
          "The speaker itself works fine, but I've had some issues with it disconnecting from the Wi-Fi network. Sometimes, the audio is delayed when streaming, and the voice assistant can be slow to respond to commands, especially when multiple people are speaking.",
        ],
      },
      4: {
        // Smart Lighting
        positives: [
          "The smart lighting system is incredibly easy to set up and control. I can adjust the brightness and color temperature of each bulb individually, or create different lighting scenes for various moods. The app works smoothly, and it integrates perfectly with my existing smart home system. It’s an easy way to upgrade your home’s lighting.",
          "These smart lights are exactly what I needed to brighten up my space. The installation was simple, and I love that I can change the colors with just a tap. I use them for ambiance during movie nights and even have them set to a schedule. It’s a great way to add both functionality and style.",
          "The color-changing feature is a game-changer! These smart lights allow me to set the perfect mood for any occasion. Whether I’m hosting a dinner party or just relaxing, I can adjust the lighting to match the atmosphere. The integration with my smart home system is flawless, and I love the convenience.",
          "I’ve been using these smart bulbs for a while now, and they’ve transformed the way I light my home. I can create custom lighting scenes for different activities, and the app makes controlling them easy and fun. The lights also respond quickly and work perfectly with voice commands.",
          "This lighting system has made my home feel much more modern. The ease of controlling each bulb individually or in groups is fantastic. The color-changing feature is great for adjusting the mood, and the setup process was incredibly easy.",
        ],
        negatives: [
          "Although the lights work well, the app can sometimes be slow to respond, which is frustrating when trying to adjust settings quickly. The bulbs also consume more power than I expected, especially when using the color-changing feature. Despite these issues, it’s still a good product overall.",
          "While the lights are great, I’ve had issues with them disconnecting from the app occasionally. This is particularly frustrating when I need to control the lights remotely. Also, the color-changing feature isn’t as vibrant as I had hoped, especially under bright light conditions.",
          "The lights are decent, but the app has some bugs. It occasionally crashes when I try to add a new bulb, and I’ve had trouble syncing with other smart devices in my home. The color options are nice, but the app could be much more reliable.",
          "I love the features, but the lights can be a little slow to respond to commands. Additionally, I’ve had occasional issues with the bulbs dropping off the Wi-Fi network. It would be great if the app offered more customization options for advanced users.",
          "The lights are great for ambiance, but I’ve experienced some occasional connectivity issues with the app. It can be frustrating when I need to adjust the lights, and it takes longer than expected to sync or respond to voice commands.",
        ],
      },
      5: {
        // Smart Thermostats
        positives: [
          "This smart thermostat is incredibly easy to install and use. I love how I can control the temperature of my home from anywhere using the app. It learns my schedule over time and adjusts the temperature automatically, which saves me money on heating and cooling bills. It’s an efficient and intuitive system.",
          "I’ve had this smart thermostat for a few months now, and it has been a great addition to my home. The temperature regulation is spot-on, and the energy-saving features are impressive. I can adjust the temperature remotely using my phone, which is incredibly convenient when I'm away.",
          "The ease of use is amazing. I can control the temperature from anywhere using the app, and the system automatically adjusts based on my preferences. It has helped me save on energy costs, and the installation process was straightforward. It’s the perfect solution for a smarter, more energy-efficient home.",
          "This thermostat has significantly improved my home’s comfort. The intuitive learning feature helps it adjust the temperature to my preferences, and I love that it can be controlled remotely. The energy savings are real, and it’s been a great investment for both comfort and efficiency.",
          "This smart thermostat is fantastic! I can control the temperature from anywhere, and the learning feature makes sure the house is always at the perfect temperature when I get home. It's helped reduce my energy bills, and the app is really easy to use.",
        ],
        negatives: [
          "The thermostat itself works fine, but the app can be a bit glitchy sometimes. It occasionally disconnects from the system or takes longer to adjust the temperature than I’d like. The learning feature is helpful, but it can take a while to fully adapt to my schedule.",
          "While the thermostat is efficient, it has some connectivity issues. Sometimes the app doesn’t respond immediately, and it can take a while for the system to update the settings. The learning feature doesn’t always adjust quickly enough, which can lead to temperature inconsistencies.",
          "I like the thermostat, but it struggles with Wi-Fi connection from time to time. There’s a noticeable delay in updating the temperature, and the app sometimes crashes. The learning feature could be more accurate and faster in adjusting to my schedule as well.",
          "Although the thermostat itself is effective, it can be slow to update the temperature in response to changes I make in the app. There are occasional issues with connectivity, which make controlling the system remotely a bit frustrating at times.",
          "I’ve had some issues with the Wi-Fi connection, and it’s taken longer than expected for the thermostat to learn my schedule. Additionally, the app can be laggy, and sometimes it doesn’t sync properly with the thermostat.",
        ],
      },
    };

    // Generate reviews for each product
    products.forEach((product) => {
      const templates = reviewTemplates[product.category_id];
      if (!templates) return; // Skip if category not defined

      for (let i = 0; i < 5; i++) {
        const reviewText =
          Math.random() > 0.5
            ? templates.positives[
                Math.floor(Math.random() * templates.positives.length)
              ]
            : templates.negatives[
                Math.floor(Math.random() * templates.negatives.length)
              ];

        reviews.push({
          id: Sequelize.literal("DEFAULT"), // auto incremented field
          ProductModelName: product.name,
          ProductCategory: templates.positives.length
            ? "Smart Doorbells"
            : "Smart Thermostats", // Default to category if needed
          ProductPrice: product.price,
          ProductID: product.id,
          UserID: users[Math.floor(Math.random() * users.length)].id,
          ReviewRating: Math.floor(Math.random() * 5) + 1, // Random rating between 1 and 5
          ReviewDate: now,
          ReviewText: reviewText,
          createdAt: now,
          updatedAt: now,
        });
      }
    });

    // Bulk insert reviews
    await queryInterface.bulkInsert("product_reviews", reviews, {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete("product_reviews", null, {
      where: { id: { [Op.gt]: 0 } }, // Deletes all reviews
    });
  },
};
