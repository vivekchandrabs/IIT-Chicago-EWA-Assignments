package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;

@WebServlet("/product/all")
public class ProductServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();
        List<ProductWithDetails> productList = new ArrayList<>();

        try (Connection connection = DBConnection.getConnection()) {
            // SQL query to fetch product, category, warranty, and accessories details
            String query = "SELECT p.id, p.name, p.category_id, p.warranty_id, p.price, p.description, p.image, "
                    + "c.name AS category_name, "
                    + "w.name AS warranty_name, "
                    + "a.accessory_id AS accessory_id, "
                    + "pa.name AS accessory_name, pa.price AS accessory_price, pa.description AS accessory_description, pa.image AS accessory_image "
                    + "FROM Products p "
                    + "JOIN Categories c ON p.category_id = c.id "
                    + "JOIN Warranties w ON p.warranty_id = w.id "
                    + "LEFT JOIN Accessories a ON p.id = a.product_id "
                    + "LEFT JOIN Products pa ON a.accessory_id = pa.id";  // Accessory is also a product
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            // Temporary structure to group products and accessories
            java.util.Map<Integer, ProductWithDetails> productMap = new java.util.HashMap<>();

            // Process the result set
            while (resultSet.next()) {
                int productId = resultSet.getInt("id");
                ProductWithDetails product = productMap.get(productId);

                // If the product hasn't been processed yet, create a new ProductWithDetails object
                if (product == null) {
                    product = new ProductWithDetails(
                            productId,
                            resultSet.getString("name"),
                            resultSet.getDouble("price"),
                            resultSet.getString("description"),
                            resultSet.getString("image"),
                            new Category(resultSet.getInt("category_id"), resultSet.getString("category_name")),
                            new Warranty(resultSet.getInt("warranty_id"), resultSet.getString("warranty_name")),
                            new ArrayList<>()
                    );
                    productMap.put(productId, product);
                }

                // Check if the product has any accessories and add them to the list
                if (resultSet.getInt("accessory_id") != 0) {
                    Accessory accessory = new Accessory(
                            resultSet.getInt("accessory_id"),
                            resultSet.getString("accessory_name"),
                            resultSet.getDouble("accessory_price"),
                            resultSet.getString("accessory_description"),
                            resultSet.getString("accessory_image")
                    );
                    product.getAccessories().add(accessory);
                }
            }

            // Convert map values to list for the final output
            productList.addAll(productMap.values());

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Convert the product list to JSON using Gson
        Gson gson = new Gson();
        String jsonResponse = gson.toJson(productList);
        out.print(jsonResponse);
        out.flush();
    }

    // Inner class for Product with category, warranty, and accessories details
    class ProductWithDetails {
        private int id;
        private String name;
        private double price;
        private String description;
        private String image;
        private Category category;
        private Warranty warranty;
        private List<Accessory> accessories;

        public ProductWithDetails(int id, String name, double price, String description, String image, Category category, Warranty warranty, List<Accessory> accessories) {
            this.id = id;
            this.name = name;
            this.price = price;
            this.description = description;
            this.image = image;
            this.category = category;
            this.warranty = warranty;
            this.accessories = accessories;
        }

        public List<Accessory> getAccessories() {
            return accessories;
        }
    }

    // Inner class for Category
    class Category {
        private int id;
        private String name;

        public Category(int id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    // Inner class for Warranty
    class Warranty {
        private int id;
        private String name;

        public Warranty(int id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    // Inner class for Accessory (which is also a product)
    class Accessory {
        private int id;
        private String name;
        private double price;
        private String description;
        private String image;

        public Accessory(int id, String name, double price, String description, String image) {
            this.id = id;
            this.name = name;
            this.price = price;
            this.description = description;
            this.image = image;
        }
    }
}
