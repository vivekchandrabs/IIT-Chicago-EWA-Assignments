package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/customer/delete")
public class CustomerDeleteServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body to JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract customer details from the JSON object
        int targetCustomerId = jsonObject.get("target_customer_id").getAsInt();
        int customerId = jsonObject.get("customer_id").getAsInt();
        String customerType = null;

        try (Connection connection = DBConnection.getConnection()) {
            // Check the type of the customer performing the delete
            String checkCustomerQuery = "SELECT type FROM Customers WHERE id = ?";
            PreparedStatement checkCustomerStmt = connection.prepareStatement(checkCustomerQuery);
            checkCustomerStmt.setInt(1, customerId);
            ResultSet customerResultSet = checkCustomerStmt.executeQuery();

            if (customerResultSet.next()) {
                customerType = customerResultSet.getString("type");
            } else {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"message\": \"Invalid customer_id\"}");
                out.flush();
                return;
            }

            // Only salesmen or managers can delete a customer
            if (!customerType.equals("salesmen") && !customerType.equals("manager")) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"message\": \"Only salesmen or managers can delete a customer\"}");
                out.flush();
                return;
            }

            // Delete the target customer
            String deleteCustomerQuery = "DELETE FROM Customers WHERE id = ?";
            PreparedStatement deleteStmt = connection.prepareStatement(deleteCustomerQuery);
            deleteStmt.setInt(1, targetCustomerId);

            int rowsAffected = deleteStmt.executeUpdate();
            if (rowsAffected > 0) {
                // Send a success response
                JsonObject successResponse = new JsonObject();
                successResponse.addProperty("message", "Customer deleted successfully");
                String jsonResponse = gson.toJson(successResponse);
                out.print(jsonResponse);
                out.flush();
            } else {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                JsonObject errorResponse = new JsonObject();
                errorResponse.addProperty("message", "Customer not found");
                String jsonResponse = gson.toJson(errorResponse);
                out.print(jsonResponse);
                out.flush();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            JsonObject errorResponse = new JsonObject();
            errorResponse.addProperty("message", "Error deleting customer");
            String jsonResponse = gson.toJson(errorResponse);
            out.print(jsonResponse);
            out.flush();
        }
    }
}
