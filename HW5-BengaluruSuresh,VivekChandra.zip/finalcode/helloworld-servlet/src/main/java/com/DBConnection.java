package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    // MySQL connection details
    private static final String URL = "jdbc:mysql://localhost:3306/ewadb";  // Replace with your MySQL database URL
    private static final String USERNAME = "root";  // Replace with your MySQL username
    private static final String PASSWORD = "password";  // Replace with your MySQL password

    public static Connection getConnection() throws SQLException {
        try {
            // Ensure the MySQL JDBC driver is loaded
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        // Establish and return the connection to the MySQL database
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
