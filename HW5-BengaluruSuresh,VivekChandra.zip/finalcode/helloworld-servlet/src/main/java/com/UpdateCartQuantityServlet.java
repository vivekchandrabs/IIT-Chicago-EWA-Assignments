package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/cart/update")
public class UpdateCartQuantityServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read JSON body from request
        Gson gson = new Gson();
        CartRequest request = gson.fromJson(req.getReader(), CartRequest.class);

        // Extract parameters from request object
        int customerId = request.getCustomer_id();
        int productId = request.getProduct_id();
        int quantity = request.getQuantity();

        try (Connection connection = DBConnection.getConnection()) {
            // Use separate queries for insert and update due to SQLite constraints
            String checkExistenceQuery = "SELECT * FROM Carts WHERE customer_id = ? AND product_id = ?";
            PreparedStatement checkStatement = connection.prepareStatement(checkExistenceQuery);
            checkStatement.setInt(1, customerId);
            checkStatement.setInt(2, productId);
            ResultSet resultSet = checkStatement.executeQuery();

            if (resultSet.next()) {
                // Update existing cart item
                String updateQuery = "UPDATE Carts SET quantity = ?, updatedAt = datetime('now') WHERE customer_id = ? AND product_id = ?";
                PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
                updateStatement.setInt(1, quantity);
                updateStatement.setInt(2, customerId);
                updateStatement.setInt(3, productId);
                updateStatement.executeUpdate();
            } else {
                // Insert new cart item
                String insertQuery = "INSERT INTO Carts (customer_id, product_id, quantity, createdAt, updatedAt) VALUES (?, ?, ?, datetime('now'), datetime('now'))";
                PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
                insertStatement.setInt(1, customerId);
                insertStatement.setInt(2, productId);
                insertStatement.setInt(3, quantity);
                insertStatement.executeUpdate();
            }

            // Retrieve the updated cart details
            String selectQuery = "SELECT c.customer_id, c.product_id, c.quantity, p.name, p.price, p.description, p.image " +
                    "FROM Carts c " +
                    "JOIN Products p ON c.product_id = p.id " +
                    "WHERE c.customer_id = ?";
            PreparedStatement selectStatement = connection.prepareStatement(selectQuery);
            selectStatement.setInt(1, customerId);
            ResultSet updatedResultSet = selectStatement.executeQuery();

            List<CartItem> items = new ArrayList<>();
            while (updatedResultSet.next()) {
                CartItem item = new CartItem(
                        updatedResultSet.getInt("product_id"),
                        updatedResultSet.getInt("quantity"),
                        new ProductDetail(
                                updatedResultSet.getString("name"),
                                updatedResultSet.getDouble("price"),
                                updatedResultSet.getString("description"),
                                updatedResultSet.getString("image")
                        )
                );
                items.add(item);
            }

            // Prepare the response
            CartResponse cartResponse = new CartResponse(customerId, items);
            String jsonResponse = gson.toJson(cartResponse);
            out.print(jsonResponse);
            out.flush();
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"Internal Server Error\"}");
            out.flush();
        }
    }

    // Inner class for Cart Request
    private class CartRequest {
        private int customer_id;
        private int product_id;
        private int quantity;

        public int getCustomer_id() {
            return customer_id;
        }

        public int getProduct_id() {
            return product_id;
        }

        public int getQuantity() {
            return quantity;
        }
    }

    // Inner class for Cart Response
    private class CartResponse {
        private int customer_id;
        private List<CartItem> items;

        public CartResponse(int customer_id, List<CartItem> items) {
            this.customer_id = customer_id;
            this.items = items;
        }

        public int getCustomer_id() {
            return customer_id;
        }

        public List<CartItem> getItems() {
            return items;
        }
    }

    // Inner class for Cart Item
    private class CartItem {
        private int product_id;
        private int quantity;
        private ProductDetail product;

        public CartItem(int product_id, int quantity, ProductDetail product) {
            this.product_id = product_id;
            this.quantity = quantity;
            this.product = product;
        }

        public int getProduct_id() {
            return product_id;
        }

        public int getQuantity() {
            return quantity;
        }

        public ProductDetail getProduct() {
            return product;
        }
    }

    // Inner class for Product Detail
    private class ProductDetail {
        private String name;
        private double price;
        private String description;
        private String image;

        public ProductDetail(String name, double price, String description, String image) {
            this.name = name;
            this.price = price;
            this.description = description;
            this.image = image;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }

        public String getDescription() {
            return description;
        }

        public String getImage() {
            return image;
        }
    }
}
