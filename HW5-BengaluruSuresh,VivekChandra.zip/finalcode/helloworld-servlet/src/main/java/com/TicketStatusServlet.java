package com;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/api/ticket-status")
public class TicketStatusServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();
        Gson gson = new Gson();

        // Retrieve ticket_number from request parameters
        String ticketNumber = req.getParameter("ticket_number");

        if (ticketNumber == null || ticketNumber.isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            JsonObject errorResponse = new JsonObject();
            errorResponse.addProperty("error", "Missing or empty ticket_number parameter.");
            out.print(gson.toJson(errorResponse));
            out.flush();
            return;
        }

        try (Connection connection = DBConnection.getConnection()) {
            // Query to fetch ticket details
            String query = "SELECT id, ticket_description, ticket_number, customer_id, image_url, status FROM tickets WHERE ticket_number = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, ticketNumber);
            ResultSet resultSet = statement.executeQuery();

            // Check if ticket exists
            if (resultSet.next()) {
                // Create JSON response with ticket details
                JsonObject ticketJson = new JsonObject();
                ticketJson.addProperty("id", resultSet.getInt("id"));
                ticketJson.addProperty("ticket_description", resultSet.getString("ticket_description"));
                ticketJson.addProperty("ticket_number", resultSet.getString("ticket_number"));
                ticketJson.addProperty("customer_id", resultSet.getInt("customer_id"));
                ticketJson.addProperty("image_url", resultSet.getString("image_url"));
                ticketJson.addProperty("status", resultSet.getString("status"));

                // Send the JSON response
                out.print(gson.toJson(ticketJson));
            } else {
                // Ticket not found
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                JsonObject errorResponse = new JsonObject();
                errorResponse.addProperty("error", "Ticket not found.");
                out.print(gson.toJson(errorResponse));
            }
            out.flush();
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            JsonObject errorResponse = new JsonObject();
            errorResponse.addProperty("error", "An error occurred while retrieving the ticket status.");
            out.print(gson.toJson(errorResponse));
            out.flush();
        }
    }
}
