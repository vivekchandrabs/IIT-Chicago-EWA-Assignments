package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;

@WebServlet("/cart/get")
public class CartGetServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Get customer_id from URL parameter
        String customerIdParam = req.getParameter("customer_id");
        if (customerIdParam == null || customerIdParam.isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"error\": \"customer_id is required\"}");
            out.flush();
            return;
        }

        int customerId = Integer.parseInt(customerIdParam);
        List<CartItem> cartItems = new ArrayList<>();

        try (Connection connection = DBConnection.getConnection()) {
            // SQL query to fetch cart items and product details
            String query = "SELECT c.product_id, c.quantity, p.id, p.name, p.price, p.description, p.image, "
                    + "cat.name AS category_name, w.name AS warranty_name "
                    + "FROM Carts c "
                    + "JOIN Products p ON c.product_id = p.id "
                    + "JOIN Categories cat ON p.category_id = cat.id "
                    + "JOIN Warranties w ON p.warranty_id = w.id "
                    + "WHERE c.customer_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, customerId);
            ResultSet resultSet = statement.executeQuery();

            // Process the result set
            while (resultSet.next()) {
                Product product = new Product(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("price"),
                        resultSet.getString("description"),
                        resultSet.getString("image"),
                        new Category(resultSet.getString("category_name")),
                        new Warranty(resultSet.getString("warranty_name"))
                );
                CartItem cartItem = new CartItem(resultSet.getInt("quantity"), product);
                cartItems.add(cartItem);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"Unable to retrieve cart items\"}");
            out.flush();
            return;
        }

        // Convert the cart item list to JSON and return it in the response
        Gson gson = new Gson();
        String jsonResponse = gson.toJson(cartItems);
        out.print(jsonResponse);
        out.flush();
    }

    // Inner class for CartItem
    class CartItem {
        private int quantity;
        private Product product;

        public CartItem(int quantity, Product product) {
            this.quantity = quantity;
            this.product = product;
        }
    }

    // Inner class for Product
    class Product {
        private int id;
        private String name;
        private double price;
        private String description;
        private String image;
        private Category category;
        private Warranty warranty;

        public Product(int id, String name, double price, String description, String image, Category category, Warranty warranty) {
            this.id = id;
            this.name = name;
            this.price = price;
            this.description = description;
            this.image = image;
            this.category = category;
            this.warranty = warranty;
        }
    }

    // Inner class for Category
    class Category {
        private String name;

        public Category(String name) {
            this.name = name;
        }
    }

    // Inner class for Warranty
    class Warranty {
        private String name;

        public Warranty(String name) {
            this.name = name;
        }
    }
}
