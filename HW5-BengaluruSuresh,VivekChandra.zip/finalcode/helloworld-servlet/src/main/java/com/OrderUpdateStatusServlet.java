package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/order/update-status")
public class OrderUpdateStatusServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body to JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract order_id, customer_id, and new status from the JSON object
        int orderId = jsonObject.get("order_id").getAsInt();
        int customerId = jsonObject.get("customer_id").getAsInt();
        String newStatus = jsonObject.get("status").getAsString();

        try (Connection connection = DBConnection.getConnection()) {
            // First, check if the customer_id matches the one that created the order
            String selectOrderQuery = "SELECT customer_id FROM Orders WHERE id = ?";
            PreparedStatement selectStatement = connection.prepareStatement(selectOrderQuery);
            selectStatement.setInt(1, orderId);
            ResultSet resultSet = selectStatement.executeQuery();

            if (resultSet.next()) {
                int dbCustomerId = resultSet.getInt("customer_id");

                if (dbCustomerId != customerId) {
                    // If the customer_id does not match, return an error
                    JsonObject errorResponse = new JsonObject();
                    errorResponse.addProperty("error", "Customer ID does not match the one that created the order.");
                    resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
                    out.print(gson.toJson(errorResponse));
                    out.flush();
                    return;
                }

                // If the customer ID matches, proceed to update the status
                String updateOrderQuery = "UPDATE Orders SET status = ?, updatedAt = ? WHERE id = ?";
                PreparedStatement updateStatement = connection.prepareStatement(updateOrderQuery);

                // Set current timestamp for updatedAt
                String updatedAt = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());

                updateStatement.setString(1, newStatus);
                updateStatement.setString(2, updatedAt);
                updateStatement.setInt(3, orderId);
                int affectedRows = updateStatement.executeUpdate();

                if (affectedRows == 0) {
                    throw new SQLException("Failed to update the order status, no rows affected.");
                }

                // Build the response with the updated order details
                JsonObject orderResponse = new JsonObject();
                orderResponse.addProperty("order_id", orderId);
                orderResponse.addProperty("customer_id", customerId);
                orderResponse.addProperty("status", newStatus);
                orderResponse.addProperty("updatedAt", updatedAt);

                // Return the updated order details in the response
                String jsonResponse = gson.toJson(orderResponse);
                out.print(jsonResponse);
                out.flush();

            } else {
                // If no order found with the given order_id
                JsonObject errorResponse = new JsonObject();
                errorResponse.addProperty("error", "Order not found.");
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print(gson.toJson(errorResponse));
                out.flush();
            }

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
