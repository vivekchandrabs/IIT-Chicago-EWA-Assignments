package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.*;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Base64;
import java.util.Random;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

@WebServlet("/api/create-tickets")
@MultipartConfig
public class TicketCreationServlet extends HttpServlet {

    private static final String IMAGE_SAVE_DIR = "./finalcode";
    private static final String OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";
    private static final String API_KEY = ""; // Retrieve API key from environment variable

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Generate a random 4-digit ticket number
        int ticketNumber = new Random().nextInt(9000) + 1000;
        String orderStatus = "pending";

        // Get the ticket description and customer ID from the request
        String ticketDescription = req.getParameter("ticket_description");
        int customerId = Integer.parseInt(req.getParameter("customer_id"));

        // Handle image upload and Base64 encoding
        String imageUrl = null;
        Part imagePart = req.getPart("image");
        String base64Image = null;

        if (imagePart != null && imagePart.getSize() > 0) {
            // Create the local directory if it doesn't exist
            File directory = new File(IMAGE_SAVE_DIR);
            if (!directory.exists()) {
                directory.mkdirs();
            }

            // Save the image file locally
            String fileName = System.currentTimeMillis() + "_" + imagePart.getSubmittedFileName();
            File file = new File(directory, fileName);
            imagePart.write(file.getAbsolutePath());

            // Set the image URL and encode the image to Base64
            imageUrl = file.getAbsolutePath();
            byte[] imageBytes = Files.readAllBytes(file.toPath());
            base64Image = Base64.getEncoder().encodeToString(imageBytes);
        }

        // Call OpenAI API with Base64 encoded image
        String aiResponse = callOpenAiApi(base64Image);

        if (aiResponse != null) {
            if (aiResponse.contains("Return") || aiResponse.contains("Refund") || aiResponse.contains("Escalate to Human Agent")) {
                orderStatus = aiResponse.contains("Return") ? "Return" : "Escalate to Human";
            } else {
                orderStatus = "unknown";
            }
        }

        // Save ticket information to the database
        try (Connection connection = DBConnection.getConnection()) {
            String sql = "INSERT INTO tickets (ticket_description, ticket_number, customer_id, image_url, status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, ticketDescription);
            statement.setInt(2, ticketNumber);
            statement.setInt(3, customerId);
            statement.setString(4, imageUrl);
            statement.setString(5, orderStatus);
            statement.executeUpdate();

            out.print("{\"message\": \"Ticket created successfully!\", \"ticket_number\": " + ticketNumber + ", \"status\": \"" + orderStatus + "\"}");
            out.flush();
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"Unable to create ticket.\"}");
            out.flush();
        }
    }

    private String callOpenAiApi(String base64Image) {
        try {
            // Construct the request body
            String body = "{\n" +
                    "    \"model\": \"gpt-4o-mini\",\n" +
                    "    \"messages\": [\n" +
                    "        {\"role\": \"user\", \"content\": [\n" +
                    "            {\"type\": \"text\", \"text\": \"Analyse the image. The response should be one word only. It should contain Return if the item in the image is damaged. If the item in the image is not damaged then the response should be just Escalate to Human only. If the item is barely damaged then return Refund only\"},\n" +
                    "            {\"type\": \"image_url\", \"image_url\": {\n" +
                    "                \"url\": \"data:image/png;base64," + base64Image + "\"}\n" +
                    "            }\n" +
                    "        ]}\n" +
                    "    ]\n" +
                    "}";

            // Set up the HTTP connection to the OpenAI API
            URL url = new URL(OPENAI_API_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Authorization", "Bearer " + API_KEY);
            connection.setDoOutput(true);

            // Write the request body
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = body.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            // Handle the response
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    return response.toString();
                }
            } else {
                System.err.println("OpenAI API request failed with response code: " + responseCode);
                return null;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
