package com;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/api/ajax-utility")
public class AjaxUtility extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Get the search term from the request
        String searchTerm = req.getParameter("query");
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();
        JsonArray productsArray = new JsonArray();

        if (searchTerm == null || searchTerm.isEmpty()) {
            // If no search term is provided, return an empty array
            out.print(productsArray.toString());
            out.flush();
            return;
        }

        try (Connection connection = DBConnection.getConnection()) {
            // SQL query to search for products by name
            String query = "SELECT id, name  FROM Products WHERE name LIKE ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, "%" + searchTerm + "%"); // Use wildcard search
                ResultSet resultSet = statement.executeQuery();

                // Process the result set
                while (resultSet.next()) {
                    JsonObject productJson = new JsonObject();
                    productJson.addProperty("id", resultSet.getString("id"));
                    productJson.addProperty("name", resultSet.getString("name"));
                    productsArray.add(productJson);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }

        // Send the response
        out.print(productsArray.toString());
        out.flush();
    }
}
