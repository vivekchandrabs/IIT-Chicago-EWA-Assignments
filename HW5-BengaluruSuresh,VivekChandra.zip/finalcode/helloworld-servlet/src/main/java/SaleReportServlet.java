package com;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/api/sale-report")
public class SaleReportServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();
        Map<Integer, SaleProduct> salesData = new HashMap<>();
        Map<String, Double> dailySalesData = new HashMap<>();

        try (Connection connection = DBConnection.getConnection()) {
            // SQL query to fetch order details
            String query = "SELECT products, createdAt FROM Orders"; // Fetch product details and creation time
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            // Process each order
            while (resultSet.next()) {
                String productDetailsJson = resultSet.getString("products"); // This contains the JSON array of products
                String createdAt = resultSet.getString("createdAt"); // This is the creation timestamp of the order

                // Parse the JSON array from the order record
                JsonArray productArray = JsonParser.parseString(productDetailsJson).getAsJsonArray();
                double totalSalesForOrder = 0; // Total sales for this specific order

                for (int i = 0; i < productArray.size(); i++) {
                    JsonObject productObj = productArray.get(i).getAsJsonObject();
                    int productId = productObj.get("product_id").getAsInt();
                    int quantity = productObj.get("quantity").getAsInt();

                    // Fetch product information from the Products table
                    String productQuery = "SELECT name, price FROM Products WHERE id = ?";
                    try (PreparedStatement productStatement = connection.prepareStatement(productQuery)) {
                        productStatement.setInt(1, productId);
                        ResultSet productResultSet = productStatement.executeQuery();

                        if (productResultSet.next()) {
                            String productName = productResultSet.getString("name");
                            double productPrice = productResultSet.getDouble("price");

                            // Update sales data
                            if (!salesData.containsKey(productId)) {
                                salesData.put(productId, new SaleProduct(productName, productPrice, 0, 0));
                            }
                            SaleProduct saleProduct = salesData.get(productId);
                            saleProduct.incrementQuantitySold(quantity);
                            double salesAmount = productPrice * quantity;
                            saleProduct.addToTotalSales(salesAmount);

                            // Add to the total sales for the order
                            totalSalesForOrder += salesAmount;
                        }
                    }
                }

                // Calculate total sales for the day
                String dateKey = createdAt.split(" ")[0]; // Get the date part (YYYY-MM-DD)
                dailySalesData.put(dateKey, dailySalesData.getOrDefault(dateKey, 0.0) + totalSalesForOrder);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Convert the sales data to JSON using Gson
        Gson gson = new Gson();
        JsonArray salesArray = new JsonArray();
        for (SaleProduct saleProduct : salesData.values()) {
            JsonObject productJson = new JsonObject();
            productJson.addProperty("name", saleProduct.getName());
            productJson.addProperty("price", saleProduct.getPrice());
            productJson.addProperty("number_of_items_sold", saleProduct.getQuantitySold());
            productJson.addProperty("total_sales", saleProduct.getTotalSales());
            salesArray.add(productJson);
        }

        JsonObject responseJson = new JsonObject();
        responseJson.add("sales", salesArray);

        // Prepare daily sales data
        JsonArray dailySalesArray = new JsonArray();
        for (Map.Entry<String, Double> entry : dailySalesData.entrySet()) {
            JsonObject dailySalesJson = new JsonObject();
            dailySalesJson.addProperty("date", entry.getKey());
            dailySalesJson.addProperty("total_sales", entry.getValue());
            dailySalesArray.add(dailySalesJson);
        }

        responseJson.add("daily_sales", dailySalesArray);
        out.print(responseJson.toString());
        out.flush();
    }

    // Inner class for SaleProduct
    class SaleProduct {
        private String name;
        private double price;
        private int quantitySold;
        private double totalSales;

        public SaleProduct(String name, double price, int quantitySold, double totalSales) {
            this.name = name;
            this.price = price;
            this.quantitySold = quantitySold;
            this.totalSales = totalSales;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }

        public int getQuantitySold() {
            return quantitySold;
        }

        public double getTotalSales() {
            return totalSales;
        }

        public void incrementQuantitySold(int quantity) {
            this.quantitySold += quantity;
        }

        public void addToTotalSales(double amount) {
            this.totalSales += amount;
        }
    }
}
