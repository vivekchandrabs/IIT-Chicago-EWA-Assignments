hw2store Application

Overview

This project is a web application built using Java Servlets, JDBC (with SQLite database), and Gson for JSON responses. It provides RESTful APIs to manage orders, products, customers, and shopping carts, with role-based access control for different user types (managers, salesmen, and customers).

Prerequisites

Before setting up and running the project, ensure that you have the following installed:

- Java Development Kit (JDK) 8+
- Apache Tomcat 9+
- SQLite 3
- Maven (for building the project)
- SQLite JDBC Driver (included in the dependencies)

Project Structure

The project is structured as follows:

src/main/java/com/
├── DBConnection.java # Utility for managing database connections
├── OrderCreateServlet.java # Servlet for creating orders
├── ProductServlet.java # Servlet for fetching all products
├── GetAllCustomersServlet.java # Servlet for fetching all customer info
├── CartServlet.java # Servlet for handling cart-related requests
├── UpdateCustomerServlet.java # Servlet for updating customer information
├── OrdersServlet.java # Servlet for retrieving orders
├── CustomerSignupServlet.java # Servlet for signing up customers
└── Other Servlets...

Setup Instructions

Step 1: Clone the Repository

git clone <repository_url>
cd hw1store

Step 2: Configure Database

The project uses SQLite as the database. A sample database file is provided.

1. Initialize the SQLite database:
   - Create a new SQLite database (or use the provided hw1store.db).
   - Run the migrations and seed commands to create and populate tables for `Customers`, `Products`, `Orders`, etc.

for migrations:
npx sequelize-cli db:migrate

for seeders:
npx sequelize-cli db:seed --seed 20240927174344-demo-store-location.js
npx sequelize-cli db:seed --seed 20240913204334-demo-category.js
npx sequelize-cli db:seed --seed 20240913204344-demo-delivery-type.js
npx sequelize-cli db:seed --seed 20240913204349-demo-customer.js
npx sequelize-cli db:seed --seed 20240913204411-demo-warranty.js
npx sequelize-cli db:seed --seed 20240913204355-demo-product.js
npx sequelize-cli db:seed --seed 20240913204400-demo-accessory.js
npx sequelize-cli db:seed --seed 20240913204404-demo-order.js

2. Database Connection:
   Ensure the SQLite database connection in DBConnection.java points to the correct database path.

private static final String DB_URL = "jdbc:sqlite:/path/to/hw1store.db";

Step 3: Install Maven Dependencies

The project uses Maven to manage dependencies. Run the following command to install them:

mvn clean install

Dependencies include:

- Gson: For handling JSON serialization/deserialization.
- SQLite JDBC: To connect to SQLite.
- Servlet API: For building servlets.

Step 4: Deploy to Apache Tomcat

1. Build the WAR file:

Use Maven to package the project into a .war file:

mvn clean package

This will generate a hw1store.war file in the target/ directory.

2. Deploy to Tomcat:

- Copy the hw1store.war file to the webapps/ directory of your Apache Tomcat installation.
- Start Tomcat:

cd /path/to/tomcat/bin
./startup.sh

Tomcat will automatically deploy the hw1store.war file.

3. Access the Application:

You can access the application at: http://localhost:8080/hw1store/

Step 5: Test APIs

Use tools like Postman or cURL to test the API endpoints.

Example requests:

- Get all products:
  GET http://localhost:8080/hw1store/products/all

- Create a new order:
  POST http://localhost:8080/hw1store/order/create
  Content-Type: application/json

  {
  "customer_id": 1,
  "products": [
  {"product_id": 1, "quantity": 2},
  {"product_id": 3, "quantity": 1}
  ],
  "payment": "29.99"
  }

- Get all customers:
  GET http://localhost:8080/hw1store/customers/all

- Sign up a new customer:
  POST http://localhost:8080/hw1store/customer/signup
  Content-Type: application/json

  {
  "name": "John Doe",
  "email": "john@example.com",
  "type": "regular"
  }

CORS Configuration

If you're making requests from a different domain, ensure that CORS is enabled. This is already configured in CORSFilter.java.

response.setHeader("Access-Control-Allow-Origin", "\*");
response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

Make sure this filter is mapped in web.xml to apply to all API endpoints.

Troubleshooting

- Database connection issues: Ensure the correct path to the SQLite database is specified in DBConnection.java.
- CORS errors: Verify that the CORS filter is properly configured and deployed.
- API response issues: Check the Tomcat logs for detailed error messages.

Contributing

Feel free to fork the repository and submit pull requests for any features or improvements.

License

This project is licensed under the MIT License.
