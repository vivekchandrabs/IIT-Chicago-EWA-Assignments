"use strict";
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("Accessories", {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      product_id: {
        type: Sequelize.INTEGER,
        references: {
          model: "Products",
          key: "id",
        },
        onDelete: "CASCADE", // If the product is deleted, the accessory should be deleted too
        allowNull: false,
      },
      accessory_id: {
        type: Sequelize.INTEGER,
        references: {
          model: "Products", // Reference the Products table since an accessory is also a product
          key: "id",
        },
        onDelete: "CASCADE", // If the accessory product is deleted, the association should be deleted
        allowNull: false,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("Accessories");
  },
};
