mvn clean package
cp target/helloworld-servlet.war /usr/local/tomcat/webapps/