package com; // Adjust this package name as needed for your project structure

import com.google.gson.Gson;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.FindIterable;
import org.bson.Document;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@WebServlet("/product/reviews")
public class GetProductReviewsByID extends HttpServlet {
    private static final Logger logger = Logger.getLogger(GetProductReviewsByID.class.getName());
    private Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        try {
            // Get the product_id from the request parameters
            String productIdStr = req.getParameter("product_id");
            if (productIdStr == null || productIdStr.isEmpty()) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print(gson.toJson("Error: product_id is required"));
                return;
            }

            int productId = Integer.parseInt(productIdStr);

            // Get the MongoDB collection
            MongoDatabase database = MongoDBConnection.getDatabase();
            MongoCollection<Document> collection = database.getCollection("product_reviews");

            // Query for reviews with the given product_id
            Document query = new Document("ProductID", productId);
            FindIterable<Document> results = collection.find(query);

            // Convert the results to a list of ProductReview objects
            List<ProductReview> reviews = new ArrayList<>();
            for (Document doc : results) {
                ProductReview review = gson.fromJson(doc.toJson(), ProductReview.class);
                reviews.add(review);
            }

            // Send the reviews as a JSON response
            out.print(gson.toJson(reviews));
            logger.info("Retrieved " + reviews.size() + " reviews for product ID: " + productId);

        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print(gson.toJson("Error: Invalid product_id format"));
            logger.warning("Invalid product_id format: " + e.getMessage());
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print(gson.toJson("Error retrieving reviews: " + e.getMessage()));
            logger.severe("Error retrieving reviews: " + e.getMessage());
        } finally {
            out.flush();
        }
    }
}