package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/product/like")
public class UpdateLikeCountServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body to JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract product_id from the JSON object
        int productId = jsonObject.get("product_id").getAsInt();

        try (Connection connection = DBConnection.getConnection()) {
            // SQL query to increment the like_count for the given product_id
            String updateQuery = "UPDATE Products SET like_count = like_count + 1 WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(updateQuery);
            statement.setInt(1, productId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                resp.setStatus(HttpServletResponse.SC_OK);
                out.print("{\"message\": \"Like count incremented successfully\"}");
            } else {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print("{\"error\": \"Product not found\"}");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"An error occurred while updating the like count\"}");
        } finally {
            out.flush();
        }
    }
}
