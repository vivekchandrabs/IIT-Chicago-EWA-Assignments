package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import java.sql.Timestamp;

@WebServlet("/cart/add")
public class CartServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = req.getReader().readLine()) != null) {
            sb.append(line);
        }
        String requestBody = sb.toString();

        // Parse JSON request body
        Gson gson = new Gson();
        CartRequest cartRequest = gson.fromJson(requestBody, CartRequest.class);

        if (cartRequest == null || cartRequest.getCustomer_id() <= 0 || cartRequest.getProduct_id() <= 0 || cartRequest.getQuantity() <= 0) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"message\":\"Invalid request\"}");
            out.flush();
            return;
        }

        try (Connection connection = DBConnection.getConnection()) {
            // Insert the product into the cart
            String insertQuery = "INSERT INTO Carts (customer_id, product_id, quantity, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement insertStatement = connection.prepareStatement(insertQuery);

            // Current timestamp
            Timestamp now = new Timestamp(System.currentTimeMillis());

            insertStatement.setInt(1, cartRequest.getCustomer_id());
            insertStatement.setInt(2, cartRequest.getProduct_id());
            insertStatement.setInt(3, cartRequest.getQuantity());
            insertStatement.setTimestamp(4, now); // Set createdAt
            insertStatement.setTimestamp(5, now); // Set updatedAt
            insertStatement.executeUpdate();

            // Fetch the cart with product details
            String selectQuery = "SELECT c.customer_id, c.product_id, c.quantity, p.name as product_name, p.price as product_price, c.createdAt, c.updatedAt " +
                    "FROM Carts c " +
                    "JOIN Products p ON c.product_id = p.id " +
                    "WHERE c.customer_id = ?";
            PreparedStatement selectStatement = connection.prepareStatement(selectQuery);
            selectStatement.setInt(1, cartRequest.getCustomer_id());
            ResultSet resultSet = selectStatement.executeQuery();

            List<CartItem> cartItems = new ArrayList<>();
            while (resultSet.next()) {
                CartItem cartItem = new CartItem(
                        resultSet.getInt("product_id"),
                        resultSet.getString("product_name"),
                        resultSet.getDouble("product_price"),
                        resultSet.getInt("quantity"),
                        resultSet.getTimestamp("createdAt"),
                        resultSet.getTimestamp("updatedAt")
                );
                cartItems.add(cartItem);
            }

            CartResponse cartResponse = new CartResponse(cartRequest.getCustomer_id(), cartItems);

            // Convert the response object to JSON using Gson
            String jsonResponse = gson.toJson(cartResponse);
            out.print(jsonResponse);
            out.flush();
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"message\":\"An error occurred while adding product to the cart\"}");
            out.flush();
        }
    }

    // Inner class for request body
    class CartRequest {
        private int customer_id;
        private int product_id;
        private int quantity;

        // Getters and setters
        public int getCustomer_id() {
            return customer_id;
        }

        public void setCustomer_id(int customer_id) {
            this.customer_id = customer_id;
        }

        public int getProduct_id() {
            return product_id;
        }

        public void setProduct_id(int product_id) {
            this.product_id = product_id;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }
    }

    // Inner class for cart item response
    class CartItem {
        private int product_id;
        private String product_name;
        private double product_price;
        private int quantity;
        private Timestamp createdAt;
        private Timestamp updatedAt;

        public CartItem(int product_id, String product_name, double product_price, int quantity, Timestamp createdAt, Timestamp updatedAt) {
            this.product_id = product_id;
            this.product_name = product_name;
            this.product_price = product_price;
            this.quantity = quantity;
            this.createdAt = createdAt;
            this.updatedAt = updatedAt;
        }

        // Getters and setters
        public int getProduct_id() {
            return product_id;
        }

        public void setProduct_id(int product_id) {
            this.product_id = product_id;
        }

        public String getProduct_name() {
            return product_name;
        }

        public void setProduct_name(String product_name) {
            this.product_name = product_name;
        }

        public double getProduct_price() {
            return product_price;
        }

        public void setProduct_price(double product_price) {
            this.product_price = product_price;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        public Timestamp getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(Timestamp createdAt) {
            this.createdAt = createdAt;
        }

        public Timestamp getUpdatedAt() {
            return updatedAt;
        }

        public void setUpdatedAt(Timestamp updatedAt) {
            this.updatedAt = updatedAt;
        }
    }

    // Inner class for cart response
    class CartResponse {
        private int customer_id;
        private List<CartItem> items;

        public CartResponse(int customer_id, List<CartItem> items) {
            this.customer_id = customer_id;
            this.items = items;
        }

        // Getters and setters
        public int getCustomer_id() {
            return customer_id;
        }

        public void setCustomer_id(int customer_id) {
            this.customer_id = customer_id;
        }

        public List<CartItem> getItems() {
            return items;
        }

        public void setItems(List<CartItem> items) {
            this.items = items;
        }
    }
}
