package com;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/product/review")
public class ProductReviewServlet extends HttpServlet {
    private Gson gson = new Gson();
    private static final Logger logger = Logger.getLogger(ProductReviewServlet.class.getName());

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        try {
            // Read the request body
            String requestBody = req.getReader().lines().reduce("", (accumulator, actual) -> accumulator + actual);
            logger.info("Received request body: " + requestBody);

            // Deserialize the request body to ProductReview
            ProductReview review = gson.fromJson(requestBody, ProductReview.class);
            logger.info("Deserialized review: " + review.toString());

            // Get the MongoDB collection
            MongoDatabase database = MongoDBConnection.getDatabase();
            logger.info("Connected to MongoDB database: " + database.getName());
            MongoCollection<Document> collection = database.getCollection("product_reviews");
            logger.info("Accessing collection: product_reviews");

            // Insert the review document
            Document doc = review.toDocument();
            logger.info("Inserting document: " + doc.toJson());
            collection.insertOne(doc);
            logger.info("Review successfully saved to MongoDB.");

            // Respond with the original JSON
            out.print(requestBody);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error while processing review", e);
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print(gson.toJson("Error processing review: " + e.getMessage()));
        } finally {
            out.flush();
        }
    }
}