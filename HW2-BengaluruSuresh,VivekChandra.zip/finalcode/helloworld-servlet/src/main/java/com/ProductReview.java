package com; // Adjust this package name as needed for your project structure

import org.bson.Document;
import com.google.gson.Gson;

public class ProductReview {
    private String ProductModelName;
    private String ProductCategory;
    private int ProductPrice;
    private int ProductID;
    private String UserID;
    private int ReviewRating;
    private String ReviewDate;
    private String ReviewText;

    private static final Gson gson = new Gson(); // Static Gson instance

    // Getters and setters...

    public Document toDocument() {
        return new Document()
                .append("ProductModelName", ProductModelName)
                .append("ProductCategory", ProductCategory)
                .append("ProductPrice", ProductPrice)
                .append("ProductID", ProductID)
                .append("UserID", UserID)
                .append("ReviewRating", ReviewRating)
                .append("ReviewDate", ReviewDate)
                .append("ReviewText", ReviewText);
    }

    @Override
    public String toString() {
        return gson.toJson(this);
    }
}