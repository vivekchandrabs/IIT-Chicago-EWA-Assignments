package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/product/update")
public class ProductUpdateServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body to JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract product details from the JSON object
        int productId = jsonObject.get("id").getAsInt();
        String name = jsonObject.get("name").getAsString();
        String description = jsonObject.get("description").getAsString();
        double price = jsonObject.get("price").getAsDouble();
        String image = jsonObject.get("image").getAsString();
        int customerId = jsonObject.get("customer_id").getAsInt(); // Customer ID of the person performing the update

        String customerType = null;

        try (Connection connection = DBConnection.getConnection()) {
            // Check the type of the customer performing the update
            String checkCustomerQuery = "SELECT type FROM Customers WHERE id = ?";
            PreparedStatement checkCustomerStmt = connection.prepareStatement(checkCustomerQuery);
            checkCustomerStmt.setInt(1, customerId);
            ResultSet customerResultSet = checkCustomerStmt.executeQuery();

            if (customerResultSet.next()) {
                customerType = customerResultSet.getString("type");
            } else {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"message\": \"Invalid customer_id\"}");
                out.flush();
                return;
            }

            // Validate that only a manager can update a product
            if (!customerType.equals("manager")) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"message\": \"Only managers can update a product\"}");
                out.flush();
                return;
            }

            // Update the product information and set updatedAt field
            String updateProductQuery = "UPDATE Products SET name = ?, description = ?, price = ?, image = ?, updatedAt = datetime('now') WHERE id = ?";
            PreparedStatement updateStmt = connection.prepareStatement(updateProductQuery);
            updateStmt.setString(1, name);
            updateStmt.setString(2, description);
            updateStmt.setDouble(3, price);
            updateStmt.setString(4, image);
            updateStmt.setInt(5, productId);

            int rowsAffected = updateStmt.executeUpdate();
            if (rowsAffected > 0) {
                // Fetch the updated product details
                String fetchProductQuery = "SELECT id, name, description, price, image, createdAt, updatedAt FROM Products WHERE id = ?";
                PreparedStatement fetchStmt = connection.prepareStatement(fetchProductQuery);
                fetchStmt.setInt(1, productId);
                ResultSet productResultSet = fetchStmt.executeQuery();

                if (productResultSet.next()) {
                    JsonObject productResponse = new JsonObject();
                    productResponse.addProperty("id", productResultSet.getInt("id"));
                    productResponse.addProperty("name", productResultSet.getString("name"));
                    productResponse.addProperty("description", productResultSet.getString("description"));
                    productResponse.addProperty("price", productResultSet.getDouble("price"));
                    productResponse.addProperty("image", productResultSet.getString("image"));
                    productResponse.addProperty("createdAt", productResultSet.getString("createdAt"));
                    productResponse.addProperty("updatedAt", productResultSet.getString("updatedAt"));

                    // Send the updated product response
                    String jsonResponse = gson.toJson(productResponse);
                    out.print(jsonResponse);
                    out.flush();
                }
            } else {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print("{\"message\": \"Product not found\"}");
                out.flush();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"message\": \"Error updating product\"}");
            out.flush();
        }
    }
}
