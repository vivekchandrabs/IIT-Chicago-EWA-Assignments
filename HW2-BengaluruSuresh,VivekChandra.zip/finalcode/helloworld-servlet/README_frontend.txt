Project Name: ASSIGNMENT 2

Setup for the Frontend:

Prerequisites:

- Node.js
- npm

Installation Instructions:

1. Navigate to the project directory:
   cd hw1-frontend

1. Install dependencies:
   npm install
   or
   yarn install

Running the Project:

1. Start the development server:
   npm start
   or
   yarn start

2. Open your browser and visit:
   http://localhost:5173

Building for Production:

1. Build the app for production:
   npm run build
   or
   yarn build

2. The production-ready files will be in the 'build' directory.

Additional Information:

- For any issues or questions, please contact [vbengalurusuresh@hawk.iit.edu].
- Contributions are welcome! Please see 'CONTRIBUTING.md' for more information.

License:
This project is licensed under the MIT License.
