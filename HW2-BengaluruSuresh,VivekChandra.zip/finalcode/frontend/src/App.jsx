import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import AuthPage from './views/AuthPage.jsx';
import ProductGrid from './views/ProductGrid.jsx';
import ProductDetail from './views/ProductDetail.jsx'; // Import the ProductDetail component
import CartPage from './views/CartPage.jsx';
import CheckoutPage from './views/Checkout.jsx';
import OrdersPage from './views/Orders.jsx';
import CustomersPage from './views/Customer.jsx';
import EditProduct from './views/EditProduct.jsx';
import Layout from './Layouts/layout.jsx';
import TrendingPage from './views/TrendingPage.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const userType = 'customer';

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<AuthPage />} />
        <Route element={<Layout userType={userType} />}>
          <Route path="/products" element={<ProductGrid />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/orders" element={<OrdersPage />} />
          <Route path="/customers" element={<CustomersPage />} />
          <Route path="/edit-product" element={<EditProduct />} />
          <Route path="/trending" element={<TrendingPage />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;