import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

function Navbar() {
    const navigate = useNavigate();
    const location = useLocation();
    const query = new URLSearchParams(location.search);
    const customerId = query.get("customer_id");
    const userType = query.get("type");

    const handleLogout = () => {
        navigate('/login');
    };

    if (location.pathname === '/login') {
        return null; // Do not render navbar on login page
    }

    const navItems = {
        customer: [
            { name: 'Products', path: '/products' },
            { name: 'Orders', path: '/orders' },
            { name: 'Cart', path: '/cart' },
            { name: 'Trending', path: '/trending' }, // Added Trending Page
            { name: 'Logout', action: handleLogout },
        ],
        salesmen: [
            { name: 'Products', path: '/products' },
            { name: 'Orders', path: '/orders' },
            { name: 'Cart', path: '/cart' },
            { name: 'Customers', path: '/customers' },
            { name: 'Trending', path: '/trending' }, // Added Trending Page
            { name: 'Logout', action: handleLogout },
        ],
        manager: [
            { name: 'Products', path: '/products' },
            { name: 'Orders', path: '/orders' },
            { name: 'Edit Product', path: '/edit-product' },
            { name: 'Cart', path: '/cart' },
            { name: 'Customers', path: '/customers' },
            { name: 'Trending', path: '/trending' }, // Added Trending Page
            { name: 'Logout', action: handleLogout },
        ],
    };

    const currentNavItems = navItems[userType] || [];

    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
            <div className="container-fluid">
                <a className="navbar-brand" href="#">CSP-587 Stores</a>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav">
                        {currentNavItems.map((item, index) => (
                            <li className="nav-item" key={index}>
                                {item.path ? (
                                    <a className="nav-link" href={`${item.path}?customer_id=${customerId}&type=${userType}`}>
                                        {item.name}
                                    </a>
                                ) : (
                                    <button className="nav-link btn btn-link" onClick={item.action}>
                                        {item.name}
                                    </button>
                                )}
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </nav>
    );
}

export default Navbar;