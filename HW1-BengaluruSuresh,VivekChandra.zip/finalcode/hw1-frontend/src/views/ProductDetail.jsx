import React, { useEffect, useState } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";

function ProductDetail() {
    const { id } = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    const [product, setProduct] = useState(null);
    const [accessories, setAccessories] = useState([]);
    const [quantity, setQuantity] = useState(1);

    useEffect(() => {
        fetch(`http://localhost:8080/helloworld-servlet/product/${id}`)
            .then((response) => response.json())
            .then((data) => {
                setProduct(data);
                return Promise.all(
                    data.accessories.map((accessory) =>
                        fetch(`http://localhost:8080/helloworld-servlet/product/${accessory.id}`)
                            .then((res) => res.json())
                    )
                );
            })
            .then((accessoryData) => setAccessories(accessoryData))
            .catch((error) => console.error("Error fetching product:", error));
    }, [id]);

    const query = new URLSearchParams(location.search);
    const customerId = query.get("customer_id");
    const userType = query.get("type");

    const handleAddToCart = async () => {
        try {
            const response = await fetch("http://localhost:8080/helloworld-servlet/cart/add", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    customer_id: customerId,
                    product_id: product.id,
                    quantity: quantity,
                }),
            });
            const result = await response.json();
            console.log("Add to Cart Response:", result);
            alert("Product added to cart!");
        } catch (error) {
            console.error("Add to Cart Error:", error);
        }
    };

    if (!product) return <div>Loading...</div>;

    return (
        <div style={{ padding: "20px" }}>
            <div style={{ display: "flex", alignItems: "center", marginBottom: "20px" }}>
                <img src={product.image} alt={product.name} style={{ width: "300px", marginRight: "20px" }} />
                <div>
                    <h2>{product.name}</h2>
                    <p>Price: ${product.price.toFixed(2)}</p>
                    <p>{product.description}</p>
                    <p>Category: {product.category.name}</p>
                    <p>Warranty: {product.warranty.name}</p>
                    <div style={{ display: "flex", alignItems: "center", marginTop: "10px" }}>
                        <button onClick={() => setQuantity(quantity > 1 ? quantity - 1 : 1)}>-</button>
                        <span style={{ margin: "0 10px" }}>{quantity}</span>
                        <button onClick={() => setQuantity(quantity + 1)}>+</button>
                    </div>
                    <button onClick={handleAddToCart} style={{ marginTop: "10px", backgroundColor: "blue", color: "white", padding: "5px 10px" }}>
                        Add to Cart
                    </button>
                </div>
            </div>
            <h3>Accessories</h3>
            <div style={{ display: "flex", overflowX: "auto" }}>
                {accessories.map((accessory) => (
                    <div
                        key={accessory.id}
                        style={{ cursor: "pointer", marginRight: "20px" }}
                        onClick={() => navigate(`/product/${accessory.id}?customer_id=${customerId}&type=${userType}`)}
                    >
                        <img src={accessory.image} alt={accessory.name} style={{ width: "100px" }} />
                        <p>{accessory.name}</p>
                        <p>${accessory.price.toFixed(2)}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default ProductDetail;