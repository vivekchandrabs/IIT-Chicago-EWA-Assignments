import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

function OrdersPage() {
    const [orders, setOrders] = useState([]);
    const location = useLocation();
    const query = new URLSearchParams(location.search);
    const customerId = query.get("customer_id");

    useEffect(() => {
        fetch("http://localhost:8080/helloworld-servlet/orders/all", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ customer_id: customerId }),
        })
            .then((response) => response.json())
            .then((data) => setOrders(data))
            .catch((error) => console.error("Error fetching orders:", error));
    }, [customerId]);

    const handleCancelOrder = async (orderId, orderCustomerId) => {
        try {
            const response = await fetch("http://localhost:8080/helloworld-servlet/order/update-status", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    order_id: orderId,
                    customer_id: orderCustomerId,
                    status: "Cancelled",
                }),
            });

            if (response.ok) {
                alert("Order cancelled successfully.");
                setOrders(orders.map(order =>
                    order.id === orderId ? { ...order, status: "Cancelled" } : order
                ));
            } else {
                alert("Failed to cancel order.");
            }
        } catch (error) {
            console.error("Error cancelling order:", error);
        }
    };

    return (
        <div style={{ padding: "20px" }}>
            {orders.length === 0 ? (
                <p>You don't have any orders yet.</p>
            ) : (
                orders.map((order) => (
                    <div key={order.id} style={{ display: "flex", marginBottom: "20px", width: "100%" }}>
                        <div style={{ flex: 2, marginRight: "20px" }}>
                            <h2>Order #{order.id}</h2>
                            {order.products.map((product) => (
                                <div key={product.product_id} style={{ border: "1px solid #ccc", borderRadius: "5px", padding: "10px", marginBottom: "10px" }}>
                                    <img src={product.image} alt={product.name} style={{ width: "100px", height: "100px", objectFit: "cover" }} />
                                    <h3>{product.name}</h3>
                                    <p>Price: ${product.price.toFixed(2)}</p>
                                    <p>Quantity: {product.quantity}</p>
                                    <p>{product.description}</p>
                                </div>
                            ))}
                        </div>
                        <div style={{ flex: 1, border: "1px solid #ccc", borderRadius: "5px", padding: "20px" }}>
                            <h2>Order Details</h2>
                            <p>Status: {order.status}</p>
                            <p>Total Payment: ${order.payment}</p>
                            <button onClick={() => handleCancelOrder(order.id, order.customer_id)} style={{ marginTop: "10px", padding: "10px", backgroundColor: "red", color: "white", border: "none", cursor: "pointer" }}>
                                Cancel Order
                            </button>
                        </div>
                    </div>
                ))
            )}
        </div>
    );
}

export default OrdersPage;