package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@WebServlet("/order/create")
public class OrderCreateServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body to JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract customer_id, products, payment, and status from the JSON object
        int customerId = jsonObject.get("customer_id").getAsInt();
        JsonArray products = jsonObject.getAsJsonArray("products");
        String payment = jsonObject.get("payment").getAsString();

        // Define default order status
        String status = "pending";  // This can be modified based on your business logic

        int orderId = 0;
        String createdAt = null;
        String updatedAt = null;

        try (Connection connection = DBConnection.getConnection()) {
            // Insert the new order into the Orders table
            String insertOrderQuery = "INSERT INTO Orders (customer_id, products, payment, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(insertOrderQuery, Statement.RETURN_GENERATED_KEYS);

            // Set the current timestamp for createdAt and updatedAt
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String currentTime = dateFormat.format(new Date());

            statement.setInt(1, customerId);
            statement.setString(2, products.toString()); // Store the products as JSON string
            statement.setString(3, payment);
            statement.setString(4, status);  // status of the order
            statement.setString(5, currentTime);  // createdAt
            statement.setString(6, currentTime);  // updatedAt
            int affectedRows = statement.executeUpdate();

            // Ensure that the insert was successful
            if (affectedRows == 0) {
                throw new SQLException("Failed to create order, no rows affected.");
            }

            // Retrieve the generated order ID and the timestamps
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    orderId = generatedKeys.getInt(1); // Get the inserted order's ID
                } else {
                    throw new SQLException("Failed to create order, no ID obtained.");
                }
            }

            // Fetch the created and updated timestamps from the result
            createdAt = currentTime;
            updatedAt = currentTime;

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // Send error response if something goes wrong
            return;
        }

        // Build the response with the order details
        JsonObject orderResponse = new JsonObject();
        orderResponse.addProperty("id", orderId);
        orderResponse.addProperty("customer_id", customerId);
        orderResponse.add("products", products);
        orderResponse.addProperty("payment", payment);
        orderResponse.addProperty("status", status); // Add the status to the response
        orderResponse.addProperty("createdAt", createdAt);
        orderResponse.addProperty("updatedAt", updatedAt);

        // Convert the order object to JSON and return it in the response
        String jsonResponse = gson.toJson(orderResponse);
        out.print(jsonResponse);
        out.flush();
    }
}
