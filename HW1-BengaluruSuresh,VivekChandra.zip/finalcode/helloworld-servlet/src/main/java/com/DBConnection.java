package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:sqlite:/Users/vivekchandrabs/Documents/IIT Chicago/CSP-584/HW1/helloworld-servlet/database.sqlite";  // Path to your SQLite database file

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC"); // Ensure the SQLite JDBC driver is loaded
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return DriverManager.getConnection(URL);
    }
}
