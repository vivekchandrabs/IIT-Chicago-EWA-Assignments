package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/customer/update-name")
public class UpdateCustomerNameServlet extends HttpServlet {

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read request body
        StringBuilder requestBody = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                requestBody.append(line);
            }
        }

        // Parse the request body to extract customer_id and new_name
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(requestBody.toString(), JsonObject.class);
        int customerId = jsonObject.get("customer_id").getAsInt();
        String newName = jsonObject.get("new_name").getAsString();

        // SQL to update the customer name
        String updateQuery = "UPDATE Customers SET name = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?";
        String selectQuery = "SELECT id, name, email, type, createdAt, updatedAt FROM Customers WHERE id = ?";

        try (Connection connection = DBConnection.getConnection()) {
            // Prepare and execute the update query
            PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
            updateStatement.setString(1, newName);
            updateStatement.setInt(2, customerId);

            int rowsUpdated = updateStatement.executeUpdate();
            if (rowsUpdated > 0) {
                // Fetch the updated customer information
                PreparedStatement selectStatement = connection.prepareStatement(selectQuery);
                selectStatement.setInt(1, customerId);
                ResultSet resultSet = selectStatement.executeQuery();

                if (resultSet.next()) {
                    // Create a customer object and populate it with data
                    Customer updatedCustomer = new Customer(
                            resultSet.getInt("id"),
                            resultSet.getString("name"),
                            resultSet.getString("email"),
                            resultSet.getString("type"),
                            resultSet.getString("createdAt"),
                            resultSet.getString("updatedAt")
                    );

                    // Convert the customer object to JSON and return it
                    String jsonResponse = gson.toJson(updatedCustomer);
                    out.print(jsonResponse);
                }
            } else {
                // If no rows were updated, return an error message
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print("{\"error\": \"Customer not found or no changes made.\"}");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"Unable to update customer name.\"}");
        }

        out.flush();
    }

    // Inner class for Customer
    class Customer {
        private int id;
        private String name;
        private String email;
        private String type;
        private String created_at;
        private String updated_at;

        public Customer(int id, String name, String email, String type, String created_at, String updated_at) {
            this.id = id;
            this.name = name;
            this.email = email;
            this.type = type;
            this.created_at = created_at;
            this.updated_at = updated_at;
        }
    }
}
