package com;

public class Product {
    private int id;
    private String name;
    private int categoryId;
    private int warrantyId;
    private double price;
    private String description;
    private String image;

    // Getters and setters
    public Product(int id, String name, int categoryId, int warrantyId, double price, String description, String image) {
        this.id = id;
        this.name = name;
        this.categoryId = categoryId;
        this.warrantyId = warrantyId;
        this.price = price;
        this.description = description;
        this.image = image;
    }

    // Getters and setters
}
