package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;

@WebServlet("/product/*")
public class ProductByIdServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Extract the product ID from the URL path parameter
        String pathInfo = req.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"error\": \"Product ID is required in the URL\"}");
            out.flush();
            return;
        }
        int productId = Integer.parseInt(pathInfo.substring(1));

        ProductWithDetails product = null;

        try (Connection connection = DBConnection.getConnection()) {
            // SQL query to fetch product, category, warranty details by product ID
            String query = "SELECT p.id, p.name, p.category_id, p.warranty_id, p.price, p.description, p.image, "
                    + "c.name AS category_name, "
                    + "w.name AS warranty_name "
                    + "FROM Products p "
                    + "JOIN Categories c ON p.category_id = c.id "
                    + "JOIN Warranties w ON p.warranty_id = w.id "
                    + "WHERE p.id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, productId);
            ResultSet resultSet = statement.executeQuery();

            // Check if the product was found
            if (resultSet.next()) {
                product = new ProductWithDetails(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("price"),
                        resultSet.getString("description"),
                        resultSet.getString("image"),
                        new Category(resultSet.getInt("category_id"), resultSet.getString("category_name")),
                        new Warranty(resultSet.getInt("warranty_id"), resultSet.getString("warranty_name"))
                );

                // Fetch accessories for the product
                product.setAccessories(getAccessoriesForProduct(connection, productId));
            } else {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print("{\"error\": \"Product not found\"}");
                out.flush();
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"An error occurred while fetching the product\"}");
            out.flush();
            return;
        }

        // Convert the product to JSON using Gson
        Gson gson = new Gson();
        String jsonResponse = gson.toJson(product);
        out.print(jsonResponse);
        out.flush();
    }

    // Method to fetch accessories for a given product
    private List<ProductAccessory> getAccessoriesForProduct(Connection connection, int productId) throws SQLException {
        List<ProductAccessory> accessories = new ArrayList<>();
        String accessoryQuery = "SELECT a.accessory_id, p.name, p.price, p.description, p.image "
                + "FROM Accessories a "
                + "JOIN Products p ON a.accessory_id = p.id "
                + "WHERE a.product_id = ?";
        PreparedStatement accessoryStatement = connection.prepareStatement(accessoryQuery);
        accessoryStatement.setInt(1, productId);
        ResultSet accessoryResultSet = accessoryStatement.executeQuery();

        while (accessoryResultSet.next()) {
            accessories.add(new ProductAccessory(
                    accessoryResultSet.getInt("accessory_id"),
                    accessoryResultSet.getString("name"),
                    accessoryResultSet.getDouble("price"),
                    accessoryResultSet.getString("description"),
                    accessoryResultSet.getString("image")
            ));
        }

        return accessories;
    }

    // Inner class for Product with category, warranty, and accessory details
    class ProductWithDetails {
        private int id;
        private String name;
        private double price;
        private String description;
        private String image;
        private Category category;
        private Warranty warranty;
        private List<ProductAccessory> accessories;

        public ProductWithDetails(int id, String name, double price, String description, String image, Category category, Warranty warranty) {
            this.id = id;
            this.name = name;
            this.price = price;
            this.description = description;
            this.image = image;
            this.category = category;
            this.warranty = warranty;
        }

        public void setAccessories(List<ProductAccessory> accessories) {
            this.accessories = accessories;
        }
    }

    // Inner class for Category
    class Category {
        private int id;
        private String name;

        public Category(int id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    // Inner class for Warranty
    class Warranty {
        private int id;
        private String name;

        public Warranty(int id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    // Inner class for Product Accessory
    class ProductAccessory {
        private int id;
        private String name;
        private double price;
        private String description;
        private String image;

        public ProductAccessory(int id, String name, double price, String description, String image) {
            this.id = id;
            this.name = name;
            this.price = price;
            this.description = description;
            this.image = image;
        }
    }
}
