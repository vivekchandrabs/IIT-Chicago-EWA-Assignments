package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;

@WebServlet("/customers/all")
public class GetAllCustomersServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();
        List<Customer> customers = new ArrayList<>();

        // SQL query to get all customers
        String query = "SELECT id, name, email, type, createdAt, updatedAt FROM Customers";

        try (Connection connection = DBConnection.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            // Process the result set
            while (resultSet.next()) {
                Customer customer = new Customer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("email"),
                        resultSet.getString("type"),
                        resultSet.getString("createdAt"),
                        resultSet.getString("updatedAt")
                );
                customers.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"Unable to fetch customer information.\"}");
            return;
        }

        // Convert the list of customers to JSON
        Gson gson = new Gson();
        String jsonResponse = gson.toJson(customers);
        out.print(jsonResponse);
        out.flush();
    }

    // Inner class to hold customer information
    class Customer {
        private int id;
        private String name;
        private String email;
        private String type;
        private String created_at;
        private String updated_at;

        public Customer(int id, String name, String email, String type, String created_at, String updated_at) {
            this.id = id;
            this.name = name;
            this.email = email;
            this.type = type;
            this.created_at = created_at;
            this.updated_at = updated_at;
        }
    }
}
