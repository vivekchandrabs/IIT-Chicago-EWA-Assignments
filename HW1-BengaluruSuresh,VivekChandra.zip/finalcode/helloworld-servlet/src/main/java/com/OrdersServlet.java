package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@WebServlet("/orders/all")
public class OrdersServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body to JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract customer_id from the JSON object
        int customerId = jsonObject.get("customer_id").getAsInt();

        List<Order> orderList = new ArrayList<>();

        try (Connection connection = DBConnection.getConnection()) {
            // SQL query to fetch orders for the given customer_id
            String query = "SELECT id, customer_id, products, payment, status FROM Orders WHERE customer_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, customerId);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                // Parse the products field from JSON string to JsonArray
                String productsJsonString = resultSet.getString("products");
                JsonArray productsJsonArray = JsonParser.parseString(productsJsonString).getAsJsonArray();

                // Enrich the products with product details from the Products table
                JsonArray detailedProducts = new JsonArray();
                for (int i = 0; i < productsJsonArray.size(); i++) {
                    JsonObject productObject = productsJsonArray.get(i).getAsJsonObject();
                    int productId = productObject.get("product_id").getAsInt();
                    int quantity = productObject.get("quantity").getAsInt();

                    // Fetch product details from the Products table
                    String productQuery = "SELECT id, name, price, description, image FROM Products WHERE id = ?";
                    PreparedStatement productStatement = connection.prepareStatement(productQuery);
                    productStatement.setInt(1, productId);
                    ResultSet productResult = productStatement.executeQuery();

                    if (productResult.next()) {
                        // Add detailed product information to the original product object
                        productObject.addProperty("name", productResult.getString("name"));
                        productObject.addProperty("price", productResult.getDouble("price"));
                        productObject.addProperty("description", productResult.getString("description"));
                        productObject.addProperty("image", productResult.getString("image"));
                        productObject.addProperty("quantity", quantity);  // Include the quantity from the order

                        // Add enriched product object to the detailedProducts array
                        detailedProducts.add(productObject);
                    }
                }

                // Add the order with detailed product info and status
                Order order = new Order(
                        resultSet.getInt("id"),
                        resultSet.getInt("customer_id"),
                        resultSet.getString("status"),  // Fetch the status of the order
                        detailedProducts,  // Add the detailed products directly in the products array
                        resultSet.getString("payment")
                );
                orderList.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Convert the order list to JSON using Gson
        String jsonResponse = gson.toJson(orderList);
        out.print(jsonResponse);
        out.flush();
    }

    // Inner class for Order
    class Order {
        private int id;
        private int customer_id;
        private String status;  // Add status field
        private JsonArray products;
        private String payment;

        public Order(int id, int customer_id, String status, JsonArray products, String payment) {
            this.id = id;
            this.customer_id = customer_id;
            this.status = status;  // Set status
            this.products = products;  // Use products array for detailed product info
            this.payment = payment;
        }
    }
}
