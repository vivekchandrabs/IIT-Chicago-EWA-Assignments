"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert("Customers", [
      {
        name: "John Doe",
        email: "john@example.com",
        type: "customer",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Jane Smith",
        email: "jane@example.com",
        type: "customer",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Alice Johnson",
        email: "alice@example.com",
        type: "salesmen",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Bob Brown",
        email: "bob@example.com",
        type: "manager",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Charlie Davis",
        email: "charlie@example.com",
        type: "customer",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "David Wilson",
        email: "david@example.com",
        type: "customer",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Eve Taylor",
        email: "eve@example.com",
        type: "salesmen",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Frank Moore",
        email: "frank@example.com",
        type: "manager",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Grace Lee",
        email: "grace@example.com",
        type: "customer",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Hank Miller",
        email: "hank@example.com",
        type: "customer",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete("Customers", null, {});
  },
};
