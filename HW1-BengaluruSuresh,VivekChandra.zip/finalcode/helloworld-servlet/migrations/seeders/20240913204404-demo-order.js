"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Fetch existing customer IDs
    const customers = await queryInterface.sequelize.query(
      "SELECT id FROM Customers",
      { type: Sequelize.QueryTypes.SELECT }
    );

    // Fetch existing delivery type IDs
    const deliveryTypes = await queryInterface.sequelize.query(
      "SELECT id FROM DeliveryTypes",
      { type: Sequelize.QueryTypes.SELECT }
    );

    // Fetch existing product IDs
    const products = await queryInterface.sequelize.query(
      "SELECT id FROM Products",
      { type: Sequelize.QueryTypes.SELECT }
    );

    // Map IDs to arrays
    const customerIds = customers.map((c) => c.id);
    const deliveryTypeIds = deliveryTypes.map((d) => d.id);
    const productIds = products.map((p) => p.id);

    // Ensure there are enough records in the related tables
    if (
      customerIds.length === 0 ||
      deliveryTypeIds.length === 0 ||
      productIds.length === 0
    ) {
      throw new Error("Not enough data in related tables to create orders.");
    }

    // Generate sample orders
    const orders = [];
    for (let i = 0; i < 10; i++) {
      // Randomly pick customer, delivery type, and products
      const customerId =
        customerIds[Math.floor(Math.random() * customerIds.length)];
      const deliveryTypeId =
        deliveryTypeIds[Math.floor(Math.random() * deliveryTypeIds.length)];
      const product = productIds[Math.floor(Math.random() * productIds.length)];

      // Create a sample order
      orders.push({
        customer_id: customerId,
        products: JSON.stringify([
          {
            product_id: product,
            quantity: Math.floor(Math.random() * 10) + 1, // Random quantity between 1 and 10
          },
        ]),
        payment: (Math.random() * 100).toFixed(2), // Random payment amount
        delivery_type_id: deliveryTypeId,
        status: "pending", // Default status
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    // Insert the orders
    await queryInterface.bulkInsert("Orders", orders, {});
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete("Orders", null, {});
  },
};
