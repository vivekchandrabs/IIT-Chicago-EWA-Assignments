"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Fetch existing product IDs
    const products = await queryInterface.sequelize.query(
      "SELECT id FROM Products",
      { type: Sequelize.QueryTypes.SELECT }
    );

    // Map product IDs to array
    const productIds = products.map((p) => p.id);

    // Check if there are enough products to create accessories
    if (productIds.length < 2) {
      throw new Error("Not enough products available to create accessories.");
    }

    // Generate sample accessories
    const accessories = [];
    for (let i = 0; i < productIds.length; i++) {
      // Ensure that we don’t create an accessory for a product that is itself an accessory
      const randomProductId =
        productIds[Math.floor(Math.random() * productIds.length)];
      const randomAccessoryId =
        productIds[Math.floor(Math.random() * productIds.length)];

      // Make sure the accessory_id is different from product_id
      if (randomProductId !== randomAccessoryId) {
        accessories.push({
          product_id: randomProductId,
          accessory_id: randomAccessoryId,
          createdAt: new Date(),
          updatedAt: new Date(),
        });
      }
    }

    // Insert the accessories
    await queryInterface.bulkInsert("Accessories", accessories, {});
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete("Accessories", null, {});
  },
};
