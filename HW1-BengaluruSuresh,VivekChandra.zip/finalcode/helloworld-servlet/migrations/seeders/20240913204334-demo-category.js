"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert("Categories", [
      { name: "Electronics", createdAt: new Date(), updatedAt: new Date() },
      { name: "Furniture", createdAt: new Date(), updatedAt: new Date() },
      { name: "Clothing", createdAt: new Date(), updatedAt: new Date() },
      { name: "Toys", createdAt: new Date(), updatedAt: new Date() },
      { name: "Books", createdAt: new Date(), updatedAt: new Date() },
      { name: "Groceries", createdAt: new Date(), updatedAt: new Date() },
      { name: "Health", createdAt: new Date(), updatedAt: new Date() },
      { name: "Sports", createdAt: new Date(), updatedAt: new Date() },
      { name: "Beauty", createdAt: new Date(), updatedAt: new Date() },
      { name: "Automotive", createdAt: new Date(), updatedAt: new Date() },
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete("Categories", null, {});
  },
};
