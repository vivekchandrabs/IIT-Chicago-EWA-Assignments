"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert("Warranties", [
      { name: "1 Year Warranty", createdAt: new Date(), updatedAt: new Date() },
      {
        name: "2 Years Warranty",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "3 Years Warranty",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Lifetime Warranty",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "6 Months Warranty",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "30 Days Warranty",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Extended Warranty",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Accidental Damage Warranty",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Replacement Warranty",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Service Warranty",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete("Warranties", null, {});
  },
};
