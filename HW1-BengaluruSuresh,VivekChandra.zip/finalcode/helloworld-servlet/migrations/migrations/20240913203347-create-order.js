"use strict";
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("Orders", {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      customer_id: {
        type: Sequelize.INTEGER,
        references: {
          model: "Customers",
          key: "id",
        },
        onDelete: "CASCADE",
      },
      products: {
        type: Sequelize.JSON,
        allowNull: false,
      },
      payment: {
        type: Sequelize.DECIMAL,
        allowNull: false,
      },
      delivery_type_id: {
        type: Sequelize.INTEGER,
        references: {
          model: "DeliveryTypes",
          key: "id",
        },
        allowNull: true,
        onDelete: "SET NULL",
      },
      status: {
        type: Sequelize.STRING, // You can use ENUM if you want specific values
        allowNull: false,
        defaultValue: "pending", // Default value for new orders
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("Orders");
  },
};
