package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/customer/create")
public class CustomerCreateServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body to JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract customer details from the JSON object
        String name = jsonObject.get("name").getAsString();
        String email = jsonObject.get("email").getAsString();
        int creatorCustomerId = jsonObject.get("customer_id").getAsInt(); // The ID of the person creating the account

        String creatorType = null;

        try (Connection connection = DBConnection.getConnection()) {
            // Check if the email already exists
            String checkEmailQuery = "SELECT id FROM Customers WHERE email = ?";
            PreparedStatement checkEmailStmt = connection.prepareStatement(checkEmailQuery);
            checkEmailStmt.setString(1, email);
            ResultSet emailResultSet = checkEmailStmt.executeQuery();

            if (emailResultSet.next()) {
                // Email already exists, return a 400 error
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"message\": \"Email already exists\"}");
                out.flush();
                return;
            }

            // Check the type of the creator
            String checkCreatorQuery = "SELECT type FROM Customers WHERE id = ?";
            PreparedStatement checkCreatorStmt = connection.prepareStatement(checkCreatorQuery);
            checkCreatorStmt.setInt(1, creatorCustomerId);
            ResultSet creatorResultSet = checkCreatorStmt.executeQuery();

            if (creatorResultSet.next()) {
                creatorType = creatorResultSet.getString("type");
            } else {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"message\": \"Invalid creator customer_id\"}");
                out.flush();
                return;
            }

            // Validate the creator's type
            if (!creatorType.equals("salesmen") && !creatorType.equals("manager")) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"message\": \"Only of type salesmen and manager can create account for customer\"}");
                out.flush();
                return;
            }

            // Insert the new customer with createdAt and updatedAt fields
            String insertCustomerQuery = "INSERT INTO Customers (name, email, type, createdAt, updatedAt) VALUES (?, ?, 'customer', datetime('now'), datetime('now'))";
            PreparedStatement insertStmt = connection.prepareStatement(insertCustomerQuery, PreparedStatement.RETURN_GENERATED_KEYS);
            insertStmt.setString(1, name);
            insertStmt.setString(2, email);
            insertStmt.executeUpdate();

            // Get the generated customer ID
            ResultSet generatedKeys = insertStmt.getGeneratedKeys();
            int newCustomerId = 0;
            if (generatedKeys.next()) {
                newCustomerId = generatedKeys.getInt(1);
            }

            // Fetch the newly inserted customer including the createdAt and updatedAt timestamps
            String fetchCustomerQuery = "SELECT id, name, email, type, createdAt, updatedAt FROM Customers WHERE id = ?";
            PreparedStatement fetchStmt = connection.prepareStatement(fetchCustomerQuery);
            fetchStmt.setInt(1, newCustomerId);
            ResultSet customerResultSet = fetchStmt.executeQuery();

            if (customerResultSet.next()) {
                JsonObject customerResponse = new JsonObject();
                customerResponse.addProperty("id", customerResultSet.getInt("id"));
                customerResponse.addProperty("name", customerResultSet.getString("name"));
                customerResponse.addProperty("email", customerResultSet.getString("email"));
                customerResponse.addProperty("type", customerResultSet.getString("type"));
                customerResponse.addProperty("createdAt", customerResultSet.getString("createdAt"));
                customerResponse.addProperty("updatedAt", customerResultSet.getString("updatedAt"));

                // Send the response
                String jsonResponse = gson.toJson(customerResponse);
                out.print(jsonResponse);
                out.flush();
            }

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"message\": \"Error creating customer\"}");
            out.flush();
        }
    }
}
