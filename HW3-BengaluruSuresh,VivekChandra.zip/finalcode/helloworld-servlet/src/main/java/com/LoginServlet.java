package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Set CORS headers to allow requests from any domain
        resp.setHeader("Access-Control-Allow-Origin", "*");
        resp.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        resp.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body to JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract name and email from the JSON object
        String name = jsonObject.get("name").getAsString();
        String email = jsonObject.get("email").getAsString();

        Customer customer = null;

        try (Connection connection = DBConnection.getConnection()) {
            // SQL query to fetch customer details based on name and email
            String query = "SELECT id, name, email, type FROM Customers WHERE name = ? AND email = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, email);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                customer = new Customer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("email"),
                        resultSet.getString("type")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Convert the customer object to JSON using Gson
        String jsonResponse = gson.toJson(customer);
        out.print(jsonResponse);
        out.flush();
    }

    // Inner class for Customer
    class Customer {
        private int id;
        private String name;
        private String email;
        private String type;

        public Customer(int id, String name, String email, String type) {
            this.id = id;
            this.name = name;
            this.email = email;
            this.type = type;
        }
    }
}
