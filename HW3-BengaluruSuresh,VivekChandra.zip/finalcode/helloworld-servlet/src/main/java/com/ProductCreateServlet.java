package com;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/product/create")
public class ProductCreateServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        // Read the request body
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }

        // Parse the request body to JSON
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(stringBuilder.toString(), JsonObject.class);

        // Extract product details from the JSON object
        String name = jsonObject.get("name").getAsString();
        int categoryId = jsonObject.get("category_id").getAsInt();
        int warrantyId = jsonObject.get("warranty_id").getAsInt();
        double price = jsonObject.get("price").getAsDouble();
        String description = jsonObject.get("description").getAsString();
        String image = jsonObject.get("image").getAsString();
        int creatorCustomerId = jsonObject.get("customer_id").getAsInt(); // Customer ID of the person creating the product

        String creatorType = null;

        try (Connection connection = DBConnection.getConnection()) {
            // Check the type of the creator
            String checkCreatorQuery = "SELECT type FROM Customers WHERE id = ?";
            PreparedStatement checkCreatorStmt = connection.prepareStatement(checkCreatorQuery);
            checkCreatorStmt.setInt(1, creatorCustomerId);
            ResultSet creatorResultSet = checkCreatorStmt.executeQuery();

            if (creatorResultSet.next()) {
                creatorType = creatorResultSet.getString("type");
            } else {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"message\": \"Invalid creator customer_id\"}");
                out.flush();
                return;
            }

            // Validate that only manager can create a product
            if (!creatorType.equals("manager")) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"message\": \"Only managers can create a product\"}");
                out.flush();
                return;
            }

            // Insert the product with createdAt and updatedAt fields
            String insertProductQuery = "INSERT INTO Products (name, category_id, warranty_id, price, description, image, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))";
            PreparedStatement insertStmt = connection.prepareStatement(insertProductQuery, PreparedStatement.RETURN_GENERATED_KEYS);
            insertStmt.setString(1, name);
            insertStmt.setInt(2, categoryId);
            insertStmt.setInt(3, warrantyId);
            insertStmt.setDouble(4, price);
            insertStmt.setString(5, description);
            insertStmt.setString(6, image);
            insertStmt.executeUpdate();

            // Get the generated product ID
            ResultSet generatedKeys = insertStmt.getGeneratedKeys();
            int newProductId = 0;
            if (generatedKeys.next()) {
                newProductId = generatedKeys.getInt(1);
            }

            // Fetch the newly inserted product along with category and warranty information
            String fetchProductQuery = "SELECT p.id, p.name, p.price, p.description, p.image, p.createdAt, p.updatedAt, c.name as category_name, w.name as warranty_name " +
                    "FROM Products p " +
                    "JOIN Categories c ON p.category_id = c.id " +
                    "JOIN Warranties w ON p.warranty_id = w.id " +
                    "WHERE p.id = ?";
            PreparedStatement fetchStmt = connection.prepareStatement(fetchProductQuery);
            fetchStmt.setInt(1, newProductId);
            ResultSet productResultSet = fetchStmt.executeQuery();

            if (productResultSet.next()) {
                JsonObject productResponse = new JsonObject();
                productResponse.addProperty("id", productResultSet.getInt("id"));
                productResponse.addProperty("name", productResultSet.getString("name"));
                productResponse.addProperty("price", productResultSet.getDouble("price"));
                productResponse.addProperty("description", productResultSet.getString("description"));
                productResponse.addProperty("image", productResultSet.getString("image"));
                productResponse.addProperty("createdAt", productResultSet.getString("createdAt"));
                productResponse.addProperty("updatedAt", productResultSet.getString("updatedAt"));

                // Add nested category information
                JsonObject category = new JsonObject();
                category.addProperty("category_id", categoryId);
                category.addProperty("category_name", productResultSet.getString("category_name"));
                productResponse.add("category", category);

                // Add nested warranty information
                JsonObject warranty = new JsonObject();
                warranty.addProperty("warranty_id", warrantyId);
                warranty.addProperty("warranty_name", productResultSet.getString("warranty_name"));
                productResponse.add("warranty", warranty);

                // Send the response
                String jsonResponse = gson.toJson(productResponse);
                out.print(jsonResponse);
                out.flush();
            }

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"message\": \"Error creating product\"}");
            out.flush();
        }
    }
}
