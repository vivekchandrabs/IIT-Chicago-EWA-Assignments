"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Fetch existing customer IDs
    const customers = await queryInterface.sequelize.query(
        "SELECT id, name FROM Customers",
        { type: Sequelize.QueryTypes.SELECT }
    );

    // Fetch existing delivery type IDs
    const deliveryTypes = await queryInterface.sequelize.query(
        "SELECT id FROM DeliveryTypes",
        { type: Sequelize.QueryTypes.SELECT }
    );

    // Fetch existing product IDs
    const products = await queryInterface.sequelize.query(
        "SELECT id FROM Products",
        { type: Sequelize.QueryTypes.SELECT }
    );

    // Fetch existing store location IDs
    const storeLocations = await queryInterface.sequelize.query(
        "SELECT id FROM StoreLocation",
        { type: Sequelize.QueryTypes.SELECT }
    );

    // Map IDs to arrays
    const customerIds = customers.map((c) => c.id);
    const customerNames = customers.map((c) => c.name);
    const deliveryTypeIds = deliveryTypes.map((d) => d.id);
    const productIds = products.map((p) => p.id);
    const storeLocationIds = storeLocations.map((s) => s.id);

    // Ensure there are enough records in the related tables
    if (
        customerIds.length === 0 ||
        deliveryTypeIds.length === 0 ||
        productIds.length === 0 ||
        storeLocationIds.length === 0
    ) {
      throw new Error("Not enough data in related tables to create orders.");
    }

    // Generate sample orders
    const orders = [];
    for (let i = 0; i < 20; i++) {  // Change 10 to 20
      // Randomly pick customer, delivery type, products, and store location
      const customerIndex = Math.floor(Math.random() * customerIds.length);
      const customerId = customerIds[customerIndex];
      const customerName = customerNames[customerIndex];
      const deliveryTypeId =
          deliveryTypeIds[Math.floor(Math.random() * deliveryTypeIds.length)];
      const product = productIds[Math.floor(Math.random() * productIds.length)];
      const storeLocationId =
          storeLocationIds[Math.floor(Math.random() * storeLocationIds.length)];

      // Create random credit card number, zip code, and address
      const creditCardNumber = `411111111111${Math.floor(
          Math.random() * 10000
      )}`; // Random 16-digit number
      const zipCode = `${Math.floor(10000 + Math.random() * 90000)}`; // Random 5-digit zip code
      const address = `123 Main St, Apt ${Math.floor(Math.random() * 100)}`; // Random address

      // Create a sample order
      orders.push({
        customer_id: customerId,
        customer_name: customerName,
        products: JSON.stringify([
          {
            product_id: product,
            quantity: Math.floor(Math.random() * 10) + 1, // Random quantity between 1 and 10
          },
        ]),
        payment: (Math.random() * 100).toFixed(2), // Random payment amount
        delivery_type_id: deliveryTypeId,
        store_location_id: storeLocationId, // Random store location
        status: "pending", // Default status
        credit_card_number: creditCardNumber,
        zip_code: zipCode,
        address: address,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    // Insert the orders
    await queryInterface.bulkInsert("Orders", orders, {});
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete("Orders", null, {});
  },
};
