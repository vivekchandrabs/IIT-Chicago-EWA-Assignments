'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    const stores = [
      { name: 'Main Street Store', location: '123 Main St, Springfield' },
      { name: 'Downtown Plaza', location: '456 Plaza Rd, Metropolis' },
      { name: 'Market Square', location: '789 Market St, Gotham' },
      { name: 'Sunset Mall', location: '101 Sunset Blvd, Los Angeles' },
      { name: 'Oceanview Store', location: '202 Ocean Ave, Miami' },
      { name: 'Tech Plaza', location: '303 Silicon St, San Francisco' },
      { name: 'City Center', location: '404 City Center, New York' },
      { name: 'Hilltop Store', location: '505 Hilltop Dr, Denver' },
      { name: 'Seaside Store', location: '606 Seaside Rd, Seattle' },
      { name: 'Riverside Store', location: '707 Riverside Ave, Portland' },
      { name: 'Midtown Shop', location: '808 Midtown Ln, Chicago' },
      { name: 'Mountain View Plaza', location: '909 Mountain View St, Boulder' },
      { name: 'Bayview Store', location: '111 Bayview Rd, San Diego' },
      { name: 'Pinewood Plaza', location: '121 Pinewood Ln, Houston' },
      { name: 'Lakeside Store', location: '131 Lakeside Dr, Austin' },
      { name: 'Uptown Mall', location: '141 Uptown Ave, Dallas' },
      { name: 'Green Valley Store', location: '151 Green Valley Rd, Phoenix' },
      { name: 'Old Town Plaza', location: '161 Old Town St, Philadelphia' },
      { name: 'Broadway Store', location: '171 Broadway, Nashville' },
      { name: 'Capitol Plaza', location: '181 Capitol Ave, Washington DC' }
    ];

    const storesWithTimestamps = stores.map(store => ({
      ...store,
      createdAt: new Date(),
      updatedAt: new Date()
    }));

    await queryInterface.bulkInsert('StoreLocation', storesWithTimestamps, {});
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('StoreLocation', null, {});
  }
};
