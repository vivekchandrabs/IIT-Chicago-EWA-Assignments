"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Fetch existing category and warranty IDs
    const categories = await queryInterface.sequelize.query(
        "SELECT id FROM Categories",
        { type: Sequelize.QueryTypes.SELECT }
    );

    const warranties = await queryInterface.sequelize.query(
        "SELECT id FROM Warranties",
        { type: Sequelize.QueryTypes.SELECT }
    );

    // Map IDs to arrays
    const categoryIds = categories.map((c) => c.id);
    const warrantyIds = warranties.map((w) => w.id);

    // Check if there are categories and warranties to choose from
    if (categoryIds.length === 0 || warrantyIds.length === 0) {
      throw new Error(
          "No categories or warranties available to populate products."
      );
    }

    // Helper function to generate a rebate less than the price
    const calculateRebate = (price) => {
      const priceValue = parseFloat(price); // Convert price to float
      const rebate = (Math.random() * 0.5 * priceValue).toFixed(2); // Random rebate between 1% and 50% of the price
      return parseFloat(rebate);
    };

    // Define an array of realistic product data with valid image URLs
    const products = [
      {
        name: "Wireless Headphones",
        category_id: categoryIds[Math.floor(Math.random() * categoryIds.length)],
        warranty_id: warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "59.99",
        description: "High-quality wireless headphones with noise cancellation and long battery life.",
        image: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MQTQ3?wid=1144&hei=1144&fmt=jpeg&qlt=90&.v=1687660671363",
        like_count: Math.floor(Math.random() * 500),
        stock: Math.floor(Math.random() * 100) + 1,
        has_rebate: Math.random() > 0.5,
        rebate: Math.random() > 0.5 ? calculateRebate("59.99") : null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "4K Ultra HD Smart TV",
        category_id: categoryIds[Math.floor(Math.random() * categoryIds.length)],
        warranty_id: warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "799.99",
        description: "55-inch 4K UHD smart TV with vibrant colors and built-in streaming apps.",
        image: "https://as2.ftcdn.net/v2/jpg/01/51/00/87/1000_F_151008771_Kvl6PeN8PeXL7cfeqtKJloSX7UDgHDxS.jpg",
        like_count: Math.floor(Math.random() * 500),
        stock: Math.floor(Math.random() * 100) + 1,
        has_rebate: Math.random() > 0.5,
        rebate: Math.random() > 0.5 ? calculateRebate("799.99") : null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Gaming Laptop",
        category_id: categoryIds[Math.floor(Math.random() * categoryIds.length)],
        warranty_id: warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "1299.99",
        description: "High-performance gaming laptop with NVIDIA RTX graphics and 16GB RAM.",
        image: "https://i.pcmag.com/imagery/roundups/01hiB08j7yaJGJmPl2YhRRH-59..v1713199550.jpg",
        like_count: Math.floor(Math.random() * 500),
        stock: Math.floor(Math.random() * 100) + 1,
        has_rebate: Math.random() > 0.5,
        rebate: Math.random() > 0.5 ? calculateRebate("1299.99") : null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Smartphone",
        category_id: categoryIds[Math.floor(Math.random() * categoryIds.length)],
        warranty_id: warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "999.99",
        description: "Latest model smartphone with 128GB storage and a stunning OLED display.",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQXJsFtjFfWFldbhVVE753SrvFQ6DX1Dw6Hw&s",
        like_count: Math.floor(Math.random() * 500),
        stock: Math.floor(Math.random() * 100) + 1,
        has_rebate: Math.random() > 0.5,
        rebate: Math.random() > 0.5 ? calculateRebate("999.99") : null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Smartwatch",
        category_id: categoryIds[Math.floor(Math.random() * categoryIds.length)],
        warranty_id: warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "199.99",
        description: "Stylish smartwatch with health monitoring and fitness tracking features.",
        image: "https://cdn.mos.cms.futurecdn.net/FkGweMeB7hdPgaSFQdgsfj.jpg",
        like_count: Math.floor(Math.random() * 500),
        stock: Math.floor(Math.random() * 100) + 1,
        has_rebate: Math.random() > 0.5,
        rebate: Math.random() > 0.5 ? calculateRebate("199.99") : null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Bluetooth Speaker",
        category_id: categoryIds[Math.floor(Math.random() * categoryIds.length)],
        warranty_id: warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "49.99",
        description: "Portable Bluetooth speaker with deep bass and a 10-hour battery life.",
        image: "https://media.istockphoto.com/id/1059154330/photo/boombox.jpg?s=612x612&w=0&k=20&c=AYwVrPpREeFXXP0j8rC8R3eF_9WUVghBXPndGqZYSJw=",
        like_count: Math.floor(Math.random() * 500),
        stock: Math.floor(Math.random() * 100) + 1,
        has_rebate: Math.random() > 0.5,
        rebate: Math.random() > 0.5 ? calculateRebate("49.99") : null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Smart Drone with Camera",
        category_id: categoryIds[Math.floor(Math.random() * categoryIds.length)],
        warranty_id: warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "399.99",
        description: "High-definition drone with a 4K camera, GPS, and real-time video transmission.",
        image: "https://m.media-amazon.com/images/I/61vufzhhQ6L._AC_UF894,1000_QL80_.jpg",
        like_count: Math.floor(Math.random() * 500),
        stock: Math.floor(Math.random() * 100) + 1,
        has_rebate: Math.random() > 0.5,
        rebate: Math.random() > 0.5 ? calculateRebate("399.99") : null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Smart Electric Scooter",
        category_id: categoryIds[Math.floor(Math.random() * categoryIds.length)],
        warranty_id: warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "499.99",
        description: "Electric scooter with a top speed of 25km/h and a 30km range.",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7Hkh4B0cwm4A_P3ktaSdTFa0per30-DooQg&s",
        like_count: Math.floor(Math.random() * 500),
        stock: Math.floor(Math.random() * 100) + 1,
        has_rebate: Math.random() > 0.5,
        rebate: Math.random() > 0.5 ? calculateRebate("499.99") : null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Smart Digital Camera",
        category_id: categoryIds[Math.floor(Math.random() * categoryIds.length)],
        warranty_id: warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "599.99",
        description: "DSLR camera with 24MP resolution and 4K video recording capabilities.",
        image: "https://m.media-amazon.com/images/I/61FignAicXL.jpg",
        like_count: Math.floor(Math.random() * 500),
        stock: Math.floor(Math.random() * 100) + 1,
        has_rebate: Math.random() > 0.5,
        rebate: Math.random() > 0.5 ? calculateRebate("599.99") : null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Smart Fitness Tracker",
        category_id: categoryIds[Math.floor(Math.random() * categoryIds.length)],
        warranty_id: warrantyIds[Math.floor(Math.random() * warrantyIds.length)],
        price: "89.99",
        description: "Fitness tracker with heart rate monitor, sleep tracking, and waterproof design.",
        image: "https://m.media-amazon.com/images/I/616xF-WkW5L.jpg",
        like_count: Math.floor(Math.random() * 500),
        stock: Math.floor(Math.random() * 100) + 1,
        has_rebate: Math.random() > 0.5,
        rebate: Math.random() > 0.5 ? calculateRebate("89.99") : null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    // Insert the products
    await queryInterface.bulkInsert("Products", products, {});
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete("Products", null, {});
  },
};
