import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

function Navbar() {
    const navigate = useNavigate();
    const location = useLocation();
    const query = new URLSearchParams(location.search);
    const customerId = query.get("customer_id");
    const userType = query.get("type");

    const [searchTerm, setSearchTerm] = useState('');
    const [searchResults, setSearchResults] = useState([]);

    const handleLogout = () => {
        navigate('/login');
    };

    if (location.pathname === '/login') {
        return null; // Do not render navbar on login page
    }

    const navItems = {
        customer: [
            { name: 'Products', path: '/products' },
            { name: 'Orders', path: '/orders' },
            { name: 'Cart', path: '/cart' },
            { name: 'Trending', path: '/trending' }, // Added Trending Page
            { name: 'Logout', action: handleLogout },
        ],
        salesmen: [
            { name: 'Products', path: '/products' },
            { name: 'Orders', path: '/orders' },
            { name: 'Cart', path: '/cart' },
            { name: 'Customers', path: '/customers' },
            { name: 'Trending', path: '/trending' }, // Added Trending Page
            { name: 'Logout', action: handleLogout },
        ],
        manager: [
            { name: 'Products', path: '/products' },
            { name: 'Orders', path: '/orders' },
            { name: 'Edit Product', path: '/edit-product' },
            { name: 'Cart', path: '/cart' },
            { name: 'Customers', path: '/customers' },
            { name: 'Trending', path: '/trending' }, // Added Trending Page
            {name: "InventoryReport", path: "/inventory-report"},
            {name: "SalesReport", path: "/sales-report"},
            { name: 'Logout', action: handleLogout },
        ],
    };

    const currentNavItems = navItems[userType] || [];

    const handleSearchChange = (e) => {
        const value = e.target.value;
        setSearchTerm(value);

        if (value) {
            fetch(`http://localhost:8080/helloworld-servlet/api/ajax-utility?query=${value}`)
                .then(response => response.json())
                .then(data => setSearchResults(data.slice(0, 6)))
                .catch(error => console.error('Error fetching search results:', error));
        } else {
            setSearchResults([]);
        }
    };

    const handleResultClick = (id) => {
        navigate(`/product/${id}?customer_id=${customerId}&type=${userType}`);
        setSearchTerm(''); // Clear search input
        setSearchResults([]); // Clear search results
    };

    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
            <div className="container-fluid">
                <a className="navbar-brand" href="#">CSP-587 Stores</a>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav me-auto">
                        {currentNavItems.map((item, index) => (
                            <li className="nav-item" key={index}>
                                {item.path ? (
                                    <a className="nav-link" href={`${item.path}?customer_id=${customerId}&type=${userType}`}>
                                        {item.name}
                                    </a>
                                ) : (
                                    <button className="nav-link btn btn-link" onClick={item.action}>
                                        {item.name}
                                    </button>
                                )}
                            </li>
                        ))}
                    </ul>
                    <form className="d-flex position-relative">
                        <input
                            className="form-control me-2"
                            type="search"
                            placeholder="Search"
                            aria-label="Search"
                            value={searchTerm}
                            onChange={handleSearchChange}
                        />
                        {searchResults.length > 0 && (
                            <ul className="list-group position-absolute w-100" style={{ top: '100%', zIndex: 1000 }}>
                                {searchResults.map((result) => (
                                    <li
                                        key={result.id}
                                        className="list-group-item list-group-item-action"
                                        style={{ cursor: 'pointer' }}
                                        onClick={() => handleResultClick(result.id)}
                                    >
                                        {result.name}
                                    </li>
                                ))}
                            </ul>
                        )}
                    </form>
                </div>
            </div>
        </nav>
    );
}

export default Navbar;