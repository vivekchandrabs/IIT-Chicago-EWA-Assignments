import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import 'bootstrap/dist/css/bootstrap.min.css';

// Register the components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

function InventoryReport() {
    const [products, setProducts] = useState([]);
    const [saleProducts, setSaleProducts] = useState([]);
    const [rebateProducts, setRebateProducts] = useState([]);

    useEffect(() => {
        fetch('http://localhost:8080/helloworld-servlet/api/inventory-report')
            .then(response => response.json())
            .then(data => {
                setProducts(data.products);
                setSaleProducts(data.saleProducts);
                setRebateProducts(data.products.filter(product => product.rebate > 0));
            })
            .catch(error => console.error('Error fetching data:', error));
    }, []);

    const productNames = products.map(product => product.name);
    const productStocks = products.map(product => product.stock);

    const data = {
        labels: productNames,
        datasets: [
            {
                label: 'Stock',
                data: productStocks,
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
            },
        ],
    };

    return (
        <div className="container mt-4">
            <h2>Inventory Report</h2>
            <table className="table table-bordered">
                <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Product Price</th>
                    <th>Product Stock</th>
                </tr>
                </thead>
                <tbody>
                {products.map((product, index) => (
                    <tr key={index}>
                        <td>{product.name}</td>
                        <td>${product.price.toFixed(2)}</td>
                        <td>{product.stock}</td>
                    </tr>
                ))}
                </tbody>
            </table>

            <h2>Sale Products</h2>
            <table className="table table-bordered">
                <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Product Price</th>
                    <th>Product Stock</th>
                </tr>
                </thead>
                <tbody>
                {saleProducts.map((product, index) => (
                    <tr key={index}>
                        <td>{product.name}</td>
                        <td>${product.price.toFixed(2)}</td>
                        <td>{product.stock}</td>
                    </tr>
                ))}
                </tbody>
            </table>

            <h2>Products with Rebate</h2>
            <table className="table table-bordered">
                <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Product Price</th>
                    <th>Product Stock</th>
                    <th>Rebate</th>
                </tr>
                </thead>
                <tbody>
                {rebateProducts.map((product, index) => (
                    <tr key={index}>
                        <td>{product.name}</td>
                        <td>${product.price.toFixed(2)}</td>
                        <td>{product.stock}</td>
                        <td>${product.rebate.toFixed(2)}</td>
                    </tr>
                ))}
                </tbody>
            </table>

            <h2>Product Stock Chart</h2>
            <Bar data={data} />
        </div>
    );
}

export default InventoryReport;