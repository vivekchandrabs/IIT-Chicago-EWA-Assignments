import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

function EditProduct() {
    const [products, setProducts] = useState([]);
    const [editingProduct, setEditingProduct] = useState(null);
    const [newProduct, setNewProduct] = useState({
        name: "",
        category_id: 1,
        warranty_id: 1,
        price: "",
        description: "",
        image: "",
    });
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        fetch("http://localhost:8080/helloworld-servlet/product/all")
            .then((response) => response.json())
            .then((data) => setProducts(data))
            .catch((error) => console.error("Error fetching products:", error));
    }, []);

    const query = new URLSearchParams(location.search);
    const customerId = parseInt(query.get("customer_id"), 10);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        if (editingProduct) {
            setEditingProduct({ ...editingProduct, [name]: value });
        } else {
            setNewProduct({ ...newProduct, [name]: value });
        }
    };

    const handleEditClick = (product) => {
        setEditingProduct({ ...product, customer_id: customerId });
    };

    const handleUpdateProduct = async () => {
        try {
            const response = await fetch("http://localhost:8080/helloworld-servlet/product/update", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(editingProduct),
            });

            if (response.ok) {
                alert("Product updated successfully.");
                setProducts(products.map((p) => (p.id === editingProduct.id ? editingProduct : p)));
                setEditingProduct(null);
            } else {
                alert("Failed to update product.");
            }
        } catch (error) {
            console.error("Error updating product:", error);
        }
    };

    const handleAddProduct = async () => {
        try {
            const response = await fetch("http://localhost:8080/helloworld-servlet/product/create", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    ...newProduct,
                    customer_id: customerId,
                }),
            });

            if (response.ok) {
                alert("Product added successfully.");
                setNewProduct({
                    name: "",
                    category_id: 1,
                    warranty_id: 1,
                    price: "",
                    description: "",
                    image: "",
                });
            } else {
                alert("Failed to add product.");
            }
        } catch (error) {
            console.error("Error adding product:", error);
        }
    };

    const handleDeleteProduct = async (productId) => {
        if (window.confirm("Are you sure you want to delete this product?")) {
            try {
                const response = await fetch("http://localhost:8080/helloworld-servlet/product/delete", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        product_id: productId,
                        customer_id: customerId,
                    }),
                });

                if (response.ok) {
                    alert("Product deleted successfully.");
                    setProducts(products.filter((p) => p.id !== productId));
                } else {
                    alert("Failed to delete product.");
                }
            } catch (error) {
                console.error("Error deleting product:", error);
            }
        }
    };

    return (
        <div className="d-flex p-3">
            <div className="flex-grow-1 d-grid gap-3" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
                {products.map((product) => (
                    <div key={product.id} className="border rounded overflow-hidden">
                        <img src={product.image} alt={product.name} className="w-100" style={{ height: "200px", objectFit: "cover" }} />
                        <div className="p-3">
                            {editingProduct && editingProduct.id === product.id ? (
                                <>
                                    <input type="text" name="name" value={editingProduct.name} onChange={handleInputChange} className="form-control mb-2" />
                                    <input type="number" name="price" value={editingProduct.price} onChange={handleInputChange} className="form-control mb-2" />
                                    <input type="text" name="description" value={editingProduct.description} onChange={handleInputChange} className="form-control mb-2" />
                                    <input type="text" name="image" value={editingProduct.image} onChange={handleInputChange} className="form-control mb-2" />
                                    <button onClick={handleUpdateProduct} className="btn btn-success w-100 mb-2">Submit</button>
                                </>
                            ) : (
                                <>
                                    <h3>{product.name}</h3>
                                    <p>${product.price.toFixed(2)}</p>
                                    <button onClick={() => handleEditClick(product)} className="btn btn-primary w-100 mb-2">Edit</button>
                                </>
                            )}
                            <button onClick={() => handleDeleteProduct(product.id)} className="btn btn-danger w-100">Delete</button>
                        </div>
                    </div>
                ))}
            </div>
            <div className="flex-shrink-0 border rounded p-3 ml-3" style={{ width: "300px" }}>
                <h2>Add Product</h2>
                <form>
                    <div className="mb-2">
                        <label>Name</label>
                        <input type="text" name="name" value={newProduct.name} onChange={handleInputChange} className="form-control" />
                    </div>
                    <div className="mb-2">
                        <label>Category</label>
                        <select name="category_id" value={newProduct.category_id} onChange={handleInputChange} className="form-control">
                            <option value={1}>Electronics</option>
                            <option value={2}>Furniture</option>
                            <option value={3}>Clothing</option>
                            <option value={4}>Toys</option>
                            <option value={5}>Books</option>
                            <option value={6}>Groceries</option>
                            <option value={7}>Health</option>
                            <option value={8}>Sports</option>
                            <option value={9}>Beauty</option>
                            <option value={10}>Automotive</option>
                        </select>
                    </div>
                    <div className="mb-2">
                        <label>Warranty</label>
                        <select name="warranty_id" value={newProduct.warranty_id} onChange={handleInputChange} className="form-control">
                            <option value={1}>1 Year Warranty</option>
                            <option value={2}>2 Years Warranty</option>
                            <option value={3}>3 Years Warranty</option>
                            <option value={4}>Lifetime Warranty</option>
                            <option value={5}>6 Months Warranty</option>
                            <option value={6}>30 Days Warranty</option>
                            <option value={7}>Extended Warranty</option>
                            <option value={8}>Accidental Damage Warranty</option>
                            <option value={9}>Replacement Warranty</option>
                            <option value={10}>Service Warranty</option>
                        </select>
                    </div>
                    <div className="mb-2">
                        <label>Price</label>
                        <input type="number" name="price" value={newProduct.price} onChange={handleInputChange} className="form-control" />
                    </div>
                    <div className="mb-2">
                        <label>Description</label>
                        <input type="text" name="description" value={newProduct.description} onChange={handleInputChange} className="form-control" />
                    </div>
                    <div className="mb-2">
                        <label>Image URL</label>
                        <input type="text" name="image" value={newProduct.image} onChange={handleInputChange} className="form-control" />
                    </div>
                    <button type="button" onClick={handleAddProduct} className="btn btn-primary w-100">Submit</button>
                </form>
            </div>
        </div>
    );
}

export default EditProduct;